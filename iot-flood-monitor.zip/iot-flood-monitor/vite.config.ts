import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: { alias: { "@": "/src" } },
  // Library ini dimuat dinamis (saat unduh/QR); di-bundle di awal agar dev server tidak reload mendadak
  optimizeDeps: { include: ["exceljs", "jspdf", "jspdf-autotable", "qrcode.react", "leaflet", "react-leaflet"] },
});
