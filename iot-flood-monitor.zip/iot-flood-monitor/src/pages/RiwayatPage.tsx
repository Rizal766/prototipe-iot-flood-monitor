import { useMemo, useState } from "react";
import { HistoryOutlined } from "@ant-design/icons";
import dayjs from "dayjs";
import Panel from "@/components/dashboard/Panel";
import ExportCard from "@/components/history/ExportCard";
import FilterInfoCard from "@/components/history/FilterInfoCard";
import HistoryFilters, { MAX_SENSORS, type IDataTypes } from "@/components/history/HistoryFilters";
import HistoryLineChart, { type ILineSeries } from "@/components/history/HistoryLineChart";
import HistoryMiniMap from "@/components/history/HistoryMiniMap";
import HistoryTable from "@/components/history/HistoryTable";
import RainBarChart from "@/components/history/RainBarChart";
import StatsSummaryTable from "@/components/history/StatsSummaryTable";
import { useThresholdMap } from "@/hooks/useAlertConfigs";
import { useCsvExport } from "@/hooks/useCsvExport";
import { useHistory } from "@/hooks/useHistory";
import { useSensors } from "@/hooks/useSensors";
import { HistoryInterval, INTERVAL_HOURS, type IHistoryRow } from "@/types/history";
import { customRange, defaultInterval, presetRange, type IRange, type RangeKey } from "@/utils/historyRange";
import { levelToStatus } from "@/utils/thresholds";

const SERIES_COLORS = ["#3b82f6", "#ef4444", "#a855f7", "#f59e0b", "#22c55e"];

const RiwayatPage = () => {
  const { data: sensorData } = useSensors({ page: 1, limit: 100 });
  const sensors = useMemo(() => sensorData?.data ?? [], [sensorData]);

  const [selectedIds, setSelectedIds] = useState<number[] | null>(null);
  const ids = useMemo(
    () => selectedIds ?? sensors.slice(0, MAX_SENSORS).map((s) => s.id),
    [selectedIds, sensors],
  );

  const [rangeKey, setRangeKey] = useState<RangeKey>("30d");
  const [range, setRange] = useState<IRange>(() => presetRange("30d"));
  const [interval, setIntervalValue] = useState<HistoryInterval>(() => defaultInterval(presetRange("30d")));
  const [types, setTypes] = useState<IDataTypes>({ water: true, rain: true });

  const thresholdMap = useThresholdMap();
  const { state: exportState, start: startExport, reopen, dismiss } = useCsvExport();
  const history = useHistory({ sensorIds: ids, from: range.from, to: range.to, interval });
  const seriesData = useMemo(() => history.data?.data ?? [], [history.data]);

  const times = useMemo(() => seriesData[0]?.points.map((p) => p.t) ?? [], [seriesData]);

  const waterSeries = useMemo<ILineSeries[]>(
    () =>
      seriesData.map((s, i) => ({
        code: s.code,
        color: SERIES_COLORS[i % SERIES_COLORS.length],
        values: s.points.map((p) => p.waterLevel),
        siaga: thresholdMap.get(s.sensorId)?.siaga,
      })),
    [seriesData, thresholdMap],
  );

  const rainValues = useMemo(
    () =>
      times.map((_, i) => {
        const sum = seriesData.reduce((a, s) => a + (s.points[i]?.rainfall ?? 0), 0);
        return Math.round((sum / (seriesData.length || 1)) * 10) / 10;
      }),
    [times, seriesData],
  );

  const rows = useMemo<IHistoryRow[]>(
    () =>
      seriesData
        .flatMap((s) =>
          s.points.map((p) => ({
            id: `${s.sensorId}-${p.t}`,
            t: p.t,
            code: s.code,
            location: s.location,
            district: s.district,
            river: s.river,
            waterLevel: p.waterLevel,
            rainfall: p.rainfall,
            status: levelToStatus(p.waterLevel, thresholdMap.get(s.sensorId)),
          })),
        )
        .sort((a, b) => b.t.localeCompare(a.t) || a.code.localeCompare(b.code)),
    [seriesData, thresholdMap],
  );

  const mapSensors = useMemo(() => sensors.filter((s) => ids.includes(s.id)), [sensors, ids]);

  const applyRange = (next: IRange) => {
    setRange(next);
    setIntervalValue(defaultInterval(next));
  };

  const handlePreset = (key: RangeKey) => {
    setRangeKey(key);
    if (key !== "custom") applyRange(presetRange(key));
  };

  const handleExport = (exportRows: IHistoryRow[]) => {
    const header = ["Waktu", "ID Sensor", "Lokasi", "Kecamatan", "Sungai"];
    if (types.water) header.push("Tinggi Air (cm)");
    if (types.rain) header.push("Curah Hujan (mm)");
    header.push("Status");
    const matrix = exportRows.map((r) => {
      const line: (string | number)[] = [dayjs(r.t).format("YYYY-MM-DD HH:mm"), r.code, r.location, r.district, r.river];
      if (types.water) line.push(r.waterLevel);
      if (types.rain) line.push(r.rainfall);
      line.push(r.status);
      return line;
    });
    void startExport(header, matrix, "riwayat-data");
  };

  const loading = history.isLoading || history.isFetching;

  return (
    <div className="mx-auto flex w-full max-w-[1600px] flex-col gap-3">
      <div className="flex items-center gap-3">
        <HistoryOutlined className="text-3xl text-slate-700" />
        <div>
          <h1 className="m-0 text-lg font-bold leading-tight">Riwayat Data</h1>
          <p className="m-0 text-xs text-slate-500">
            Lihat dan analisis data historis sensor untuk kebutuhan evaluasi dan pelaporan
          </p>
        </div>
      </div>

      <HistoryFilters
        rangeKey={rangeKey}
        sensors={sensors}
        ids={ids}
        types={types}
        interval={interval}
        exporting={exportState.status === "running"}
        onPreset={handlePreset}
        onCustom={(from, to) => applyRange(customRange(from, to))}
        onIds={setSelectedIds}
        onTypes={setTypes}
        onInterval={setIntervalValue}
        onExport={() => handleExport(rows)}
      />

      {history.isError && (
        <p className="m-0 rounded border border-red-200 bg-red-50 p-2 text-xs text-red-600">Gagal memuat data historis.</p>
      )}

      <div className="grid grid-cols-1 items-stretch gap-3 xl:grid-cols-[minmax(0,1fr)_minmax(0,400px)]">
        <Panel title={`Perbandingan Tinggi Air (${ids.length} Sensor)`}>
          {types.water ? (
            <HistoryLineChart times={times} series={waterSeries} unit="cm" />
          ) : (
            <p className="m-0 py-10 text-center text-xs text-slate-400">Aktifkan jenis data Tinggi Air untuk melihat grafik</p>
          )}
        </Panel>
        <Panel title="Ringkasan Statistik per Sensor">
          {types.water ? (
            <StatsSummaryTable series={waterSeries} intervalHours={INTERVAL_HOURS[interval]} />
          ) : (
            <p className="m-0 py-6 text-center text-xs text-slate-400">Aktifkan Tinggi Air untuk melihat statistik</p>
          )}
        </Panel>
      </div>

      <div className="grid grid-cols-1 items-stretch gap-3 lg:grid-cols-2 xl:grid-cols-[minmax(0,1fr)_minmax(0,280px)_minmax(0,280px)]">
        <Panel title={`Data Curah Hujan (${ids.length} Sensor)`} className="lg:col-span-2 xl:col-span-1">
          {types.rain ? (
            <RainBarChart times={times} values={rainValues} />
          ) : (
            <p className="m-0 py-10 text-center text-xs text-slate-400">Aktifkan jenis data Curah Hujan untuk melihat grafik</p>
          )}
          <p className="m-0 mt-1 text-[10px] text-slate-400">Rata-rata curah hujan (mm) seluruh sensor terpilih per interval</p>
        </Panel>
        <FilterInfoCard range={range} sensorCount={ids.length} types={types} interval={interval} />
        <ExportCard state={exportState} onReopen={reopen} onDismiss={dismiss} />
      </div>

      <div className="grid grid-cols-1 items-start gap-3 2xl:grid-cols-[minmax(0,1fr)_340px]">
        <HistoryTable rows={rows} loading={loading} types={types} onExport={handleExport} />
        <HistoryMiniMap sensors={mapSensors} />
      </div>
    </div>
  );
};

export default RiwayatPage;
