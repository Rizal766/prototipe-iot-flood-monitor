import SensorSearchPanel from "@/components/peta/SensorSearchPanel";
import StatusChips from "@/components/peta/StatusChips";
import LayerTabs from "@/components/peta/LayerTabs";
import MapCanvas from "@/components/peta/MapCanvas";
import MapBottomBar from "@/components/peta/MapBottomBar";
import SensorDetailPanel from "@/components/peta/SensorDetailPanel";
import SpecialCases from "@/components/peta/SpecialCases";

const PetaPage = () => (
  <div className="grid grid-cols-1 gap-3 xl:grid-cols-[250px_minmax(0,1fr)_270px]">
    <div className="order-2 xl:order-1">
      <SensorSearchPanel />
    </div>
    <div className="order-1 flex min-w-0 flex-col gap-3 xl:order-2">
      <StatusChips />
      <LayerTabs />
      <MapCanvas />
      <MapBottomBar />
    </div>
    <div className="order-3 flex flex-col gap-3">
      <SensorDetailPanel />
      <SpecialCases />
    </div>
  </div>
);

export default PetaPage;
