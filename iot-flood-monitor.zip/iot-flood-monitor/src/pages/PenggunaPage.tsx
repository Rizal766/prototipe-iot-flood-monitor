import { useCallback, useMemo, useState } from "react";
import { Alert, Button, Input, Modal, Select, Spin, message } from "antd";
import { SearchOutlined, TeamOutlined } from "@ant-design/icons";
import type { GridPaginationModel } from "@mui/x-data-grid";
import Panel from "@/components/dashboard/Panel";
import AreaTable from "@/components/pengguna/AreaTable";
import InvitePanel from "@/components/pengguna/InvitePanel";
import PermissionMatrix from "@/components/pengguna/PermissionMatrix";
import UserModal from "@/components/pengguna/UserModal";
import UserStats from "@/components/pengguna/UserStats";
import UserTable from "@/components/pengguna/UserTable";
import { usePermissionMatrix } from "@/hooks/usePermissions";
import { useSensors } from "@/hooks/useSensors";
import { useAreas, useUserMutations, useUsers } from "@/hooks/useUsers";
import { useAuthStore } from "@/stores/useAuthStore";
import { ROLE_LABEL, UserRole } from "@/types/auth";
import { UserStatus, type IUser } from "@/types/user";

type Tab = "pengguna" | "hak-akses" | "warga";

const TABS: { key: Tab; label: string }[] = [
  { key: "pengguna", label: "Pengguna" },
  { key: "hak-akses", label: "Hak Akses Per Role" },
  { key: "warga", label: "Warga Terdaftar" },
];

interface IFilters {
  search: string;
  role: UserRole | "ALL";
  status: UserStatus | "ALL";
}

const DEFAULT_FILTERS: IFilters = { search: "", role: "ALL", status: "ALL" };

const PenggunaPage = () => {
  const user = useAuthStore((s) => s.user);
  const isAdmin = user?.role === UserRole.ADMIN;

  const { data, isLoading, isError, refetch } = useUsers();
  const users = useMemo(() => data?.data ?? [], [data]);
  const { data: areaData } = useAreas();
  const areas = useMemo(() => areaData?.data ?? [], [areaData]);
  const { data: sensorData } = useSensors({ page: 1, limit: 100 });
  const { data: permData } = usePermissionMatrix();
  const { update, remove } = useUserMutations();

  const districts = useMemo(
    () => [...new Set([...areas.map((a) => a.district), ...(sensorData?.data ?? []).map((s) => s.district)])].sort(),
    [areas, sensorData],
  );

  const [tab, setTab] = useState<Tab>("pengguna");
  const [filters, setFilters] = useState<IFilters>(DEFAULT_FILTERS);
  const [paging, setPaging] = useState<GridPaginationModel>({ page: 0, pageSize: 10 });
  const [editing, setEditing] = useState<IUser | null>(null);

  const patchFilters = (patch: Partial<IFilters>) => {
    setFilters((f) => ({ ...f, ...patch }));
    setPaging((p) => ({ ...p, page: 0 }));
  };

  const rows = useMemo(() => {
    const q = filters.search.trim().toLowerCase();
    return users
      .filter((u) => filters.role === "ALL" || u.role === filters.role)
      .filter((u) => filters.status === "ALL" || u.status === filters.status)
      .filter((u) => !q || [u.name, u.email, u.phone].some((f) => f.toLowerCase().includes(q)));
  }, [users, filters]);

  const handleEdit = useCallback((u: IUser) => setEditing(u), []);

  const handleToggle = useCallback(
    async (u: IUser) => {
      const next = u.status === UserStatus.AKTIF ? UserStatus.NONAKTIF : UserStatus.AKTIF;
      const res = await update.mutateAsync({
        id: u.id,
        payload: { name: u.name, email: u.email, phone: u.phone, role: u.role, areas: u.areas, status: next },
      });
      if (res.status) message.success(next === UserStatus.AKTIF ? "Pengguna diaktifkan" : "Pengguna dinonaktifkan");
      else message.error(res.message || "Gagal mengubah status");
    },
    [update],
  );

  const handleDelete = useCallback(
    (u: IUser) => {
      Modal.confirm({
        title: "Hapus pengguna?",
        content: `${u.name} (${ROLE_LABEL[u.role]}) akan dihapus dan tidak dapat masuk lagi.`,
        okText: "Hapus",
        okButtonProps: { danger: true },
        cancelText: "Batal",
        onOk: async () => {
          const res = await remove.mutateAsync(u.id);
          if (res.status) message.success("Pengguna dihapus");
          else message.error(res.message || "Gagal menghapus pengguna");
        },
      });
    },
    [remove],
  );

  const permissionMatrix = permData?.data;

  return (
    <div className="grid grid-cols-1 gap-3 xl:grid-cols-[minmax(0,1fr)_340px]">
      <div className="flex min-w-0 flex-col gap-3">
        <div className="flex items-center gap-3">
          <TeamOutlined className="text-3xl text-slate-700" />
          <div>
            <h1 className="m-0 text-lg font-bold leading-tight">Pengguna & Role</h1>
            <p className="m-0 text-xs text-slate-500">Kelola pengguna, hak akses, dan warga terdaftar.</p>
          </div>
        </div>

        <div className="flex gap-1 overflow-x-auto rounded-lg border border-slate-200 bg-white px-2 shadow-sm" role="tablist">
          {TABS.map((t) => (
            <button
              key={t.key}
              type="button"
              role="tab"
              aria-selected={tab === t.key}
              onClick={() => setTab(t.key)}
              className={`shrink-0 cursor-pointer border-x-0 border-t-0 bg-transparent px-4 py-3 text-sm font-medium ${
                tab === t.key ? "border-b-2 border-blue-600 text-blue-600" : "border-b-2 border-transparent text-slate-600"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {tab === "pengguna" && (
          <>
            {isError && (
              <Alert
                type="error"
                showIcon
                message="Gagal memuat daftar pengguna"
                action={<Button size="small" onClick={() => void refetch()}>Coba lagi</Button>}
              />
            )}
            <UserStats users={users} active={filters.role} onSelect={(r) => patchFilters({ role: r })} />

            <div className="flex flex-wrap items-center gap-2 rounded-lg border border-slate-200 bg-white p-2 shadow-sm">
              <Input
                allowClear
                className="min-w-[200px] flex-1 md:max-w-sm"
                prefix={<SearchOutlined />}
                placeholder="Cari nama, email, atau nomor HP..."
                value={filters.search}
                onChange={(e) => patchFilters({ search: e.target.value })}
              />
              <Select
                className="w-44"
                value={filters.role}
                onChange={(v: UserRole | "ALL") => patchFilters({ role: v })}
                options={[{ value: "ALL", label: "Semua role" }, ...Object.values(UserRole).map((r) => ({ value: r, label: ROLE_LABEL[r] }))]}
              />
              <Select
                className="w-36"
                value={filters.status}
                onChange={(v: UserStatus | "ALL") => patchFilters({ status: v })}
                options={[
                  { value: "ALL", label: "Semua status" },
                  { value: UserStatus.AKTIF, label: "Aktif" },
                  { value: UserStatus.NONAKTIF, label: "Nonaktif" },
                ]}
              />
              <Button onClick={() => patchFilters(DEFAULT_FILTERS)}>Reset Filter</Button>
            </div>

            <Panel title={`Daftar Pengguna (${rows.length})`}>
              <UserTable
                rows={rows}
                loading={isLoading}
                isAdmin={isAdmin}
                selfEmail={user?.email ?? ""}
                paging={paging}
                onPagingChange={setPaging}
                onEdit={handleEdit}
                onToggle={(u) => void handleToggle(u)}
                onDelete={handleDelete}
              />
            </Panel>
          </>
        )}

        {tab === "hak-akses" &&
          (permissionMatrix ? (
            <PermissionMatrix key={JSON.stringify(permissionMatrix)} matrix={permissionMatrix} isAdmin={isAdmin} />
          ) : (
            <Spin className="mt-6 block" />
          ))}

        {tab === "warga" && <AreaTable key={JSON.stringify(areas)} areas={areas} isAdmin={isAdmin} />}
      </div>

      <InvitePanel districts={districts} isAdmin={isAdmin} />

      <UserModal user={editing} districts={districts} onClose={() => setEditing(null)} />
    </div>
  );
};

export default PenggunaPage;
