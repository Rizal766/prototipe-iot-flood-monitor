import SummaryCards from "@/components/dashboard/SummaryCards";
import MonitoringMap from "@/components/dashboard/MonitoringMap";
import AlertList from "@/components/dashboard/AlertList";
import WeatherForecast from "@/components/dashboard/WeatherForecast";
import WaterLevelChart from "@/components/dashboard/WaterLevelChart";
import SensorTable from "@/components/dashboard/SensorTable";
import IntegrationList from "@/components/dashboard/IntegrationList";

const DashboardPage = () => (
  <div className="flex flex-col gap-3">
    <SummaryCards />

    <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
      <div className="lg:col-span-2">
        <MonitoringMap />
      </div>
      <div className="flex flex-col gap-3">
        <AlertList />
        <WeatherForecast />
      </div>
    </div>

    <div className="grid grid-cols-1 gap-3 lg:grid-cols-12">
      <div className="lg:col-span-4">
        <WaterLevelChart />
      </div>
      <div className="lg:col-span-5">
        <SensorTable />
      </div>
      <div className="lg:col-span-3">
        <IntegrationList />
      </div>
    </div>
  </div>
);

export default DashboardPage;
