import { Alert, Button, Spin } from "antd";
import { LockOutlined } from "@ant-design/icons";
import PasswordCard from "@/components/profil/PasswordCard";
import PreferencesCard from "@/components/profil/PreferencesCard";
import ProfileCard from "@/components/profil/ProfileCard";
import SessionsCard from "@/components/profil/SessionsCard";
import ThemeCard from "@/components/profil/ThemeCard";
import { useProfile } from "@/hooks/useProfile";

const ProfilPage = () => {
  const { data, isLoading, isError, refetch } = useProfile();
  const profile = data?.data;

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-3">
        <LockOutlined className="text-3xl text-slate-700" />
        <div>
          <h1 className="m-0 text-lg font-bold leading-tight">Profil & Keamanan</h1>
          <p className="m-0 text-xs text-slate-500">Kelola informasi akun, keamanan, dan preferensi notifikasi Anda.</p>
        </div>
      </div>

      {isError && (
        <Alert
          type="error"
          showIcon
          message="Gagal memuat profil"
          action={<Button size="small" onClick={() => void refetch()}>Coba lagi</Button>}
        />
      )}

      <div className="grid grid-cols-1 items-stretch gap-3 xl:grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)]">
        {isLoading ? <Spin className="mt-6 block" /> : profile ? <ProfileCard key={`${profile.name}|${profile.phone}|${profile.avatar ? profile.avatar.length : 0}`} profile={profile} /> : null}
        <PasswordCard />
      </div>

      <div className="grid grid-cols-1 items-stretch gap-3 lg:grid-cols-2 xl:grid-cols-3">
        <SessionsCard />
        <PreferencesCard />
        <ThemeCard />
      </div>
    </div>
  );
};

export default ProfilPage;
