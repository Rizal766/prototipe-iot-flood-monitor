import { useMemo, useState } from "react";
import { Alert, Button, DatePicker, Modal, Result, Spin } from "antd";
import { ArrowLeftOutlined, DownloadOutlined, EditOutlined, EnvironmentOutlined } from "@ant-design/icons";
import dayjs from "dayjs";
import { useNavigate, useParams } from "react-router-dom";
import Panel from "@/components/dashboard/Panel";
import HistoryLineChart, { type IThresholdLine } from "@/components/history/HistoryLineChart";
import RainBarChart from "@/components/history/RainBarChart";
import SensorMap from "@/components/map/SensorMap";
import SensorForm from "@/components/SensorForm";
import StatusBadge from "@/components/StatusBadge";
import AlertHistory from "@/components/sensor-detail/AlertHistory";
import DeviceInfoPanel from "@/components/sensor-detail/DeviceInfoPanel";
import ThresholdGauge from "@/components/sensor-detail/ThresholdGauge";
import { useAlertConfigs } from "@/hooks/useAlertConfigs";
import { useCsvExport } from "@/hooks/useCsvExport";
import { useDevices } from "@/hooks/useDevices";
import { useHistory } from "@/hooks/useHistory";
import { useNotifications } from "@/hooks/useNotifications";
import { useSensorMutations } from "@/hooks/useSensorMutations";
import { useSensors } from "@/hooks/useSensors";
import { toPayload } from "@/schemas/sensorSchema";
import { useAuthStore } from "@/stores/useAuthStore";
import { useMapStore } from "@/stores/useMapStore";
import { useSensorStore } from "@/stores/useSensorStore";
import { UserRole } from "@/types/auth";
import { FloodStatus } from "@/types/sensor";
import { customRange, defaultInterval, type IRange } from "@/utils/historyRange";
import { STATUS_META, formatTrend } from "@/utils/status";
import { DEFAULT_THRESHOLDS } from "@/utils/thresholds";
import { formatDateTime } from "@/utils/time";

type RangeKey = "24h" | "7d" | "30d" | "custom";
type ChartTab = "air" | "hujan";

const RANGES: { key: RangeKey; label: string }[] = [
  { key: "24h", label: "24 Jam" },
  { key: "7d", label: "7 Hari" },
  { key: "30d", label: "30 Hari" },
  { key: "custom", label: "Kustom" },
];

const presetRange = (key: Exclude<RangeKey, "custom">): IRange => {
  const to = dayjs();
  const from = key === "24h" ? to.subtract(24, "hour") : to.subtract(key === "7d" ? 7 : 30, "day");
  return { from: from.toISOString(), to: to.toISOString() };
};

const SensorDetailPage = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const sensorId = Number(id);
  const isAdmin = useAuthStore((s) => s.user?.role === UserRole.ADMIN);
  const selectSensor = useSensorStore((s) => s.selectSensor);
  const flyTo = useMapStore((s) => s.flyTo);

  const { data: sensorData, isLoading } = useSensors({ page: 1, limit: 100 });
  const sensor = useMemo(() => sensorData?.data?.find((s) => s.id === sensorId), [sensorData, sensorId]);
  const { data: deviceData } = useDevices();
  const device = useMemo(() => deviceData?.data?.find((d) => d.sensorId === sensorId), [deviceData, sensorId]);
  const { data: cfgData } = useAlertConfigs();
  const thresholds = cfgData?.data?.find((c) => c.sensorId === sensorId)?.thresholds ?? DEFAULT_THRESHOLDS;
  const { data: notifData, isLoading: alertsLoading } = useNotifications();
  const alerts = useMemo(
    () => (notifData?.data ?? []).filter((n) => n.sensorCode === sensor?.code),
    [notifData, sensor?.code],
  );

  const [rangeKey, setRangeKey] = useState<RangeKey>("24h");
  const [range, setRange] = useState<IRange>(() => presetRange("24h"));
  const [tab, setTab] = useState<ChartTab>("air");
  const [editing, setEditing] = useState(false);

  const history = useHistory({
    sensorIds: sensor ? [sensor.id] : [],
    from: range.from,
    to: range.to,
    interval: defaultInterval(range),
  });
  const points = useMemo(() => history.data?.data?.[0]?.points ?? [], [history.data]);
  const times = useMemo(() => points.map((p) => p.t), [points]);
  const water = useMemo(() => points.map((p) => p.waterLevel), [points]);
  const rain = useMemo(() => points.map((p) => p.rainfall), [points]);

  const { state: exportState, start: startExport } = useCsvExport();
  const { update } = useSensorMutations(() => setEditing(false));

  if (isLoading) return <Spin className="mt-10 block" />;
  if (!sensor) {
    return (
      <Result
        status="404"
        title="Sensor tidak ditemukan"
        subTitle="Sensor mungkin sudah dihapus atau alamatnya salah."
        extra={<Button type="primary" onClick={() => navigate("/sensors")}>Kembali ke Data Sensor</Button>}
      />
    );
  }

  const offline = sensor.status === FloodStatus.OFFLINE;
  const lastUpdate = sensor.lastSeenMinutes === null ? null : new Date(Date.now() - sensor.lastSeenMinutes * 60000).toISOString();
  const toDanger = Math.max(0, thresholds.bahaya - sensor.waterLevel);
  const overDanger = !offline && sensor.waterLevel >= thresholds.bahaya;
  const trendColor = sensor.trend > 0 ? "text-red-500" : sensor.trend < 0 ? "text-green-600" : "text-slate-400";

  const thresholdLines: IThresholdLine[] = [
    { label: `Waspada ${thresholds.waspada}`, value: thresholds.waspada, color: STATUS_META[FloodStatus.WASPADA].color },
    { label: `Siaga ${thresholds.siaga}`, value: thresholds.siaga, color: STATUS_META[FloodStatus.SIAGA].color },
    { label: `Bahaya ${thresholds.bahaya}`, value: thresholds.bahaya, color: STATUS_META[FloodStatus.BAHAYA].color },
  ];

  const handleRange = (key: RangeKey) => {
    setRangeKey(key);
    if (key !== "custom") setRange(presetRange(key));
  };

  const showOnMap = () => {
    selectSensor(sensor.id);
    flyTo({ lat: sensor.lat, lng: sensor.lng });
    navigate("/peta");
  };

  const exportData = () =>
    void startExport(
      ["Waktu", "Tinggi Air (cm)", "Curah Hujan (mm)"],
      points.map((p) => [dayjs(p.t).format("YYYY-MM-DD HH:mm"), p.waterLevel, p.rainfall]),
      `sensor-${sensor.code.toLowerCase()}`,
    );

  const chartBox = history.isLoading ? (
    <Spin className="block py-12" />
  ) : history.isError ? (
    <Alert type="error" showIcon message="Gagal memuat data grafik" action={<Button size="small" onClick={() => void history.refetch()}>Coba lagi</Button>} />
  ) : null;

  return (
    <div className="grid grid-cols-1 gap-3 xl:grid-cols-[minmax(0,1fr)_320px]">
      <div className="flex min-w-0 flex-col gap-3">
        <Button type="link" icon={<ArrowLeftOutlined />} className="self-start !px-0" onClick={() => navigate("/sensors")}>
          Data Sensor
        </Button>

        <section className="flex flex-wrap items-center gap-3 rounded-lg border border-slate-200 bg-white p-3 shadow-sm">
          <div className="min-w-0 flex-1">
            <h1 className="m-0 text-lg font-bold leading-tight">#{sensor.code}</h1>
            <p className="m-0 text-sm font-medium">{sensor.location}</p>
            <p className="m-0 text-xs text-slate-500">
              Sungai {sensor.river} · Kec. {sensor.district}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <StatusBadge status={sensor.status} />
            <span
              className={`inline-flex items-center gap-1.5 rounded-md border px-2 py-0.5 text-[11px] font-semibold ${
                offline ? "border-slate-400 bg-slate-50 text-slate-600" : "border-green-600 bg-green-50 text-green-700"
              }`}
            >
              <span className={`h-1.5 w-1.5 rounded-full ${offline ? "bg-slate-400" : "bg-green-500"}`} />
              {offline ? "Offline" : "Online"}
            </span>
          </div>
          <div className="text-xs leading-tight text-slate-500">
            <p className="m-0">Update terakhir</p>
            <p className="m-0 font-medium text-slate-700">{lastUpdate ? formatDateTime(lastUpdate) : "Belum pernah"}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button icon={<EditOutlined />} disabled={!isAdmin} onClick={() => setEditing(true)}>
              Edit
            </Button>
            <Button icon={<EnvironmentOutlined />} onClick={showOnMap}>
              Lihat di Peta
            </Button>
            <Button icon={<DownloadOutlined />} loading={exportState.status === "running"} disabled={points.length === 0} onClick={exportData}>
              Ekspor Data
            </Button>
          </div>
        </section>

        <div className="grid grid-cols-1 gap-3 md:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_minmax(0,1.6fr)]">
          <Panel title="Tinggi Air Saat Ini">
            <p className="m-0 text-3xl font-bold leading-tight">{offline ? "-" : `${sensor.waterLevel} cm`}</p>
            <p className={`m-0 text-xs font-semibold ${trendColor}`}>{offline ? "Sensor offline" : formatTrend(sensor.trend)}</p>
          </Panel>
          <Panel title="Jarak ke Ambang Bahaya">
            <p className="m-0 text-3xl font-bold leading-tight" style={{ color: overDanger ? STATUS_META[FloodStatus.BAHAYA].color : undefined }}>
              {offline ? "-" : `${toDanger} cm`}
            </p>
            <p className={`m-0 text-xs ${overDanger ? "font-semibold text-red-500" : "text-slate-500"}`}>
              {offline ? "Tidak ada data" : overDanger ? "Sudah melewati batas bahaya" : `Ambang bahaya ${thresholds.bahaya} cm`}
            </p>
          </Panel>
          <Panel title="Ambang Batas">
            <ThresholdGauge thresholds={thresholds} level={offline ? 0 : sensor.waterLevel} />
          </Panel>
        </div>

        <Panel
          title={
            <span className="flex gap-1.5">
              {(["air", "hujan"] as ChartTab[]).map((k) => (
                <Button key={k} size="small" type={tab === k ? "primary" : "default"} onClick={() => setTab(k)}>
                  {k === "air" ? "Tinggi Air" : "Curah Hujan"}
                </Button>
              ))}
            </span>
          }
          actions={
            <span className="flex flex-wrap items-center gap-1.5">
              {RANGES.map((r) => (
                <Button key={r.key} size="small" type={rangeKey === r.key ? "primary" : "default"} onClick={() => handleRange(r.key)}>
                  {r.label}
                </Button>
              ))}
            </span>
          }
        >
          {rangeKey === "custom" && (
            <DatePicker.RangePicker
              className="mb-2 w-full sm:w-80"
              disabledDate={(d) => d.isAfter(dayjs(), "day")}
              onChange={(v) => {
                if (v && v[0] && v[1]) setRange(customRange(v[0], v[1]));
              }}
            />
          )}
          {chartBox ??
            (tab === "air" ? (
              <>
                <p className="m-0 mb-1 text-[11px] text-slate-500">Tinggi Air (cm)</p>
                <HistoryLineChart
                  times={times}
                  series={[{ code: sensor.code, color: "#3b82f6", values: water }]}
                  unit="cm"
                  height={230}
                  thresholds={thresholdLines}
                  area
                />
              </>
            ) : (
              <>
                <p className="m-0 mb-1 text-[11px] text-slate-500">Curah Hujan (mm)</p>
                <RainBarChart times={times} values={rain} height={230} />
              </>
            ))}
        </Panel>

        {tab === "air" && !chartBox && (
          <Panel title="Curah Hujan (mm)">
            <RainBarChart times={times} values={rain} height={120} />
          </Panel>
        )}

        <AlertHistory code={sensor.code} alerts={alerts} loading={alertsLoading} />
      </div>

      <div className="flex min-w-0 flex-col gap-3">
        <DeviceInfoPanel sensor={sensor} device={device} />
        <Panel title="Lokasi di Peta">
          <div className="relative isolate h-[220px] overflow-hidden rounded-md border border-slate-200 bg-slate-200">
            <div className="absolute inset-0">
              <SensorMap sensors={[sensor]} selectedId={null} onSelect={() => undefined} fitToSensors />
            </div>
          </div>
          <Button block icon={<EnvironmentOutlined />} className="mt-2" onClick={showOnMap}>
            Buka di Peta Monitoring
          </Button>
        </Panel>
      </div>

      <Modal open={editing} title={`Edit Sensor #${sensor.code}`} footer={null} onCancel={() => setEditing(false)} width={560}>
        {editing && (
          <SensorForm
            lockCode
            loading={update.isPending}
            submitLabel="Simpan Perubahan"
            defaultValues={{
              code: sensor.code,
              location: sensor.location,
              river: sensor.river,
              district: sensor.district,
              lat: String(sensor.lat),
              lng: String(sensor.lng),
            }}
            onSubmit={(v) => update.mutate({ id: sensor.id, payload: toPayload(v) })}
          />
        )}
      </Modal>
    </div>
  );
};

export default SensorDetailPage;
