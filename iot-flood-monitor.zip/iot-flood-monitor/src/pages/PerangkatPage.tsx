import { useCallback, useMemo, useState } from "react";
import { Alert, Button, Modal, message } from "antd";
import { ToolOutlined } from "@ant-design/icons";
import type { GridPaginationModel, GridRowSelectionModel } from "@mui/x-data-grid";
import { testConnection } from "@/api/deviceApi";
import Panel from "@/components/dashboard/Panel";
import AddDeviceWizard from "@/components/perangkat/AddDeviceWizard";
import ConnectionTestModal from "@/components/perangkat/ConnectionTestModal";
import DeviceStats from "@/components/perangkat/DeviceStats";
import DeviceTable from "@/components/perangkat/DeviceTable";
import DeviceToolbar, { ALL, DEFAULT_DEVICE_FILTERS, type IDeviceFilters } from "@/components/perangkat/DeviceToolbar";
import EditDeviceModal from "@/components/perangkat/EditDeviceModal";
import PairingQrModal from "@/components/perangkat/PairingQrModal";
import { useDeviceMutations, useDevices } from "@/hooks/useDevices";
import { useAuthStore } from "@/stores/useAuthStore";
import { UserRole } from "@/types/auth";
import type { IDevice } from "@/types/device";

const PerangkatPage = () => {
  const isAdmin = useAuthStore((s) => s.user?.role === UserRole.ADMIN);
  const { data, isLoading, isError, refetch } = useDevices();
  const devices = useMemo(() => data?.data ?? [], [data]);
  const { remove } = useDeviceMutations();

  const [filters, setFilters] = useState<IDeviceFilters>(DEFAULT_DEVICE_FILTERS);
  const [selection, setSelection] = useState<GridRowSelectionModel>([]);
  const [paging, setPaging] = useState<GridPaginationModel>({ page: 0, pageSize: 10 });
  const [testing, setTesting] = useState<IDevice | null>(null);
  const [pairing, setPairing] = useState<IDevice | null>(null);
  const [editing, setEditing] = useState<IDevice | null>(null);
  const [bulkBusy, setBulkBusy] = useState(false);

  const patchFilters = useCallback((patch: Partial<IDeviceFilters>) => {
    setFilters((f) => ({ ...f, ...patch }));
    setPaging((p) => ({ ...p, page: 0 }));
  }, []);

  const districts = useMemo(() => [...new Set(devices.map((d) => d.district))].sort(), [devices]);

  const rows = useMemo(() => {
    const q = filters.search.trim().toLowerCase();
    const [from, to] = filters.range
      ? [filters.range[0].startOf("day").valueOf(), filters.range[1].endOf("day").valueOf()]
      : [null, null];
    return devices
      .filter((d) => filters.connection === "ALL" || d.connection === filters.connection)
      .filter((d) => filters.kind === "ALL" || d.kind === filters.kind)
      .filter((d) => filters.district === ALL || d.district === filters.district)
      .filter((d) => !q || [d.deviceId, d.name, d.guid, d.river, d.district].some((f) => f.toLowerCase().includes(q)))
      .filter((d) => {
        if (from === null || to === null) return true;
        if (!d.lastSeen) return false;
        const t = new Date(d.lastSeen).getTime();
        return t >= from && t <= to;
      });
  }, [devices, filters]);

  const selectedIds = useMemo(() => rows.filter((r) => selection.includes(r.id)).map((r) => r.id), [rows, selection]);

  const handleEdit = useCallback((d: IDevice) => setEditing(d), []);
  const handleTest = useCallback((d: IDevice) => setTesting(d), []);
  const handlePairing = useCallback((d: IDevice) => setPairing(d), []);
  const handleDelete = useCallback(
    (d: IDevice) => {
      Modal.confirm({
        title: "Hapus perangkat?",
        content: `Perangkat ${d.deviceId} (${d.name}) akan dihapus beserta sensor dan konfigurasi alert terkait. Tindakan ini tidak dapat dibatalkan.`,
        okText: "Hapus",
        okButtonProps: { danger: true },
        cancelText: "Batal",
        onOk: async () => {
          const res = await remove.mutateAsync(d.id);
          if (res.status) message.success("Perangkat dihapus");
          else message.error(res.message || "Gagal menghapus perangkat");
        },
      });
    },
    [remove],
  );

  const bulkTest = async () => {
    setBulkBusy(true);
    const results = await Promise.allSettled(selectedIds.map((id) => testConnection(id)));
    const okCount = results.filter((r) => r.status === "fulfilled" && r.value.data?.ok).length;
    setBulkBusy(false);
    message.info(`Uji koneksi selesai: ${okCount} berhasil, ${selectedIds.length - okCount} gagal`);
  };

  return (
    <div className="grid grid-cols-1 gap-3 xl:grid-cols-[minmax(0,1fr)_340px]">
      <div className="flex min-w-0 flex-col gap-3">
        <div className="flex items-center gap-3">
          <ToolOutlined className="text-3xl text-slate-700" />
          <div>
            <h1 className="m-0 text-lg font-bold leading-tight">Kelola Perangkat</h1>
            <p className="m-0 text-xs text-slate-500">
              Kelola dan konfigurasi sensor, gateway, dan perangkat IoT di seluruh lokasi.
            </p>
          </div>
        </div>

        {isError && (
          <Alert
            type="error"
            showIcon
            message="Gagal memuat daftar perangkat"
            action={<Button size="small" onClick={() => void refetch()}>Coba lagi</Button>}
          />
        )}

        <DeviceStats devices={devices} active={filters.connection} onSelect={(c) => patchFilters({ connection: c })} />
        <DeviceToolbar filters={filters} districts={districts} onChange={patchFilters} />

        <Panel
          title={`Daftar Perangkat (${rows.length})`}
          actions={
            selectedIds.length > 0 && (
              <span className="flex items-center gap-2 text-xs">
                {selectedIds.length} dipilih
                <Button size="small" type="primary" loading={bulkBusy} onClick={() => void bulkTest()}>
                  Uji Koneksi
                </Button>
                <Button size="small" type="text" onClick={() => setSelection([])}>
                  Batal pilih
                </Button>
              </span>
            )
          }
        >
          <DeviceTable
            rows={rows}
            loading={isLoading}
            isAdmin={isAdmin}
            selection={selection}
            paging={paging}
            onSelectionChange={setSelection}
            onPagingChange={setPaging}
            onEdit={handleEdit}
            onTest={handleTest}
            onPairing={handlePairing}
            onDelete={handleDelete}
          />
        </Panel>
      </div>

      <div className="min-w-0">
        <AddDeviceWizard devices={devices} isAdmin={isAdmin} />
      </div>

      <ConnectionTestModal device={testing} onClose={() => setTesting(null)} />
      <PairingQrModal device={pairing} onClose={() => setPairing(null)} />
      <EditDeviceModal device={editing} onClose={() => setEditing(null)} />
    </div>
  );
};

export default PerangkatPage;
