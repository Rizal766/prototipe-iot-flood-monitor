import { useMemo, useRef, useState } from "react";
import { Spin } from "antd";
import { ControlOutlined } from "@ant-design/icons";
import AmbangEditor from "@/components/ambang/AmbangEditor";
import ApplyTemplateModal from "@/components/ambang/ApplyTemplateModal";
import { useAlertConfigMutations, useAlertConfigs } from "@/hooks/useAlertConfigs";
import { useSensors } from "@/hooks/useSensors";
import { useAuthStore } from "@/stores/useAuthStore";
import { UserRole } from "@/types/auth";
import type { IAlertConfigPayload } from "@/types/alertConfig";
import { buildDefaultConfig } from "@/utils/alertConfigDefaults";
import { DEFAULT_THRESHOLDS, type IThresholds } from "@/utils/thresholds";

const AmbangPage = () => {
  const isAdmin = useAuthStore((s) => s.user?.role === UserRole.ADMIN);
  const { data: sensorData } = useSensors({ page: 1, limit: 100 });
  const sensors = useMemo(() => sensorData?.data ?? [], [sensorData]);
  const { data: cfgData } = useAlertConfigs();
  const configs = useMemo(() => cfgData?.data ?? [], [cfgData]);
  const { save, apply } = useAlertConfigMutations();

  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [applyFor, setApplyFor] = useState<IThresholds | null>(null);
  const [notice, setNotice] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout>>();

  const sensor = sensors.find((s) => s.id === selectedId) ?? sensors[0];
  const config = useMemo(
    () => (sensor ? (configs.find((c) => c.sensorId === sensor.id) ?? buildDefaultConfig(sensor.id, DEFAULT_THRESHOLDS, "-")) : null),
    [configs, sensor],
  );

  const handleSave = async (payload: IAlertConfigPayload) => {
    if (!sensor) return;
    const res = await save.mutateAsync({ sensorId: sensor.id, payload });
    if (res.status) {
      setNotice(true);
      clearTimeout(timer.current);
      timer.current = setTimeout(() => setNotice(false), 6000);
    }
  };

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-3">
        <ControlOutlined className="text-3xl text-slate-700" />
        <div>
          <h1 className="m-0 text-lg font-bold leading-tight">Pengaturan Ambang Batas & Aturan Alert</h1>
          <p className="m-0 text-xs text-slate-500">
            Tentukan kapan sensor dianggap Waspada, Siaga, atau Bahaya, dan siapa yang diberi tahu lewat saluran apa.
          </p>
        </div>
      </div>

      {!sensor || !config ? (
        <Spin className="mt-10 block" />
      ) : (
        <AmbangEditor
          key={`${sensor.id}-${config.updatedAt}`}
          sensors={sensors}
          sensor={sensor}
          config={config}
          isAdmin={isAdmin}
          saving={save.isPending}
          savedNotice={notice}
          onDismissNotice={() => setNotice(false)}
          onSelectSensor={(id) => {
            setNotice(false);
            setSelectedId(id);
          }}
          onSave={handleSave}
          onApplyMany={setApplyFor}
        />
      )}

      <ApplyTemplateModal
        thresholds={applyFor}
        sensors={sensors}
        currentId={sensor?.id ?? -1}
        loading={apply.isPending}
        onClose={() => setApplyFor(null)}
        onApply={(ids) => {
          if (applyFor) apply.mutate({ sensorIds: ids, thresholds: applyFor }, { onSuccess: () => setApplyFor(null) });
        }}
      />
    </div>
  );
};

export default AmbangPage;
