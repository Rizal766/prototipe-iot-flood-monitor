import { useCallback, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Alert, Button, Modal } from "antd";
import { BellOutlined } from "@ant-design/icons";
import type { GridPaginationModel, GridRowSelectionModel } from "@mui/x-data-grid";
import AlertBottomCards from "@/components/notifikasi/AlertBottomCards";
import AlertFilters, { DEFAULT_ALERT_FILTERS, type IAlertFilters } from "@/components/notifikasi/AlertFilters";
import { AlertDetailModal, AssignModal } from "@/components/notifikasi/AlertModals";
import AlertTable from "@/components/notifikasi/AlertTable";
import { useNotificationMutations, useNotifications } from "@/hooks/useNotifications";
import { useAuthStore } from "@/stores/useAuthStore";
import { UserRole } from "@/types/auth";
import { AlertStatus, type INotification } from "@/types/notification";

type Tab = "ALL" | AlertStatus;

const TABS: { key: Tab; label: string }[] = [
  { key: "ALL", label: "Semua" },
  { key: AlertStatus.BELUM, label: "Belum di tangani" },
  { key: AlertStatus.DIPROSES, label: "Diproses" },
  { key: AlertStatus.SELESAI, label: "Selesai" },
];

const NotifikasiPage = () => {
  const user = useAuthStore((s) => s.user);
  const isAdmin = user?.role === UserRole.ADMIN;
  const actor = user?.name ?? "Admin";

  const { data, isLoading, isError, refetch } = useNotifications();
  const { update, remove } = useNotificationMutations();
  const all = useMemo(() => data?.data ?? [], [data]);

  const [tab, setTab] = useState<Tab>("ALL");
  // ?sensor=KODE membuka halaman ini dengan filter sensor (dipakai dari halaman detail sensor)
  const [params] = useSearchParams();
  const [draft, setDraft] = useState<IAlertFilters>(() => ({ ...DEFAULT_ALERT_FILTERS, sensor: params.get("sensor") ?? "ALL" }));
  const [applied, setApplied] = useState<IAlertFilters>(() => ({ ...DEFAULT_ALERT_FILTERS, sensor: params.get("sensor") ?? "ALL" }));
  const [selection, setSelection] = useState<GridRowSelectionModel>([]);
  const [paging, setPaging] = useState<GridPaginationModel>({ page: 0, pageSize: 10 });
  const [detail, setDetail] = useState<INotification | null>(null);
  const [assignIds, setAssignIds] = useState<number[] | null>(null);

  const counts = useMemo(
    () => ({
      ALL: all.length,
      [AlertStatus.BELUM]: all.filter((n) => n.status === AlertStatus.BELUM).length,
      [AlertStatus.DIPROSES]: all.filter((n) => n.status === AlertStatus.DIPROSES).length,
      [AlertStatus.SELESAI]: all.filter((n) => n.status === AlertStatus.SELESAI).length,
    }),
    [all],
  );

  const sensorCodes = useMemo(() => [...new Set(all.map((n) => n.sensorCode))].sort(), [all]);
  const unhandled = useMemo(() => all.filter((n) => n.status === AlertStatus.BELUM), [all]);

  const rows = useMemo(() => {
    const [from, to] = applied.range ? [applied.range[0].startOf("day").valueOf(), applied.range[1].endOf("day").valueOf()] : [null, null];
    return all
      .filter((n) => tab === "ALL" || n.status === tab)
      .filter((n) => applied.level === "ALL" || n.level === applied.level)
      .filter((n) => applied.sensor === "ALL" || n.sensorCode === applied.sensor)
      .filter((n) => applied.type === "ALL" || n.type === applied.type)
      .filter((n) => {
        if (from === null || to === null) return true;
        const t = new Date(n.createdAt).getTime();
        return t >= from && t <= to;
      })
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }, [all, tab, applied]);

  const selectedIds = useMemo(
    () => rows.filter((r) => selection.includes(r.id)).map((r) => r.id),
    [rows, selection],
  );

  const goToPage1 = () => setPaging((p) => ({ ...p, page: 0 }));

  const handleSetStatus = useCallback(
    (ids: number[], status: AlertStatus) => {
      update.mutate({
        ids,
        patch: status === AlertStatus.DIPROSES ? { status, officerIfEmpty: actor } : { status },
      });
      setSelection([]);
    },
    [update, actor],
  );

  const handleAssign = useCallback((ids: number[]) => setAssignIds(ids), []);
  const handleDetail = useCallback((n: INotification) => setDetail(n), []);

  const handleDelete = useCallback(
    (n: INotification) => {
      Modal.confirm({
        title: "Hapus alert ini?",
        content: `${n.title} (${n.sensorCode})`,
        okText: "Hapus",
        okButtonProps: { danger: true },
        cancelText: "Batal",
        onOk: () => remove.mutateAsync(n.id),
      });
    },
    [remove],
  );

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-3">
        <BellOutlined className="text-3xl text-slate-700" />
        <div>
          <h1 className="m-0 text-lg font-bold leading-tight">Notifikasi & Alert</h1>
          <p className="m-0 text-xs text-slate-500">Informasi kondisi seluruh sensor IoT</p>
        </div>
      </div>

      <div className="flex gap-1 overflow-x-auto rounded-lg border border-slate-200 bg-white px-2 shadow-sm" role="tablist">
        {TABS.map((t) => (
          <button
            key={t.key}
            type="button"
            role="tab"
            aria-selected={tab === t.key}
            onClick={() => {
              setTab(t.key);
              goToPage1();
            }}
            className={`flex shrink-0 cursor-pointer items-center gap-2 border-x-0 border-t-0 bg-transparent px-4 py-3 text-sm font-medium ${
              tab === t.key ? "border-b-2 border-blue-600 text-blue-600" : "border-b-2 border-transparent text-slate-600"
            }`}
          >
            {t.label}
            <span
              className={`rounded-full px-2 py-0.5 text-[11px] font-semibold text-white ${
                t.key === AlertStatus.BELUM ? "bg-red-500" : "bg-blue-500"
              }`}
            >
              {counts[t.key]}
            </span>
          </button>
        ))}
      </div>

      <AlertFilters
        draft={draft}
        sensorCodes={sensorCodes}
        onChange={setDraft}
        onApply={() => {
          setApplied(draft);
          goToPage1();
        }}
        onReset={() => {
          setDraft(DEFAULT_ALERT_FILTERS);
          setApplied(DEFAULT_ALERT_FILTERS);
          goToPage1();
        }}
      />

      {isError && (
        <Alert
          type="error"
          showIcon
          message="Gagal memuat notifikasi"
          action={<Button size="small" onClick={() => void refetch()}>Coba lagi</Button>}
        />
      )}

      <section className="rounded-lg border border-slate-200 bg-white p-3 shadow-sm">
        <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
          <h2 className="m-0 text-sm font-semibold">Daftar alert({rows.length})</h2>
          {selectedIds.length > 0 && (
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span>{selectedIds.length} dipilih</span>
              <Button size="small" type="primary" onClick={() => handleSetStatus(selectedIds, AlertStatus.DIPROSES)}>
                Tandai Diproses
              </Button>
              <Button size="small" type="primary" onClick={() => handleSetStatus(selectedIds, AlertStatus.SELESAI)}>
                Tandai Selesai
              </Button>
              <Button size="small" onClick={() => handleAssign(selectedIds)}>
                Tugaskan
              </Button>
              <Button size="small" type="text" onClick={() => setSelection([])}>
                Batal pilih
              </Button>
            </div>
          )}
        </div>

        <AlertTable
          rows={rows}
          loading={isLoading}
          isAdmin={isAdmin}
          selection={selection}
          paging={paging}
          onSelectionChange={setSelection}
          onPagingChange={setPaging}
          onSetStatus={handleSetStatus}
          onAssign={handleAssign}
          onDetail={handleDetail}
          onDelete={handleDelete}
        />
      </section>

      <AlertBottomCards
        all={all}
        unhandled={unhandled}
        onShowUnhandled={() => {
          setTab(AlertStatus.BELUM);
          goToPage1();
        }}
        onDetail={handleDetail}
      />

      <AlertDetailModal alert={detail} onClose={() => setDetail(null)} onSetStatus={handleSetStatus} />
      <AssignModal
        ids={assignIds}
        onClose={() => setAssignIds(null)}
        onAssign={(ids, officer) => {
          update.mutate({ ids, patch: { officer, statusIfBelum: AlertStatus.DIPROSES } });
          setSelection([]);
        }}
      />
    </div>
  );
};

export default NotifikasiPage;
