import { useCallback, useMemo, useState } from "react";
import { Alert, Button, DatePicker, Input, Modal, Select } from "antd";
import { BookOutlined, SearchOutlined } from "@ant-design/icons";
import type { GridPaginationModel } from "@mui/x-data-grid";
import type { Dayjs } from "dayjs";
import ReportBottomCards from "@/components/laporan/ReportBottomCards";
import ReportBuilder from "@/components/laporan/ReportBuilder";
import { ReportPreviewModal } from "@/components/laporan/ReportPreview";
import ReportStats from "@/components/laporan/ReportStats";
import ReportTable from "@/components/laporan/ReportTable";
import Panel from "@/components/dashboard/Panel";
import { useReportDownload, type ReportFormat } from "@/hooks/useReportDownload";
import { useReportMutations, useReports } from "@/hooks/useReports";
import { useSensors } from "@/hooks/useSensors";
import { useAuthStore } from "@/stores/useAuthStore";
import { UserRole } from "@/types/auth";
import { REPORT_TYPE_LABEL, ReportType, type IReport, type IReportParams } from "@/types/report";

const PAGE_SIZE = 6;

const toParams = (r: IReport): IReportParams => ({
  type: r.type,
  from: r.from,
  to: r.to,
  sensorIds: r.sensorIds,
  areaLabel: r.areaLabel,
  includes: r.includes,
});

const LaporanPage = () => {
  const user = useAuthStore((s) => s.user);
  const isAdmin = user?.role === UserRole.ADMIN;

  const { data, isLoading, isError, refetch } = useReports();
  const reports = useMemo(() => data?.data ?? [], [data]);
  const { data: sensorData } = useSensors({ page: 1, limit: 100 });
  const sensors = useMemo(() => sensorData?.data ?? [], [sensorData]);

  const { retry, remove } = useReportMutations();
  const { download, busy } = useReportDownload();

  const [search, setSearch] = useState("");
  const [type, setType] = useState<ReportType | "ALL">("ALL");
  const [range, setRange] = useState<[Dayjs, Dayjs] | null>(null);
  const [paging, setPaging] = useState<GridPaginationModel>({ page: 0, pageSize: PAGE_SIZE });
  const [template, setTemplate] = useState<IReport | null>(null);
  const [templateKey, setTemplateKey] = useState(0);
  const [previewParams, setPreviewParams] = useState<{ params: IReportParams; creator: string } | null>(null);

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase();
    const [from, to] = range ? [range[0].startOf("day").valueOf(), range[1].endOf("day").valueOf()] : [null, null];
    return reports
      .filter((r) => type === "ALL" || r.type === type)
      .filter((r) => !q || r.name.toLowerCase().includes(q))
      .filter((r) => {
        if (from === null || to === null) return true;
        const t = new Date(r.createdAt).getTime();
        return t >= from && t <= to;
      })
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }, [reports, search, type, range]);

  const goToPage1 = () => setPaging((p) => ({ ...p, page: 0 }));
  const scrollToBuilder = () =>
    document.getElementById("report-builder")?.scrollIntoView({ behavior: "smooth", block: "start" });

  const handleDownload = useCallback(
    (r: IReport, f: ReportFormat) => void download(String(r.id), toParams(r), f, r.createdBy),
    [download],
  );
  const handleRetry = useCallback((id: number) => retry.mutate(id), [retry]);
  const handlePreview = useCallback((r: IReport) => setPreviewParams({ params: toParams(r), creator: r.createdBy }), []);
  const handleTemplate = useCallback((r: IReport) => {
    setTemplate(r);
    setTemplateKey((k) => k + 1);
    setTimeout(() => document.getElementById("report-builder")?.scrollIntoView({ behavior: "smooth", block: "start" }), 50);
  }, []);
  const handleDelete = useCallback(
    (r: IReport) => {
      Modal.confirm({
        title: "Hapus laporan ini?",
        content: r.name,
        okText: "Hapus",
        okButtonProps: { danger: true },
        cancelText: "Batal",
        onOk: () => remove.mutateAsync(r.id),
      });
    },
    [remove],
  );

  return (
    <div className="grid grid-cols-1 gap-3 xl:grid-cols-[minmax(0,1fr)_340px]">
      <div className="flex min-w-0 flex-col gap-3">
        <div className="flex items-center gap-3">
          <BookOutlined className="text-3xl text-slate-700" />
          <div>
            <h1 className="m-0 text-lg font-bold leading-tight">Laporan</h1>
            <p className="m-0 text-xs text-slate-500">
              Kelola dan buat laporan monitoring banjir untuk pimpinan dan instansi terkait.
            </p>
          </div>
        </div>

        {isError && (
          <Alert
            type="error"
            showIcon
            message="Gagal memuat daftar laporan"
            action={<Button size="small" onClick={() => void refetch()}>Coba lagi</Button>}
          />
        )}

        <ReportStats reports={reports} />

        <Panel title="Daftar Laporan Tersimpan">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <Input
              allowClear
              className="min-w-[200px] flex-1"
              prefix={<SearchOutlined />}
              placeholder="Cari nama laporan..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                goToPage1();
              }}
            />
            <DatePicker.RangePicker
              value={range}
              placeholder={["Semua tanggal", "Semua tanggal"]}
              onChange={(v) => {
                setRange(v && v[0] && v[1] ? [v[0], v[1]] : null);
                goToPage1();
              }}
            />
            <Select
              className="w-40"
              value={type}
              onChange={(v: ReportType | "ALL") => {
                setType(v);
                goToPage1();
              }}
              options={[
                { value: "ALL", label: "Semua Jenis" },
                ...Object.values(ReportType).map((t) => ({ value: t, label: REPORT_TYPE_LABEL[t] })),
              ]}
            />
          </div>

          <ReportTable
            rows={rows}
            loading={isLoading}
            isAdmin={isAdmin}
            busy={busy}
            paging={paging}
            onPagingChange={setPaging}
            onDownload={handleDownload}
            onRetry={handleRetry}
            onPreview={handlePreview}
            onTemplate={handleTemplate}
            onDelete={handleDelete}
          />
        </Panel>

        <ReportBottomCards reports={reports} onCreate={scrollToBuilder} onRetry={handleRetry} />
      </div>

      <div>
        <ReportBuilder
          key={templateKey}
          sensors={sensors}
          template={template}
          onPreview={(params) => setPreviewParams({ params, creator: user?.name ?? "Admin" })}
        />
      </div>

      <ReportPreviewModal
        params={previewParams?.params ?? null}
        creator={previewParams?.creator ?? "Admin"}
        onClose={() => setPreviewParams(null)}
      />
    </div>
  );
};

export default LaporanPage;
