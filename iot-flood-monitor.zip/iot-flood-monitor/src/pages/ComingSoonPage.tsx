const ComingSoonPage = ({ title }: { title: string }) => (
  <div className="rounded-lg border border-dashed border-slate-300 bg-white p-8 text-center">
    <h2 className="m-0 text-lg font-semibold">{title}</h2>
    <p className="mt-1 text-slate-500">Halaman ini belum dibuat.</p>
  </div>
);

export default ComingSoonPage;
