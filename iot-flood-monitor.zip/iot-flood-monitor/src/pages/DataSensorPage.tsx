import { useCallback, useMemo, useState } from "react";
import { Alert, Button, Modal } from "antd";
import { PlusOutlined, WifiOutlined } from "@ant-design/icons";
import type { GridPaginationModel, GridRowSelectionModel } from "@mui/x-data-grid";
import { useNavigate } from "react-router-dom";
import SensorForm from "@/components/SensorForm";
import SensorStats from "@/components/data-sensor/SensorStats";
import SensorTable from "@/components/data-sensor/SensorTable";
import SensorToolbar, { ALL, DEFAULT_FILTERS, type ISensorFilters } from "@/components/data-sensor/SensorToolbar";
import { useSensorMutations } from "@/hooks/useSensorMutations";
import { useSensors } from "@/hooks/useSensors";
import { toPayload, type SensorFormValues } from "@/schemas/sensorSchema";
import { useAuthStore } from "@/stores/useAuthStore";
import { UserRole } from "@/types/auth";
import type { StatusFilter } from "@/types/map";
import { FloodStatus, type ISensor } from "@/types/sensor";
import { downloadSensorCsv } from "@/utils/csv";

const ISSUE_STATUSES: FloodStatus[] = [FloodStatus.BAHAYA, FloodStatus.SIAGA, FloodStatus.WASPADA, FloodStatus.OFFLINE];

const DataSensorPage = () => {
  const navigate = useNavigate();
  const isAdmin = useAuthStore((s) => s.user?.role === UserRole.ADMIN);

  const { data, isLoading, isError, isFetching, refetch } = useSensors({ page: 1, limit: 100 });
  const all = useMemo(() => data?.data ?? [], [data]);

  const [filters, setFilters] = useState<ISensorFilters>(DEFAULT_FILTERS);
  const [selection, setSelection] = useState<GridRowSelectionModel>([]);
  const [paging, setPaging] = useState<GridPaginationModel>({ page: 0, pageSize: 10 });
  const [editing, setEditing] = useState<ISensor | "new" | null>(null);

  const { create, update } = useSensorMutations(() => setEditing(null));

  const patchFilters = useCallback((patch: Partial<ISensorFilters>) => {
    setFilters((f) => ({ ...f, ...patch }));
    setPaging((p) => ({ ...p, page: 0 }));
  }, []);

  const counts = useMemo(() => {
    const c: Record<StatusFilter, number> = {
      ALL: all.length,
      [FloodStatus.AMAN]: 0,
      [FloodStatus.WASPADA]: 0,
      [FloodStatus.SIAGA]: 0,
      [FloodStatus.BAHAYA]: 0,
      [FloodStatus.OFFLINE]: 0,
    };
    all.forEach((s) => {
      c[s.status] += 1;
    });
    return c;
  }, [all]);

  const rivers = useMemo(() => [...new Set(all.map((s) => s.river))].sort(), [all]);
  const districts = useMemo(() => [...new Set(all.map((s) => s.district))].sort(), [all]);

  const filtered = useMemo(() => {
    const q = filters.search.trim().toLowerCase();
    return all
      .filter((s) => filters.status === "ALL" || s.status === filters.status)
      .filter((s) => filters.river === ALL || s.river === filters.river)
      .filter((s) => filters.district === ALL || s.district === filters.district)
      .filter((s) => !filters.onlyIssues || ISSUE_STATUSES.includes(s.status))
      .filter((s) => !q || [s.code, s.location, s.river, s.district].some((f) => f.toLowerCase().includes(q)));
  }, [all, filters]);

  // Hanya hitung baris terpilih yang masih tampil pada hasil filter
  const selectedRows = useMemo(
    () => filtered.filter((s) => selection.includes(s.id)),
    [filtered, selection],
  );

  const handleView = useCallback((s: ISensor) => navigate(`/sensors/${s.id}`), [navigate]);

  const handleEdit = useCallback((s: ISensor) => setEditing(s), []);

  const handleSubmit = (values: SensorFormValues) => {
    const payload = toPayload(values);
    if (editing === "new") create.mutate(payload);
    else if (editing) update.mutate({ id: editing.id, payload });
  };

  const toggleSelectAll = () =>
    setSelection(selectedRows.length === filtered.length ? [] : filtered.map((s) => s.id));

  const editingSensor = editing && editing !== "new" ? editing : null;

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div className="flex items-center gap-3">
          <WifiOutlined className="text-3xl text-slate-700" />
          <div>
            <h1 className="m-0 text-lg font-bold leading-tight">Data Sensor</h1>
            <p className="m-0 text-xs text-slate-500">Total sensor terdaftar: {all.length}</p>
          </div>
        </div>
        <div className="text-right">
          <Button type="primary" icon={<PlusOutlined />} disabled={!isAdmin} onClick={() => setEditing("new")}>
            Tambah Sensor
          </Button>
          <p className="m-0 mt-0.5 text-[10px] text-slate-400">(Hanya Admin)</p>
        </div>
      </div>

      {isError && (
        <Alert
          type="error"
          showIcon
          message="Gagal memuat data sensor"
          action={<Button size="small" onClick={() => void refetch()}>Coba lagi</Button>}
        />
      )}

      <SensorStats counts={counts} active={filters.status} onSelect={(s) => patchFilters({ status: s })} />

      <SensorToolbar
        filters={filters}
        rivers={rivers}
        districts={districts}
        refreshing={isFetching}
        onChange={patchFilters}
        onRefresh={() => void refetch()}
        onExport={() => downloadSensorCsv(filtered)}
      />

      <SensorTable
        rows={filtered}
        loading={isLoading}
        selection={selection}
        selectedCount={selectedRows.length}
        paging={paging}
        canEdit={isAdmin}
        onSelectionChange={setSelection}
        onPagingChange={setPaging}
        onToggleSelectAll={toggleSelectAll}
        onExportSelected={() => downloadSensorCsv(selectedRows)}
        onView={handleView}
        onEdit={handleEdit}
      />

      <Modal
        open={editing !== null}
        title={editingSensor ? `Edit Sensor #${editingSensor.code}` : "Tambah Sensor"}
        footer={null}
        onCancel={() => setEditing(null)}
        width={560}
      >
        {editing !== null && (
          <SensorForm
            key={editingSensor?.id ?? "new"}
            lockCode={Boolean(editingSensor)}
            loading={create.isPending || update.isPending}
            submitLabel={editingSensor ? "Simpan Perubahan" : "Tambah Sensor"}
            defaultValues={
              editingSensor
                ? {
                    code: editingSensor.code,
                    location: editingSensor.location,
                    river: editingSensor.river,
                    district: editingSensor.district,
                    lat: String(editingSensor.lat),
                    lng: String(editingSensor.lng),
                  }
                : undefined
            }
            onSubmit={handleSubmit}
          />
        )}
      </Modal>
    </div>
  );
};

export default DataSensorPage;
