import { Button, Input, message } from "antd";
import { LockOutlined, MailOutlined } from "@ant-design/icons";
import { Controller, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Navigate, useNavigate } from "react-router-dom";
import DropLogo from "@/components/DropLogo";
import { login } from "@/api/authApi";
import { USE_MOCK } from "@/api/mock";
import { loginSchema, type LoginFormValues } from "@/schemas/loginSchema";
import { useAuthStore } from "@/stores/useAuthStore";

const LoginPage = () => {
  const navigate = useNavigate();
  const token = useAuthStore((s) => s.token);
  const setSession = useAuthStore((s) => s.setSession);

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: { identifier: "", password: "" },
  });

  const { mutate, isPending } = useMutation({
    mutationFn: login,
    onSuccess: (res) => {
      if (res.status && res.data) {
        setSession(res.data.token, res.data.user);
        navigate("/", { replace: true });
      } else {
        message.error(res.message || "Login gagal");
      }
    },
    onError: () => message.error("Email/No. Telepon atau password salah"),
  });

  if (token) return <Navigate to="/" replace />;

  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-5 bg-[#f4f7fd] px-4">
      <DropLogo size={44} />

      <form
        onSubmit={handleSubmit((v) => mutate(v))}
        className="w-full max-w-md rounded-md bg-blue-500 px-6 py-6 shadow-md sm:px-10"
        noValidate
      >
        <h1 className="m-0 text-center text-2xl font-semibold text-white">IoT Flood Monitor</h1>
        <p className="mb-6 mt-1 text-center text-[10px] text-blue-100">Early Warning System</p>

        <div className="mb-3">
          <Controller
            name="identifier"
            control={control}
            render={({ field }) => (
              <Input
                {...field}
                size="large"
                variant="filled"
                prefix={<MailOutlined className="text-xl text-slate-600" />}
                placeholder="Email / No.Telepon"
                autoComplete="username"
                status={errors.identifier ? "error" : undefined}
              />
            )}
          />
          {errors.identifier && <p className="mt-1 text-xs text-white">{errors.identifier.message}</p>}
        </div>

        <div className="mb-6">
          <Controller
            name="password"
            control={control}
            render={({ field }) => (
              <Input.Password
                {...field}
                size="large"
                variant="filled"
                prefix={<LockOutlined className="text-xl text-slate-600" />}
                placeholder="Password"
                autoComplete="current-password"
                status={errors.password ? "error" : undefined}
              />
            )}
          />
          {errors.password && <p className="mt-1 text-xs text-white">{errors.password.message}</p>}
        </div>

        <Button
          type="primary"
          htmlType="submit"
          size="large"
          block
          loading={isPending}
          className="!bg-blue-600 font-semibold hover:!bg-blue-700"
        >
          Login
        </Button>

        {USE_MOCK && (
          <div className="mt-4 rounded bg-blue-600/60 p-2 text-[11px] leading-snug text-blue-50">
            <p className="m-0 font-semibold">Akun demo</p>
            <p className="m-0">Admin: admin@iotflood.id / admin123</p>
            <p className="m-0">Operator: operator@iotflood.id / operator123</p>
          </div>
        )}

        <div className="mt-4 text-center">
          <button
            type="button"
            className="cursor-pointer border-none bg-transparent text-base font-medium text-white underline"
            onClick={() => message.info("Hubungi admin untuk reset password")}
          >
            Lupa Password?
          </button>
        </div>
      </form>
    </div>
  );
};

export default LoginPage;
