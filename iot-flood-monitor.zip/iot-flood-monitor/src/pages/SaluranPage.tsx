import { useState } from "react";
import { Alert, Button, Spin, message } from "antd";
import { NotificationOutlined } from "@ant-design/icons";
import ChannelCard from "@/components/saluran/ChannelCard";
import ChannelConfigModal from "@/components/saluran/ChannelConfigModal";
import ContactsPanel from "@/components/saluran/ContactsPanel";
import EvacuationPanel from "@/components/saluran/EvacuationPanel";
import TemplatePanel from "@/components/saluran/TemplatePanel";
import { useNotificationSettings, useSettingsMutations } from "@/hooks/useNotificationSettings";
import { useAuthStore } from "@/stores/useAuthStore";
import { UserRole } from "@/types/auth";
import {
  TEMPLATE_KEYS,
  type ChannelType,
  type IChannel,
  type INotificationSettings,
  type ITemplates,
} from "@/types/notificationSettings";
import { unknownVars } from "@/utils/templateVars";
import { formatDateTime } from "@/utils/time";

const Editor = ({ settings, canEdit }: { settings: INotificationSettings; canEdit: boolean }) => {
  const { save, test } = useSettingsMutations();

  const [enabled, setEnabled] = useState<Record<ChannelType, boolean>>(
    () => Object.fromEntries(settings.channels.map((c) => [c.type, c.enabled])) as Record<ChannelType, boolean>,
  );
  const [templates, setTemplates] = useState<ITemplates>(() => structuredClone(settings.templates));
  const [configuring, setConfiguring] = useState<IChannel | null>(null);
  const [testing, setTesting] = useState<ChannelType | null>(null);

  const dirty =
    settings.channels.some((c) => enabled[c.type] !== c.enabled) ||
    JSON.stringify(templates) !== JSON.stringify(settings.templates);
  const invalid = TEMPLATE_KEYS.some(
    (k) =>
      !templates[k].title.trim() ||
      !templates[k].body.trim() ||
      unknownVars(`${templates[k].title} ${templates[k].body}`).length > 0,
  );

  const runTest = async (c: IChannel) => {
    setTesting(c.type);
    try {
      const res = await test.mutateAsync(c.type);
      if (res.status && res.data) {
        if (res.data.ok) message.success(`${c.name}: ${res.data.message}`);
        else message.error(`${c.name}: ${res.data.message}`);
      } else {
        message.error(res.message || "Uji kirim gagal");
      }
    } catch {
      message.error("Uji kirim gagal dijalankan");
    } finally {
      setTesting(null);
    }
  };

  const onSave = async () => {
    const res = await save.mutateAsync({ enabled, templates });
    if (res.status) message.success("Pengaturan notifikasi disimpan");
    else message.error(res.message || "Gagal menyimpan pengaturan");
  };

  return (
    <>
      <div className="grid grid-cols-1 gap-3 xl:grid-cols-2">
        {settings.channels.map((c) => (
          <ChannelCard
            key={c.type}
            channel={c}
            enabled={enabled[c.type]}
            canEdit={canEdit}
            testing={testing === c.type}
            onToggle={(on) => setEnabled((e) => ({ ...e, [c.type]: on }))}
            onTest={() => void runTest(c)}
            onConfig={() => setConfiguring(c)}
          />
        ))}
      </div>

      <div id="kontak-evakuasi" className="grid scroll-mt-20 grid-cols-1 items-start gap-3 xl:grid-cols-2">
        <TemplatePanel
          templates={templates}
          canEdit={canEdit}
          onChange={(key, t) => setTemplates((prev) => ({ ...prev, [key]: t }))}
        />
        <ContactsPanel canEdit={canEdit} />
      </div>
      <EvacuationPanel canEdit={canEdit} />

      <section className="flex flex-wrap items-center gap-3 rounded-lg border border-slate-200 bg-white p-3 shadow-sm">
        <Button type="primary" loading={save.isPending} disabled={!canEdit || !dirty || invalid} onClick={() => void onSave()}>
          Simpan Pengaturan
        </Button>
        <Button
          onClick={() => document.getElementById("kontak-evakuasi")?.scrollIntoView({ behavior: "smooth", block: "start" })}
        >
          Kelola Kontak & Titik Evakuasi
        </Button>
        <span className="text-[11px] text-slate-500">
          Terakhir disimpan: {formatDateTime(settings.updatedAt)} oleh {settings.updatedBy}
          {dirty && " · ada perubahan yang belum disimpan"}
        </span>
      </section>

      <ChannelConfigModal channel={configuring} onClose={() => setConfiguring(null)} />
    </>
  );
};

const SaluranPage = () => {
  const isAdmin = useAuthStore((s) => s.user?.role === UserRole.ADMIN);
  const { data, isLoading, isError, refetch } = useNotificationSettings();
  const settings = data?.data;

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-3">
        <NotificationOutlined className="text-3xl text-slate-700" />
        <div>
          <h1 className="m-0 text-lg font-bold leading-tight">Saluran Notifikasi & Kontak Darurat</h1>
          <p className="m-0 text-xs text-slate-500">
            Pastikan semua saluran notifikasi aktif agar peringatan banjir dapat diterima warga dan petugas terkait.
          </p>
        </div>
      </div>

      {!isAdmin && (
        <Alert type="info" showIcon message="Anda masuk sebagai Operator: pengaturan ini hanya dapat dilihat dan diuji. Perubahan dilakukan oleh Admin." />
      )}
      {isError && (
        <Alert
          type="error"
          showIcon
          message="Gagal memuat pengaturan notifikasi"
          action={<Button size="small" onClick={() => void refetch()}>Coba lagi</Button>}
        />
      )}

      {isLoading || !settings ? (
        isError ? null : <Spin className="mt-10 block" />
      ) : (
        <Editor key={settings.updatedAt} settings={settings} canEdit={isAdmin} />
      )}
    </div>
  );
};

export default SaluranPage;
