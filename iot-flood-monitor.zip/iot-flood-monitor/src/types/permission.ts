import { UserRole } from "./auth";

export enum Feature {
  DASHBOARD_PETA = "DASHBOARD_PETA",
  SENSOR = "SENSOR",
  RIWAYAT = "RIWAYAT",
  NOTIFIKASI = "NOTIFIKASI",
  LAPORAN = "LAPORAN",
  PENGATURAN = "PENGATURAN",
}

export const FEATURE_LABEL: Record<Feature, string> = {
  [Feature.DASHBOARD_PETA]: "Dashboard & Peta",
  [Feature.SENSOR]: "Data Sensor",
  [Feature.RIWAYAT]: "Riwayat Data",
  [Feature.NOTIFIKASI]: "Notifikasi & Alert",
  [Feature.LAPORAN]: "Laporan",
  [Feature.PENGATURAN]: "Pengaturan",
};

export const PERMISSION_ROLES: UserRole[] = [UserRole.ADMIN, UserRole.OPERATOR, UserRole.PETUGAS];

// Hak akses untuk membuka menu. Aksi ubah/hapus tetap dibatasi pada Admin.
export type IPermissionMatrix = Record<Feature, Record<UserRole, boolean>>;
