import type { FloodStatus } from "./sensor";

export interface IDashboardSummary {
  totalSensor: number;
  activeSensor: number;
  offlineSensor: number;
  riskLocations: number;
  siaga: number;
  waspada: number;
  aman: number;
  rainfall: number; // mm / 24 jam
  rainfallChange: number; // %
  waterLevel: number; // cm
  waterLevelChange: number; // %
}

export interface IAlert {
  id: number;
  sensorCode: string;
  location: string;
  message: string;
  level: FloodStatus;
  time: string;
}

export interface IForecastDay {
  label: string;
  icon: string; // emoji
  chance: number; // %
  temp: string;
}

export interface IWeather {
  temperature: number;
  condition: string;
  icon: string; // emoji
  city: string;
  forecast: IForecastDay[];
}

export interface IWaterSeries {
  code: string;
  label: string;
  color: string;
  data: number[];
}

export interface IWaterChart {
  hours: string[];
  series: IWaterSeries[];
}

export enum IntegrationType {
  SMS = "SMS",
  WHATSAPP = "WHATSAPP",
  EMAIL = "EMAIL",
  PUSH = "PUSH",
  SIREN = "SIREN",
  API = "API",
}

export interface IIntegration {
  type: IntegrationType;
  name: string;
  active: boolean;
}
