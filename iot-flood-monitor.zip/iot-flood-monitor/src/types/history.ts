import type { FloodStatus } from "./sensor";

export enum HistoryInterval {
  HOUR = "HOUR",
  SIX_HOURS = "SIX_HOURS",
  DAY = "DAY",
}

export const INTERVAL_HOURS: Record<HistoryInterval, number> = {
  [HistoryInterval.HOUR]: 1,
  [HistoryInterval.SIX_HOURS]: 6,
  [HistoryInterval.DAY]: 24,
};

export const INTERVAL_LABEL: Record<HistoryInterval, string> = {
  [HistoryInterval.HOUR]: "Per Jam",
  [HistoryInterval.SIX_HOURS]: "Per 6 Jam",
  [HistoryInterval.DAY]: "Per Hari",
};

export interface IHistoryPoint {
  t: string; // ISO
  waterLevel: number; // cm
  rainfall: number; // mm
}

export interface IHistorySeries {
  sensorId: number;
  code: string;
  location: string;
  river: string;
  district: string;
  points: IHistoryPoint[];
}

export interface IHistoryQuery {
  sensorIds: number[];
  from: string;
  to: string;
  interval: HistoryInterval;
}

export interface IHistoryRow {
  id: string;
  t: string;
  code: string;
  location: string;
  district: string;
  river: string;
  waterLevel: number;
  rainfall: number;
  status: FloodStatus;
}
