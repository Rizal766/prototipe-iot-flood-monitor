export enum FloodStatus {
  AMAN = "AMAN",
  WASPADA = "WASPADA",
  SIAGA = "SIAGA",
  BAHAYA = "BAHAYA",
  OFFLINE = "OFFLINE",
}

export interface ISensor {
  id: number;
  code: string; // contoh: BNA-003
  name: string;
  location: string;
  river: string;
  district: string; // kecamatan
  waterLevel: number; // cm
  trend: number; // cm/jam (+ naik, - turun)
  history: number[]; // 6 jam terakhir (cm)
  status: FloodStatus;
  battery: number; // %
  signal: number; // 0-4 batang
  rssi: number | null; // kekuatan sinyal (dBm)
  solar: number; // pengisian panel surya (%)
  temperature: number; // suhu perangkat (°C)
  network: string; // 4G, 3G, LoRa, atau "-"
  lastSeenMinutes: number | null; // menit sejak data terakhir diterima
  updatedAt: string; // HH:mm
  lat: number;
  lng: number;
}

export interface ISensorQuery {
  page: number;
  limit: number;
}

export interface ISensorPayload {
  code: string;
  location: string;
  river: string;
  district: string;
  lat: number;
  lng: number;
}
