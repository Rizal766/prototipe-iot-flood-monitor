export const CONTACT_CATEGORIES = [
  "Darurat Nasional",
  "Polisi",
  "Pemadam Kebakaran",
  "Ambulans",
  "SAR / Basarnas",
  "BPBD",
  "Lainnya",
] as const;

export interface IEmergencyContact {
  id: number;
  name: string;
  phone: string;
  category: string;
  showInAlert: boolean; // dicantumkan pada pesan alert
}

export type IEmergencyContactPayload = Omit<IEmergencyContact, "id">;
