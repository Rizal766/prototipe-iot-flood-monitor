export enum AlertLevel {
  TINGGI = "TINGGI",
  SEDANG = "SEDANG",
  RENDAH = "RENDAH",
  OFFLINE = "OFFLINE",
}

export enum AlertStatus {
  BELUM = "BELUM",
  DIPROSES = "DIPROSES",
  SELESAI = "SELESAI",
}

export enum AlertType {
  TINGGI_AIR = "TINGGI_AIR",
  CURAH_HUJAN = "CURAH_HUJAN",
  OFFLINE = "OFFLINE",
  BATERAI = "BATERAI",
}

export interface INotification {
  id: number;
  level: AlertLevel;
  type: AlertType;
  title: string;
  sensorCode: string;
  location: string;
  value: number | null;
  threshold: number | null;
  unit: "cm" | "mm" | "%" | "";
  createdAt: string; // ISO
  status: AlertStatus;
  officer: string | null;
  respondedAt: string | null; // ISO, saat pertama kali diproses
}

export interface INotificationPatch {
  status?: AlertStatus;
  officer?: string;
  officerIfEmpty?: string; // isi petugas hanya bila belum ada
  statusIfBelum?: AlertStatus; // ubah status hanya bila masih BELUM (mis. saat ditugaskan)
}
