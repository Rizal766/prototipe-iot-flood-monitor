import type { UserRole } from "./auth";
import type { AlertLevel, AlertStatus } from "./notification";
import type { FloodStatus } from "./sensor";

export enum ReportType {
  HARIAN = "HARIAN",
  MINGGUAN = "MINGGUAN",
  BULANAN = "BULANAN",
  KEJADIAN = "KEJADIAN",
}

export const REPORT_TYPE_LABEL: Record<ReportType, string> = {
  [ReportType.HARIAN]: "Harian",
  [ReportType.MINGGUAN]: "Mingguan",
  [ReportType.BULANAN]: "Bulanan",
  [ReportType.KEJADIAN]: "Kejadian",
};

export const REPORT_TYPE_COLOR: Record<ReportType, string> = {
  [ReportType.HARIAN]: "#3b82f6",
  [ReportType.MINGGUAN]: "#a855f7",
  [ReportType.BULANAN]: "#22c55e",
  [ReportType.KEJADIAN]: "#ef4444",
};

export enum ReportStatus {
  PROSES = "PROSES",
  SELESAI = "SELESAI",
  GAGAL = "GAGAL",
}

export enum ScheduleFrequency {
  NONE = "NONE",
  HARIAN = "HARIAN",
  MINGGUAN = "MINGGUAN",
  BULANAN = "BULANAN",
}

export const FREQUENCY_LABEL: Record<ScheduleFrequency, string> = {
  [ScheduleFrequency.NONE]: "Tidak ada",
  [ScheduleFrequency.HARIAN]: "Setiap hari",
  [ScheduleFrequency.MINGGUAN]: "Setiap minggu",
  [ScheduleFrequency.BULANAN]: "Setiap bulan",
};

export interface IReportContent {
  summary: boolean; // ringkasan status + statistik sensor
  charts: boolean;
  alerts: boolean; // daftar alert & waktu respons
  problemSensors: boolean;
}

export interface IReportSchedule {
  frequency: Exclude<ScheduleFrequency, ScheduleFrequency.NONE>;
  email: string;
}

export interface IReportParams {
  type: ReportType;
  from: string; // ISO
  to: string; // ISO
  sensorIds: number[] | null; // null = semua sensor
  areaLabel: string;
  includes: IReportContent;
}

export type IReportCreate = IReportParams & { schedule: IReportSchedule | null };

export interface IReport extends IReportParams {
  id: number;
  name: string;
  status: ReportStatus;
  progress: number; // 0-100
  createdBy: string;
  creatorRole: UserRole;
  createdAt: string; // ISO
  schedule: IReportSchedule | null;
}

// ---- Data hasil susunan laporan (dipakai preview, PDF, Excel) ----
export interface IReportSensorStat {
  sensorId: number;
  code: string;
  location: string;
  district: string;
  status: FloodStatus;
  battery: number;
  max: number;
  min: number;
  avg: number;
  hoursSiaga: number;
  rainTotal: number;
}

export interface IReportAlertRow {
  id: number;
  time: string;
  level: AlertLevel;
  title: string;
  sensorCode: string;
  status: AlertStatus;
  officer: string | null;
  responseMin: number | null;
}

export interface IReportProblem {
  code: string;
  location: string;
  issue: string;
}

export interface IReportData {
  title: string;
  typeLabel: string;
  periodLabel: string;
  areaLabel: string;
  generatedAt: string;
  createdBy: string;
  includes: IReportContent;
  summary: {
    totalSensor: number;
    activeSensor: number;
    offlineSensor: number;
    activePct: number;
    byStatus: Record<FloodStatus, number>;
    alertTotal: number;
    alertUnhandled: number;
    avgResponseMin: number | null;
    maxLevel: { code: string; value: number } | null;
  };
  times: string[];
  series: { code: string; color: string; values: number[] }[];
  sensorStats: IReportSensorStat[];
  alerts: IReportAlertRow[];
  problems: IReportProblem[];
}
