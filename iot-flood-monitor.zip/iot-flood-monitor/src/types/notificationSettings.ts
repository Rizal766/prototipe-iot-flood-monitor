export enum ChannelType {
  SMS = "SMS",
  WHATSAPP = "WHATSAPP",
  EMAIL = "EMAIL",
  PUSH = "PUSH",
  SIREN = "SIREN",
  API = "API",
}

export enum ChannelHealth {
  NORMAL = "NORMAL",
  GANGGUAN = "GANGGUAN",
}

export interface IChannelField {
  key: string;
  label: string;
  value: string; // nilai rahasia sudah disamarkan oleh server
  secret?: boolean;
}

export interface IChannel {
  type: ChannelType;
  name: string;
  enabled: boolean;
  health: ChannelHealth;
  fields: IChannelField[];
  lastDeliveryAt: string | null;
  lastTest: { ok: boolean; at: string } | null;
}

export type TemplateKey = "BAHAYA" | "SIAGA" | "WASPADA" | "NORMAL";
export const TEMPLATE_KEYS: TemplateKey[] = ["BAHAYA", "SIAGA", "WASPADA", "NORMAL"];

export const TEMPLATE_LABEL: Record<TemplateKey, string> = {
  BAHAYA: "Bahaya",
  SIAGA: "Siaga",
  WASPADA: "Waspada",
  NORMAL: "Normal",
};

export interface IMessageTemplate {
  title: string;
  body: string;
}

export type ITemplates = Record<TemplateKey, IMessageTemplate>;

export interface INotificationSettings {
  channels: IChannel[];
  templates: ITemplates;
  updatedAt: string;
  updatedBy: string;
}

export interface ISettingsSave {
  enabled: Record<ChannelType, boolean>;
  templates: ITemplates;
}

export interface IChannelTestResult {
  ok: boolean;
  message: string;
  at: string;
}
