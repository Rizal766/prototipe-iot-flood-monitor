import type { IThresholds } from "@/utils/thresholds";

export const NOTIFY_ROLES = ["admin", "operator", "petugas", "bpbd"] as const;
export const NOTIFY_CHANNELS = ["push", "sms", "whatsapp", "email", "sirene"] as const;

export type NotifyRole = (typeof NOTIFY_ROLES)[number];
export type NotifyChannel = (typeof NOTIFY_CHANNELS)[number];
export type AlertTier = "WASPADA" | "SIAGA" | "BAHAYA";

export const ALERT_TIERS: AlertTier[] = ["WASPADA", "SIAGA", "BAHAYA"];

export const ROLE_TEXT: Record<NotifyRole, string> = {
  admin: "Admin",
  operator: "Operator",
  petugas: "Petugas Lapangan",
  bpbd: "BPBD",
};

export const CHANNEL_TEXT: Record<NotifyChannel, string> = {
  push: "Push",
  sms: "SMS",
  whatsapp: "WhatsApp",
  email: "Email",
  sirene: "Sirene",
};

export type IAlertTarget = Record<NotifyRole | NotifyChannel, boolean>;
export type IAlertMatrix = Record<AlertTier, IAlertTarget>;

export interface IAlertRules {
  rainfallMmPerHour: number;
  offlineMinutes: number;
  batteryPercent: number;
}

export interface IAlertConfig {
  sensorId: number;
  thresholds: IThresholds;
  rules: IAlertRules;
  matrix: IAlertMatrix;
  updatedAt: string; // ISO
  updatedBy: string;
}

export type IAlertConfigPayload = Omit<IAlertConfig, "sensorId" | "updatedAt" | "updatedBy">;
