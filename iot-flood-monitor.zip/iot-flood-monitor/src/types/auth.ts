export interface ILoginPayload {
  identifier: string; // email atau no. telepon
  password: string;
}

export enum UserRole {
  ADMIN = "ADMIN",
  OPERATOR = "OPERATOR",
  PETUGAS = "PETUGAS",
}

export const ROLE_LABEL: Record<UserRole, string> = {
  [UserRole.ADMIN]: "Administrator",
  [UserRole.OPERATOR]: "Operator",
  [UserRole.PETUGAS]: "Petugas Lapangan",
};

export interface IAuthUser {
  id: number;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string | null; // foto profil (data URL)
}

export interface ILoginResult {
  token: string;
  user: IAuthUser;
}

// Akun demo (hanya dipakai saat VITE_USE_MOCK=true). Nama akun tetap: "Admin" dan "Operator".
export const DEMO_ACCOUNTS: { identifiers: string[]; password: string; user: IAuthUser }[] = [
  {
    identifiers: ["admin@iotflood.id", "081200000001"],
    password: "admin123",
    user: { id: 1, name: "Admin", email: "admin@iotflood.id", role: UserRole.ADMIN },
  },
  {
    identifiers: ["operator@iotflood.id", "081200000002"],
    password: "operator123",
    user: { id: 2, name: "Operator", email: "operator@iotflood.id", role: UserRole.OPERATOR },
  },
];
