import type { UserRole } from "./auth";

export interface IProfile {
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  avatar: string | null;
  lastLogin: string | null;
}

export interface IProfileUpdate {
  name: string;
  phone: string;
}

export interface IPasswordChange {
  oldPassword: string;
  newPassword: string;
  signOutOthers: boolean;
}

export interface ISession {
  id: string;
  device: string; // contoh: Windows Chrome
  ip: string;
  location: string;
  lastActive: string; // ISO
  current: boolean;
}

export interface IPreferences {
  floodAlert: boolean;
  systemInfo: boolean;
  dailyReport: boolean;
  email: boolean;
  sms: boolean;
  whatsapp: boolean;
}
