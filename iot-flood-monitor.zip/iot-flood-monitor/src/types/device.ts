import type { IThresholds } from "@/utils/thresholds";

export enum DeviceKind {
  WATER_LEVEL = "WATER_LEVEL",
  RAIN_GAUGE = "RAIN_GAUGE",
}

export const DEVICE_KIND_LABEL: Record<DeviceKind, string> = {
  [DeviceKind.WATER_LEVEL]: "Water Level",
  [DeviceKind.RAIN_GAUGE]: "Rain Gauge",
};

export const DEVICE_KIND_ICON: Record<DeviceKind, string> = {
  [DeviceKind.WATER_LEVEL]: "💧",
  [DeviceKind.RAIN_GAUGE]: "🌧️",
};

export enum DeviceConnection {
  ONLINE = "ONLINE",
  OFFLINE = "OFFLINE",
  MAINTENANCE = "MAINTENANCE",
}

export const CONNECTION_META: Record<DeviceConnection, { label: string; color: string }> = {
  [DeviceConnection.ONLINE]: { label: "Online", color: "#22c55e" },
  [DeviceConnection.OFFLINE]: { label: "Offline", color: "#ef4444" },
  [DeviceConnection.MAINTENANCE]: { label: "Maintenance", color: "#f59e0b" },
};

export interface IDevice {
  id: number;
  sensorId: number; // sensor yang terhubung dengan perangkat ini
  sensorCode: string;
  deviceId: string; // DEV-001
  name: string; // nama lokasi
  kind: DeviceKind;
  guid: string; // GUID / Kit ID, contoh GK-001-7789
  firmware: string;
  connection: DeviceConnection;
  lastSeen: string | null; // ISO
  river: string;
  district: string;
  lat: number;
  lng: number;
  host: string;
  officer: string | null;
  photo: string | null;
  registeredAt: string; // ISO
}

export interface IDevicePayload {
  deviceId: string;
  name: string;
  kind: DeviceKind;
  guid: string;
  firmware: string;
  river: string;
  district: string;
  lat: number;
  lng: number;
  officer: string | null;
  photo: string | null;
  thresholds: IThresholds;
}

export type IDeviceUpdate = Pick<
  IDevicePayload,
  "name" | "river" | "district" | "lat" | "lng" | "guid" | "firmware" | "officer"
>;

export interface IConnectionTest {
  ok: boolean;
  testedAt: string;
  latencyMs: number | null;
  host: string;
  stream: string;
  status: string;
  guid: string;
  message: string;
}

export interface IPairing {
  deviceId: string;
  payload: string; // isi QR
  expiresAt: string;
}
