import type { UserRole } from "./auth";

export enum UserStatus {
  AKTIF = "AKTIF",
  NONAKTIF = "NONAKTIF",
}

export interface IUser {
  id: number;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  areas: string[]; // wilayah tugas (kecamatan); kosong = semua wilayah
  status: UserStatus;
  lastLogin: string | null; // ISO
}

export interface IUserPayload {
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  areas: string[];
  status: UserStatus;
}

export enum InviteStatus {
  MENUNGGU = "MENUNGGU",
  DITERIMA = "DITERIMA",
  KEDALUWARSA = "KEDALUWARSA",
  GAGAL = "GAGAL",
}

export const INVITE_META: Record<InviteStatus, { label: string; color: string }> = {
  [InviteStatus.MENUNGGU]: { label: "Menunggu", color: "#f59e0b" },
  [InviteStatus.DITERIMA]: { label: "Diterima", color: "#16a34a" },
  [InviteStatus.KEDALUWARSA]: { label: "Kedaluwarsa", color: "#64748b" },
  [InviteStatus.GAGAL]: { label: "Gagal terkirim", color: "#ef4444" },
};

export interface IInvitation {
  id: number;
  name: string;
  target: string; // email atau nomor HP
  role: UserRole;
  areas: string[];
  sentAt: string; // ISO
  status: InviteStatus;
  viaEmail: boolean;
}

export interface IInvitationCreate {
  name: string;
  target: string;
  role: UserRole;
  areas: string[];
  viaEmail: boolean;
}

// Wilayah tempat warga terdaftar menerima peringatan publik
export interface IArea {
  district: string;
  residents: number;
  active: boolean;
}
