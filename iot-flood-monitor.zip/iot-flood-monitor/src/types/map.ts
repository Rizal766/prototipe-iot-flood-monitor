import type { FloodStatus } from "./sensor";

export enum MapLayer {
  RIVER = "RIVER",
  DISTRICT = "DISTRICT",
  EVACUATION = "EVACUATION",
  RADAR = "RADAR",
}

export type BaseMap = "peta" | "satelit";
export type StatusFilter = FloodStatus | "ALL";

export interface IGeoPoint {
  lat: number;
  lng: number;
}

export interface IEvacuationPoint extends IGeoPoint {
  id: number;
  name: string;
  address: string;
  capacity: number;
  active: boolean; // titik aktif tampil di peta dan pesan evakuasi
}

export type IEvacuationPayload = Omit<IEvacuationPoint, "id">;

export interface IBBox {
  south: number;
  west: number;
  north: number;
  east: number;
}
