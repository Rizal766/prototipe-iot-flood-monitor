import { axiosInstance } from "./axios";
import { USE_MOCK, mockResponse } from "./mock";
import { thresholdsOf } from "@/mocks/alertConfigMock";
import { MOCK_SENSORS } from "@/mocks/dashboardMock";
import { levelToStatus } from "@/utils/thresholds";
import type { IResponseEntity } from "@/types/response";
import { FloodStatus, type ISensor, type ISensorPayload, type ISensorQuery } from "@/types/sensor";

// Salinan dengan status yang dihitung dari ambang batas sensor (mock menggantikan perhitungan server)
const view = (s: ISensor): ISensor => ({
  ...s,
  history: [...s.history],
  status: s.status === FloodStatus.OFFLINE ? s.status : levelToStatus(s.waterLevel, thresholdsOf(s.id)),
});

const fail = <T>(message: string, code = 400): IResponseEntity<T> => ({ code, status: false, message });

export const getSensors = async ({ page, limit }: ISensorQuery): Promise<IResponseEntity<ISensor[]>> => {
  if (USE_MOCK) {
    const rows = MOCK_SENSORS.slice((page - 1) * limit, page * limit).map(view);
    return mockResponse(rows, {
      totalPages: Math.ceil(MOCK_SENSORS.length / limit),
      totalData: MOCK_SENSORS.length,
      totalDataPerPage: rows.length,
      page,
      limit,
    });
  }
  const { data } = await axiosInstance.get<IResponseEntity<ISensor[]>>("/sensors", {
    params: { page, limit },
  });
  return data;
};

export const createSensor = async (payload: ISensorPayload): Promise<IResponseEntity<ISensor>> => {
  if (USE_MOCK) {
    if (MOCK_SENSORS.some((s) => s.code === payload.code)) return fail("Kode sensor sudah terdaftar");
    const sensor: ISensor = {
      ...payload,
      id: Math.max(0, ...MOCK_SENSORS.map((s) => s.id)) + 1,
      name: payload.code,
      waterLevel: 0,
      trend: 0,
      history: [],
      status: FloodStatus.OFFLINE,
      battery: 0,
      signal: 0,
      rssi: null,
      solar: 0,
      temperature: 0,
      network: "-",
      lastSeenMinutes: null,
      updatedAt: "-",
    };
    MOCK_SENSORS.push(sensor);
    return mockResponse(view(sensor));
  }
  const { data } = await axiosInstance.post<IResponseEntity<ISensor>>("/sensors", payload);
  return data;
};

export const updateSensor = async (id: number, payload: ISensorPayload): Promise<IResponseEntity<ISensor>> => {
  if (USE_MOCK) {
    const sensor = MOCK_SENSORS.find((s) => s.id === id);
    if (!sensor) return fail("Sensor tidak ditemukan", 404);
    if (MOCK_SENSORS.some((s) => s.id !== id && s.code === payload.code)) return fail("Kode sensor sudah terdaftar");
    Object.assign(sensor, payload, { name: payload.code });
    return mockResponse(view(sensor));
  }
  const { data } = await axiosInstance.put<IResponseEntity<ISensor>>(`/sensors/${id}`, payload);
  return data;
};
