import axios from "axios";

interface IRainViewerResponse {
  host: string;
  radar: { past: { time: number; path: string }[] };
}

// Frame radar hujan terbaru dari RainViewer, dikembalikan sebagai template URL tile Leaflet
export const getRadarTileUrl = async (): Promise<string> => {
  const { data } = await axios.get<IRainViewerResponse>("https://api.rainviewer.com/public/weather-maps.json", {
    timeout: 10000,
  });
  const latest = data.radar.past[data.radar.past.length - 1];
  if (!latest) throw new Error("Data radar tidak tersedia");
  return `${data.host}${latest.path}/256/{z}/{x}/{y}/2/1_1.png`;
};
