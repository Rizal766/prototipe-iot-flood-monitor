import { axiosInstance } from "./axios";
import { USE_MOCK, mockResponse } from "./mock";
import { MOCK_ALERT_CONFIGS } from "@/mocks/alertConfigMock";
import { MOCK_SENSORS } from "@/mocks/dashboardMock";
import { MOCK_DEVICES } from "@/mocks/deviceMock";
import { useAuthStore } from "@/stores/useAuthStore";
import {
  DeviceConnection,
  type IConnectionTest,
  type IDevice,
  type IDevicePayload,
  type IDeviceUpdate,
  type IPairing,
} from "@/types/device";
import type { IResponseEntity } from "@/types/response";
import { FloodStatus } from "@/types/sensor";
import { buildDefaultConfig } from "@/utils/alertConfigDefaults";

const fail = <T>(message: string, code = 400): IResponseEntity<T> => ({ code, status: false, message });
const later = <T>(data: T, ms: number) => new Promise<T>((resolve) => setTimeout(() => resolve(data), ms));
const ok = <T>(data: T): IResponseEntity<T> => ({ code: 200, status: true, message: "success", data });

export const getDevices = async (): Promise<IResponseEntity<IDevice[]>> => {
  if (USE_MOCK) return mockResponse(MOCK_DEVICES.map((d) => ({ ...d })));
  const { data } = await axiosInstance.get<IResponseEntity<IDevice[]>>("/devices", { params: { page: 1, limit: 200 } });
  return data;
};

export const createDevice = async (p: IDevicePayload): Promise<IResponseEntity<IDevice>> => {
  if (USE_MOCK) {
    if (MOCK_DEVICES.some((d) => d.deviceId === p.deviceId)) return fail("ID perangkat sudah terdaftar");
    if (MOCK_DEVICES.some((d) => d.guid === p.guid)) return fail("GUID / Kit ID sudah dipakai perangkat lain");
    const id = Math.max(0, ...MOCK_DEVICES.map((d) => d.id), ...MOCK_SENSORS.map((s) => s.id)) + 1;

    // perangkat baru otomatis terdaftar sebagai sensor (offline sampai data pertama masuk)
    MOCK_SENSORS.push({
      id,
      code: p.deviceId,
      name: p.deviceId,
      location: p.name,
      river: p.river,
      district: p.district,
      waterLevel: 0,
      trend: 0,
      history: [],
      status: FloodStatus.OFFLINE,
      battery: 0,
      signal: 0,
      rssi: null,
      solar: 0,
      temperature: 0,
      network: "-",
      lastSeenMinutes: null,
      updatedAt: "-",
      lat: p.lat,
      lng: p.lng,
    });
    MOCK_ALERT_CONFIGS.push(buildDefaultConfig(id, p.thresholds, useAuthStore.getState().user?.name ?? "Admin"));

    const device: IDevice = {
      id,
      sensorId: id,
      sensorCode: p.deviceId,
      deviceId: p.deviceId,
      name: p.name,
      kind: p.kind,
      guid: p.guid,
      firmware: p.firmware,
      connection: DeviceConnection.OFFLINE,
      lastSeen: null,
      river: p.river,
      district: p.district,
      lat: p.lat,
      lng: p.lng,
      host: "broker.iotflood.id",
      officer: p.officer,
      photo: p.photo,
      registeredAt: new Date().toISOString(),
    };
    MOCK_DEVICES.push(device);
    return mockResponse({ ...device });
  }
  const { data } = await axiosInstance.post<IResponseEntity<IDevice>>("/devices", p);
  return data;
};

export const updateDevice = async (id: number, p: IDeviceUpdate): Promise<IResponseEntity<IDevice>> => {
  if (USE_MOCK) {
    const d = MOCK_DEVICES.find((x) => x.id === id);
    if (!d) return fail("Perangkat tidak ditemukan", 404);
    if (MOCK_DEVICES.some((x) => x.id !== id && x.guid === p.guid)) return fail("GUID / Kit ID sudah dipakai perangkat lain");
    Object.assign(d, p);
    const sensor = MOCK_SENSORS.find((s) => s.id === d.sensorId);
    if (sensor) Object.assign(sensor, { location: p.name, river: p.river, district: p.district, lat: p.lat, lng: p.lng });
    return mockResponse({ ...d });
  }
  const { data } = await axiosInstance.put<IResponseEntity<IDevice>>(`/devices/${id}`, p);
  return data;
};

export const deleteDevice = async (id: number): Promise<IResponseEntity<number>> => {
  if (USE_MOCK) {
    const idx = MOCK_DEVICES.findIndex((x) => x.id === id);
    if (idx < 0) return fail("Perangkat tidak ditemukan", 404);
    const [d] = MOCK_DEVICES.splice(idx, 1);
    const sIdx = MOCK_SENSORS.findIndex((s) => s.id === d.sensorId);
    if (sIdx >= 0) MOCK_SENSORS.splice(sIdx, 1);
    const cIdx = MOCK_ALERT_CONFIGS.findIndex((c) => c.sensorId === d.sensorId);
    if (cIdx >= 0) MOCK_ALERT_CONFIGS.splice(cIdx, 1);
    return mockResponse(id);
  }
  const { data } = await axiosInstance.delete<IResponseEntity<number>>(`/devices/${id}`);
  return data;
};

export const testConnection = async (id: number): Promise<IResponseEntity<IConnectionTest>> => {
  if (USE_MOCK) {
    const d = MOCK_DEVICES.find((x) => x.id === id);
    if (!d) return fail("Perangkat tidak ditemukan", 404);
    const online = d.connection === DeviceConnection.ONLINE;
    const result: IConnectionTest = {
      ok: online,
      testedAt: new Date().toISOString(),
      latencyMs: online ? 40 + ((id * 13) % 120) : null,
      host: d.host,
      stream: `${d.guid}/telemetry`,
      status: online ? "Terhubung" : d.connection === DeviceConnection.MAINTENANCE ? "Mode maintenance" : "Tidak merespons",
      guid: d.guid,
      message: online
        ? "Koneksi berhasil! Perangkat dapat dihubungi dan data masuk."
        : "Koneksi gagal! Perangkat tidak dapat dihubungi.",
    };
    return later(ok(result), 1200);
  }
  const { data } = await axiosInstance.post<IResponseEntity<IConnectionTest>>(`/devices/${id}/test-connection`);
  return data;
};

// Token pairing sebenarnya harus dibuat dan divalidasi oleh server; di mode contoh dibuat lokal
export const createPairing = async (id: number): Promise<IResponseEntity<IPairing>> => {
  if (USE_MOCK) {
    const d = MOCK_DEVICES.find((x) => x.id === id);
    if (!d) return fail("Perangkat tidak ditemukan", 404);
    const bytes = new Uint8Array(12);
    crypto.getRandomValues(bytes);
    const token = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
    const expiresAt = new Date(Date.now() + 30 * 86400000).toISOString();
    return mockResponse({
      deviceId: d.deviceId,
      expiresAt,
      payload: JSON.stringify({ v: 1, deviceId: d.deviceId, guid: d.guid, token, exp: expiresAt }),
    });
  }
  const { data } = await axiosInstance.post<IResponseEntity<IPairing>>(`/devices/${id}/pairing`);
  return data;
};

