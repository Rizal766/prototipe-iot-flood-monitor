import { axiosInstance } from "./axios";
import { USE_MOCK, mockResponse } from "./mock";
import { MOCK_REPORTS, nextReportId, simulateProcessing } from "@/mocks/reportMock";
import { useAuthStore } from "@/stores/useAuthStore";
import { UserRole } from "@/types/auth";
import type { IResponseEntity } from "@/types/response";
import { ReportStatus, type IReport, type IReportCreate } from "@/types/report";
import { reportTitle } from "@/utils/reportName";

export const getReports = async (): Promise<IResponseEntity<IReport[]>> => {
  if (USE_MOCK) return mockResponse(MOCK_REPORTS.map((r) => ({ ...r })));
  const { data } = await axiosInstance.get<IResponseEntity<IReport[]>>("/reports", {
    params: { page: 1, limit: 200 },
  });
  return data;
};

export const createReport = async (payload: IReportCreate): Promise<IResponseEntity<IReport>> => {
  if (USE_MOCK) {
    const user = useAuthStore.getState().user;
    const report: IReport = {
      ...payload,
      id: nextReportId(),
      name: reportTitle(payload),
      status: ReportStatus.PROSES,
      progress: 0,
      createdBy: user?.name ?? "Admin",
      creatorRole: user?.role ?? UserRole.ADMIN,
      createdAt: new Date().toISOString(),
    };
    MOCK_REPORTS.unshift(report);
    simulateProcessing(report.id);
    return mockResponse({ ...report });
  }
  const { data } = await axiosInstance.post<IResponseEntity<IReport>>("/reports", payload);
  return data;
};

export const retryReport = async (id: number): Promise<IResponseEntity<number>> => {
  if (USE_MOCK) {
    const r = MOCK_REPORTS.find((x) => x.id === id);
    if (r) {
      r.status = ReportStatus.PROSES;
      r.progress = 0;
      simulateProcessing(id);
    }
    return mockResponse(id);
  }
  const { data } = await axiosInstance.post<IResponseEntity<number>>(`/reports/${id}/retry`);
  return data;
};

export const deleteReport = async (id: number): Promise<IResponseEntity<number>> => {
  if (USE_MOCK) {
    const idx = MOCK_REPORTS.findIndex((x) => x.id === id);
    if (idx >= 0) MOCK_REPORTS.splice(idx, 1);
    return mockResponse(id);
  }
  const { data } = await axiosInstance.delete<IResponseEntity<number>>(`/reports/${id}`);
  return data;
};
