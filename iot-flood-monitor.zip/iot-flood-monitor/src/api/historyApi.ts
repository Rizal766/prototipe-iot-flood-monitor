import { axiosInstance } from "./axios";
import { USE_MOCK, mockResponse } from "./mock";
import { generateHistory } from "@/mocks/historyMock";
import type { IResponseEntity } from "@/types/response";
import { INTERVAL_HOURS, type IHistoryQuery, type IHistorySeries } from "@/types/history";

export const getHistory = async (q: IHistoryQuery): Promise<IResponseEntity<IHistorySeries[]>> => {
  if (USE_MOCK) {
    return mockResponse(
      generateHistory(q.sensorIds, new Date(q.from).getTime(), new Date(q.to).getTime(), INTERVAL_HOURS[q.interval]),
    );
  }
  const { data } = await axiosInstance.get<IResponseEntity<IHistorySeries[]>>("/history", {
    params: { sensorIds: q.sensorIds.join(","), from: q.from, to: q.to, interval: q.interval },
  });
  return data;
};
