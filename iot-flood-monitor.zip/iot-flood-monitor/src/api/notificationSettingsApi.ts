import { axiosInstance } from "./axios";
import { USE_MOCK, mockResponse } from "./mock";
import {
  MOCK_CHANNELS,
  MOCK_CONTACTS,
  MOCK_TEMPLATES,
  SETTINGS_META,
} from "@/mocks/notificationSettingsMock";
import { useAuthStore } from "@/stores/useAuthStore";
import type { IEmergencyContact, IEmergencyContactPayload } from "@/types/contact";
import {
  ChannelHealth,
  type ChannelType,
  type IChannel,
  type IChannelTestResult,
  type INotificationSettings,
  type ISettingsSave,
} from "@/types/notificationSettings";
import type { IResponseEntity } from "@/types/response";

const fail = <T>(message: string, code = 400): IResponseEntity<T> => ({ code, status: false, message });
const later = <T>(data: T, ms: number) => new Promise<T>((resolve) => setTimeout(() => resolve(data), ms));
const actor = () => useAuthStore.getState().user?.name ?? "Admin";

// Server mengirim nilai rahasia dalam bentuk samar
const mask = (v: string) => (v ? `••••${v.slice(-3)}` : "");
const view = (c: IChannel): IChannel => ({
  ...c,
  fields: c.fields.map((f) => ({ ...f, value: f.secret ? mask(f.value) : f.value })),
  lastTest: c.lastTest ? { ...c.lastTest } : null,
});

export const getNotificationSettings = async (): Promise<IResponseEntity<INotificationSettings>> => {
  if (USE_MOCK) {
    return mockResponse({
      channels: MOCK_CHANNELS.map(view),
      templates: structuredClone(MOCK_TEMPLATES),
      ...SETTINGS_META,
    });
  }
  const { data } = await axiosInstance.get<IResponseEntity<INotificationSettings>>("/notification-settings");
  return data;
};

export const saveNotificationSettings = async (p: ISettingsSave): Promise<IResponseEntity<number>> => {
  if (USE_MOCK) {
    MOCK_CHANNELS.forEach((c) => {
      c.enabled = p.enabled[c.type];
    });
    (Object.keys(p.templates) as (keyof ISettingsSave["templates"])[]).forEach((k) => {
      MOCK_TEMPLATES[k] = { ...p.templates[k] };
    });
    SETTINGS_META.updatedAt = new Date().toISOString();
    SETTINGS_META.updatedBy = actor();
    return mockResponse(1);
  }
  const { data } = await axiosInstance.put<IResponseEntity<number>>("/notification-settings", p);
  return data;
};

// fields: hanya nilai yang diubah; rahasia kosong = tidak diubah
export const updateChannel = async (type: ChannelType, fields: Record<string, string>): Promise<IResponseEntity<IChannel>> => {
  if (USE_MOCK) {
    const c = MOCK_CHANNELS.find((x) => x.type === type);
    if (!c) return fail("Saluran tidak ditemukan", 404);
    c.fields.forEach((f) => {
      const next = fields[f.key];
      if (next === undefined) return;
      if (f.secret && next === "") return;
      f.value = next;
    });
    c.health = ChannelHealth.NORMAL; // konfigurasi baru dianggap sehat sampai diuji
    return mockResponse(view(c));
  }
  const { data } = await axiosInstance.patch<IResponseEntity<IChannel>>(`/notification-channels/${type}`, { fields });
  return data;
};

export const testChannel = async (type: ChannelType): Promise<IResponseEntity<IChannelTestResult>> => {
  if (USE_MOCK) {
    const c = MOCK_CHANNELS.find((x) => x.type === type);
    if (!c) return fail("Saluran tidak ditemukan", 404);
    const ok = c.enabled && c.health === ChannelHealth.NORMAL;
    const at = new Date().toISOString();
    c.lastTest = { ok, at };
    if (ok) c.lastDeliveryAt = at;
    const message = ok
      ? "Pesan uji berhasil dikirim."
      : !c.enabled
        ? "Saluran nonaktif. Aktifkan dan simpan terlebih dahulu."
        : "Saluran mengalami gangguan. Periksa konfigurasi dan koneksi penyedia layanan.";
    return later({ code: 200, status: true, message: "success", data: { ok, message, at } }, 1000);
  }
  const { data } = await axiosInstance.post<IResponseEntity<IChannelTestResult>>(`/notification-channels/${type}/test`);
  return data;
};

// ---------- kontak darurat ----------
export const getContacts = async (): Promise<IResponseEntity<IEmergencyContact[]>> => {
  if (USE_MOCK) return mockResponse(MOCK_CONTACTS.map((c) => ({ ...c })));
  const { data } = await axiosInstance.get<IResponseEntity<IEmergencyContact[]>>("/emergency-contacts");
  return data;
};

export const createContact = async (p: IEmergencyContactPayload): Promise<IResponseEntity<IEmergencyContact>> => {
  if (USE_MOCK) {
    const c: IEmergencyContact = { ...p, id: Math.max(0, ...MOCK_CONTACTS.map((x) => x.id)) + 1 };
    MOCK_CONTACTS.push(c);
    return mockResponse({ ...c });
  }
  const { data } = await axiosInstance.post<IResponseEntity<IEmergencyContact>>("/emergency-contacts", p);
  return data;
};

export const updateContact = async (id: number, p: IEmergencyContactPayload): Promise<IResponseEntity<IEmergencyContact>> => {
  if (USE_MOCK) {
    const c = MOCK_CONTACTS.find((x) => x.id === id);
    if (!c) return fail("Kontak tidak ditemukan", 404);
    Object.assign(c, p);
    return mockResponse({ ...c });
  }
  const { data } = await axiosInstance.put<IResponseEntity<IEmergencyContact>>(`/emergency-contacts/${id}`, p);
  return data;
};

export const deleteContact = async (id: number): Promise<IResponseEntity<number>> => {
  if (USE_MOCK) {
    const idx = MOCK_CONTACTS.findIndex((x) => x.id === id);
    if (idx >= 0) MOCK_CONTACTS.splice(idx, 1);
    return mockResponse(id);
  }
  const { data } = await axiosInstance.delete<IResponseEntity<number>>(`/emergency-contacts/${id}`);
  return data;
};
