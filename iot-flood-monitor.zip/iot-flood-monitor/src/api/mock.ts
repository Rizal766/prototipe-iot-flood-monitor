import type { IResponseEntity, ImetaPagination } from "@/types/response";

// Set VITE_USE_MOCK=false di .env untuk memakai backend asli
export const USE_MOCK = import.meta.env.VITE_USE_MOCK !== "false";

export const mockResponse = <T>(data: T, meta?: ImetaPagination): Promise<IResponseEntity<T>> =>
  new Promise((resolve) =>
    setTimeout(() => resolve({ code: 200, status: true, message: "success", data, meta }), 200),
  );
