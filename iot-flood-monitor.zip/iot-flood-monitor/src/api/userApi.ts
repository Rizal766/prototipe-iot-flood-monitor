import { axiosInstance } from "./axios";
import { USE_MOCK, mockResponse } from "./mock";
import { MOCK_AREAS, MOCK_INVITATIONS, MOCK_PERMISSIONS, MOCK_USERS } from "@/mocks/userMock";
import { useAuthStore } from "@/stores/useAuthStore";
import { UserRole } from "@/types/auth";
import { Feature, PERMISSION_ROLES, type IPermissionMatrix } from "@/types/permission";
import type { IResponseEntity } from "@/types/response";
import {
  InviteStatus,
  UserStatus,
  type IArea,
  type IInvitation,
  type IInvitationCreate,
  type IUser,
  type IUserPayload,
} from "@/types/user";

const fail = <T>(message: string, code = 400): IResponseEntity<T> => ({ code, status: false, message });
const norm = (v: string) => v.trim().toLowerCase();

const activeAdmins = () => MOCK_USERS.filter((u) => u.role === UserRole.ADMIN && u.status === UserStatus.AKTIF);

// ---------- pengguna ----------
export const getUsers = async (): Promise<IResponseEntity<IUser[]>> => {
  if (USE_MOCK) return mockResponse(MOCK_USERS.map((u) => ({ ...u, areas: [...u.areas] })));
  const { data } = await axiosInstance.get<IResponseEntity<IUser[]>>("/users", { params: { page: 1, limit: 200 } });
  return data;
};

export const createUser = async (p: IUserPayload): Promise<IResponseEntity<IUser>> => {
  if (USE_MOCK) {
    if (p.email && MOCK_USERS.some((u) => norm(u.email) === norm(p.email))) return fail("Email sudah terdaftar");
    if (p.phone && MOCK_USERS.some((u) => u.phone === p.phone)) return fail("Nomor HP sudah terdaftar");
    const user: IUser = { ...p, id: Math.max(0, ...MOCK_USERS.map((u) => u.id)) + 1, lastLogin: null };
    MOCK_USERS.push(user);
    return mockResponse({ ...user });
  }
  const { data } = await axiosInstance.post<IResponseEntity<IUser>>("/users", p);
  return data;
};

export const updateUser = async (id: number, p: IUserPayload): Promise<IResponseEntity<IUser>> => {
  if (USE_MOCK) {
    const u = MOCK_USERS.find((x) => x.id === id);
    if (!u) return fail("Pengguna tidak ditemukan", 404);
    if (p.email && MOCK_USERS.some((x) => x.id !== id && norm(x.email) === norm(p.email))) return fail("Email sudah dipakai pengguna lain");
    const losesAdmin = u.role === UserRole.ADMIN && (p.role !== UserRole.ADMIN || p.status !== UserStatus.AKTIF);
    if (losesAdmin && activeAdmins().length <= 1) return fail("Tidak dapat mengubah atau menonaktifkan Admin terakhir");
    Object.assign(u, p);
    return mockResponse({ ...u, areas: [...u.areas] });
  }
  const { data } = await axiosInstance.put<IResponseEntity<IUser>>(`/users/${id}`, p);
  return data;
};

export const deleteUser = async (id: number): Promise<IResponseEntity<number>> => {
  if (USE_MOCK) {
    const idx = MOCK_USERS.findIndex((x) => x.id === id);
    if (idx < 0) return fail("Pengguna tidak ditemukan", 404);
    const u = MOCK_USERS[idx];
    if (norm(u.email) === norm(useAuthStore.getState().user?.email ?? "")) return fail("Anda tidak dapat menghapus akun sendiri");
    if (u.role === UserRole.ADMIN && u.status === UserStatus.AKTIF && activeAdmins().length <= 1) {
      return fail("Tidak dapat menghapus Admin terakhir");
    }
    MOCK_USERS.splice(idx, 1);
    return mockResponse(id);
  }
  const { data } = await axiosInstance.delete<IResponseEntity<number>>(`/users/${id}`);
  return data;
};

// ---------- undangan ----------
// Mock: alamat berakhiran ".invalid" mensimulasikan email yang gagal terkirim
const deliveryStatus = (target: string, viaEmail: boolean) =>
  viaEmail && norm(target).endsWith(".invalid") ? InviteStatus.GAGAL : InviteStatus.MENUNGGU;

export const getInvitations = async (): Promise<IResponseEntity<IInvitation[]>> => {
  if (USE_MOCK) return mockResponse(MOCK_INVITATIONS.map((i) => ({ ...i, areas: [...i.areas] })));
  const { data } = await axiosInstance.get<IResponseEntity<IInvitation[]>>("/invitations");
  return data;
};

export const createInvitation = async (p: IInvitationCreate): Promise<IResponseEntity<IInvitation>> => {
  if (USE_MOCK) {
    const t = norm(p.target);
    if (MOCK_USERS.some((u) => norm(u.email) === t || u.phone === t)) return fail("Email / No. HP sudah terdaftar sebagai pengguna");
    if (MOCK_INVITATIONS.some((i) => norm(i.target) === t && i.status === InviteStatus.MENUNGGU)) {
      return fail("Undangan untuk email / No. HP ini masih menunggu");
    }
    const inv: IInvitation = {
      ...p,
      id: Math.max(0, ...MOCK_INVITATIONS.map((i) => i.id)) + 1,
      sentAt: new Date().toISOString(),
      status: deliveryStatus(p.target, p.viaEmail),
    };
    MOCK_INVITATIONS.unshift(inv);
    return mockResponse({ ...inv });
  }
  const { data } = await axiosInstance.post<IResponseEntity<IInvitation>>("/invitations", p);
  return data;
};

export const resendInvitation = async (id: number): Promise<IResponseEntity<IInvitation>> => {
  if (USE_MOCK) {
    const inv = MOCK_INVITATIONS.find((i) => i.id === id);
    if (!inv) return fail("Undangan tidak ditemukan", 404);
    inv.sentAt = new Date().toISOString();
    inv.status = deliveryStatus(inv.target, inv.viaEmail);
    return mockResponse({ ...inv });
  }
  const { data } = await axiosInstance.post<IResponseEntity<IInvitation>>(`/invitations/${id}/resend`);
  return data;
};

export const cancelInvitation = async (id: number): Promise<IResponseEntity<number>> => {
  if (USE_MOCK) {
    const idx = MOCK_INVITATIONS.findIndex((i) => i.id === id);
    if (idx >= 0) MOCK_INVITATIONS.splice(idx, 1);
    return mockResponse(id);
  }
  const { data } = await axiosInstance.delete<IResponseEntity<number>>(`/invitations/${id}`);
  return data;
};

// ---------- hak akses ----------
export const getPermissions = async (): Promise<IResponseEntity<IPermissionMatrix>> => {
  if (USE_MOCK) return mockResponse(structuredClone(MOCK_PERMISSIONS));
  const { data } = await axiosInstance.get<IResponseEntity<IPermissionMatrix>>("/roles/permissions");
  return data;
};

export const savePermissions = async (m: IPermissionMatrix): Promise<IResponseEntity<IPermissionMatrix>> => {
  if (USE_MOCK) {
    const next = structuredClone(m);
    Object.values(Feature).forEach((f) => {
      next[f][UserRole.ADMIN] = true; // Admin selalu memiliki semua akses
    });
    PERMISSION_ROLES.forEach((r) => {
      Object.values(Feature).forEach((f) => {
        MOCK_PERMISSIONS[f][r] = next[f][r];
      });
    });
    return mockResponse(structuredClone(MOCK_PERMISSIONS));
  }
  const { data } = await axiosInstance.put<IResponseEntity<IPermissionMatrix>>("/roles/permissions", m);
  return data;
};

// ---------- warga terdaftar ----------
export const getAreas = async (): Promise<IResponseEntity<IArea[]>> => {
  if (USE_MOCK) return mockResponse(MOCK_AREAS.map((a) => ({ ...a })));
  const { data } = await axiosInstance.get<IResponseEntity<IArea[]>>("/residents/areas");
  return data;
};

export const updateArea = async (district: string, patch: Partial<Pick<IArea, "residents" | "active">>): Promise<IResponseEntity<IArea>> => {
  if (USE_MOCK) {
    const a = MOCK_AREAS.find((x) => x.district === district);
    if (!a) return fail("Wilayah tidak ditemukan", 404);
    Object.assign(a, patch);
    return mockResponse({ ...a });
  }
  const { data } = await axiosInstance.patch<IResponseEntity<IArea>>(`/residents/areas/${encodeURIComponent(district)}`, patch);
  return data;
};
