import { axiosInstance } from "./axios";
import { USE_MOCK, mockResponse } from "./mock";
import { MOCK_ALERTS, MOCK_INTEGRATIONS, MOCK_SUMMARY, MOCK_WATER_CHART } from "@/mocks/dashboardMock";
import type { IResponseEntity } from "@/types/response";
import type { IAlert, IDashboardSummary, IIntegration, IWaterChart } from "@/types/dashboard";

const get = async <T>(url: string): Promise<IResponseEntity<T>> => {
  const { data } = await axiosInstance.get<IResponseEntity<T>>(url);
  return data;
};

export const getSummary = () =>
  USE_MOCK ? mockResponse<IDashboardSummary>(MOCK_SUMMARY) : get<IDashboardSummary>("/dashboard/summary");

export const getAlerts = () =>
  USE_MOCK ? mockResponse<IAlert[]>(MOCK_ALERTS) : get<IAlert[]>("/dashboard/alerts");

export const getWaterChart = () =>
  USE_MOCK ? mockResponse<IWaterChart>(MOCK_WATER_CHART) : get<IWaterChart>("/dashboard/water-level");

export const getIntegrations = () =>
  USE_MOCK ? mockResponse<IIntegration[]>(MOCK_INTEGRATIONS) : get<IIntegration[]>("/dashboard/integrations");
