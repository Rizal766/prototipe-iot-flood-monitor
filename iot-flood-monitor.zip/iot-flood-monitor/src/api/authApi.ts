import { axiosInstance } from "./axios";
import { USE_MOCK, mockResponse } from "./mock";
import { MOCK_AVATARS, MOCK_PASSWORDS, findMockUser } from "@/mocks/profileMock";
import type { IResponseEntity } from "@/types/response";
import { DEMO_ACCOUNTS, type ILoginPayload, type ILoginResult } from "@/types/auth";

// 08xx / 628xx / +628xx -> 08xx agar nomor telepon dibandingkan dengan format yang sama
const normalize = (v: string): string => {
  const t = v.trim().toLowerCase();
  if (t.includes("@")) return t;
  return t.replace(/^\+?62/, "0");
};

export const login = async (payload: ILoginPayload): Promise<IResponseEntity<ILoginResult>> => {
  if (USE_MOCK) {
    const id = normalize(payload.identifier);
    const account = DEMO_ACCOUNTS.find(
      (a) => a.identifiers.some((i) => normalize(i) === id) && MOCK_PASSWORDS.get(a.user.email) === payload.password,
    );
    if (!account) {
      return { code: 401, status: false, message: "Email/No. Telepon atau password salah" };
    }
    const email = account.user.email;
    return mockResponse<ILoginResult>({
      token: `mock-token-${account.user.role}`,
      user: { ...account.user, name: findMockUser(email)?.name ?? account.user.name, avatar: MOCK_AVATARS.get(email.toLowerCase()) ?? null },
    });
  }
  const { data } = await axiosInstance.post<IResponseEntity<ILoginResult>>("/auth/login", payload);
  return data;
};
