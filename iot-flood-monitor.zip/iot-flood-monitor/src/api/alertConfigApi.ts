import { axiosInstance } from "./axios";
import { USE_MOCK, mockResponse } from "./mock";
import { MOCK_ALERT_CONFIGS } from "@/mocks/alertConfigMock";
import { useAuthStore } from "@/stores/useAuthStore";
import type { IAlertConfig, IAlertConfigPayload } from "@/types/alertConfig";
import type { IResponseEntity } from "@/types/response";
import { buildDefaultConfig } from "@/utils/alertConfigDefaults";
import type { IThresholds } from "@/utils/thresholds";

const actor = () => useAuthStore.getState().user?.name ?? "Admin";

export const getAlertConfigs = async (): Promise<IResponseEntity<IAlertConfig[]>> => {
  if (USE_MOCK) return mockResponse(MOCK_ALERT_CONFIGS.map((c) => structuredClone(c)));
  const { data } = await axiosInstance.get<IResponseEntity<IAlertConfig[]>>("/alert-configs");
  return data;
};

export const saveAlertConfig = async (
  sensorId: number,
  payload: IAlertConfigPayload,
): Promise<IResponseEntity<IAlertConfig>> => {
  if (USE_MOCK) {
    const next: IAlertConfig = {
      ...structuredClone(payload),
      sensorId,
      updatedAt: new Date().toISOString(),
      updatedBy: actor(),
    };
    const idx = MOCK_ALERT_CONFIGS.findIndex((c) => c.sensorId === sensorId);
    if (idx >= 0) MOCK_ALERT_CONFIGS[idx] = next;
    else MOCK_ALERT_CONFIGS.push(next);
    return mockResponse(structuredClone(next));
  }
  const { data } = await axiosInstance.put<IResponseEntity<IAlertConfig>>(`/alert-configs/${sensorId}`, payload);
  return data;
};

// Terapkan ambang batas (template) ke banyak sensor sekaligus
export const applyThresholds = async (
  sensorIds: number[],
  thresholds: IThresholds,
): Promise<IResponseEntity<number>> => {
  if (USE_MOCK) {
    sensorIds.forEach((id) => {
      const c = MOCK_ALERT_CONFIGS.find((x) => x.sensorId === id);
      if (c) {
        c.thresholds = { ...thresholds };
        c.updatedAt = new Date().toISOString();
        c.updatedBy = actor();
      } else {
        MOCK_ALERT_CONFIGS.push(buildDefaultConfig(id, thresholds, actor()));
      }
    });
    return mockResponse(sensorIds.length);
  }
  const { data } = await axiosInstance.post<IResponseEntity<number>>("/alert-configs/apply-thresholds", {
    sensorIds,
    thresholds,
  });
  return data;
};
