import { axiosInstance } from "./axios";
import { USE_MOCK, mockResponse } from "./mock";
import { MOCK_NOTIFICATIONS } from "@/mocks/notificationMock";
import type { IResponseEntity } from "@/types/response";
import { AlertStatus, type INotification, type INotificationPatch } from "@/types/notification";

export const getNotifications = async (): Promise<IResponseEntity<INotification[]>> => {
  if (USE_MOCK) return mockResponse(MOCK_NOTIFICATIONS.map((n) => ({ ...n })));
  const { data } = await axiosInstance.get<IResponseEntity<INotification[]>>("/notifications", {
    params: { page: 1, limit: 200 },
  });
  return data;
};

export const updateNotifications = async (
  ids: number[],
  patch: INotificationPatch,
): Promise<IResponseEntity<number>> => {
  if (USE_MOCK) {
    let count = 0;
    MOCK_NOTIFICATIONS.forEach((n) => {
      if (!ids.includes(n.id)) return;
      if (patch.status) {
        n.status = patch.status;
        if (patch.status !== AlertStatus.BELUM && !n.respondedAt) n.respondedAt = new Date().toISOString();
      }
      if (patch.officer) n.officer = patch.officer;
      if (patch.officerIfEmpty && !n.officer) n.officer = patch.officerIfEmpty;
      if (patch.statusIfBelum && n.status === AlertStatus.BELUM) {
        n.status = patch.statusIfBelum;
        if (!n.respondedAt) n.respondedAt = new Date().toISOString();
      }
      count += 1;
    });
    return mockResponse(count);
  }
  const { data } = await axiosInstance.patch<IResponseEntity<number>>("/notifications", { ids, ...patch });
  return data;
};

export const deleteNotification = async (id: number): Promise<IResponseEntity<number>> => {
  if (USE_MOCK) {
    const idx = MOCK_NOTIFICATIONS.findIndex((n) => n.id === id);
    if (idx >= 0) MOCK_NOTIFICATIONS.splice(idx, 1);
    return mockResponse(id);
  }
  const { data } = await axiosInstance.delete<IResponseEntity<number>>(`/notifications/${id}`);
  return data;
};
