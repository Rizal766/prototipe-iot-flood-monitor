import axios from "axios";

interface INominatimResponse {
  address?: {
    city?: string;
    town?: string;
    municipality?: string;
    county?: string;
    state?: string;
  };
}

// Reverse geocoding OpenStreetMap Nominatim (gunakan seperlunya, maks. ~1 request/detik)
export const reverseGeocode = async (lat: number, lng: number): Promise<string> => {
  const fallback = `${lat.toFixed(2)}, ${lng.toFixed(2)}`;
  const { data } = await axios.get<INominatimResponse>("https://nominatim.openstreetmap.org/reverse", {
    params: { format: "jsonv2", lat, lon: lng, zoom: 10, "accept-language": "id" },
    timeout: 10000,
  });
  const a = data.address;
  if (!a) return fallback;
  if (a.city) return /^(kota|kabupaten)\b/i.test(a.city) ? a.city : `Kota ${a.city}`;
  return a.town ?? a.municipality ?? a.county ?? a.state ?? fallback;
};
