import axios from "axios";
import type { IWeather } from "@/types/dashboard";
import { describeWeather } from "@/utils/weather";

export type IWeatherData = Omit<IWeather, "city">;

interface IOpenMeteoResponse {
  current: { temperature_2m: number; weather_code: number };
  daily: {
    time: string[];
    weather_code: number[];
    temperature_2m_max: number[];
    temperature_2m_min: number[];
    precipitation_probability_max: (number | null)[];
  };
}

// Open-Meteo: gratis, tanpa API key
export const getWeather = async (lat: number, lng: number): Promise<IWeatherData> => {
  const { data } = await axios.get<IOpenMeteoResponse>("https://api.open-meteo.com/v1/forecast", {
    params: {
      latitude: lat,
      longitude: lng,
      current: "temperature_2m,weather_code",
      daily: "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max",
      forecast_days: 3,
      timezone: "auto",
    },
    timeout: 10000,
  });

  const now = describeWeather(data.current.weather_code);
  return {
    temperature: Math.round(data.current.temperature_2m),
    condition: now.label,
    icon: now.icon,
    forecast: data.daily.time.map((d, i) => ({
      label: new Date(`${d}T00:00:00`)
        .toLocaleDateString("id-ID", { weekday: "short", day: "numeric", month: "short" })
        .replace(",", ""),
      icon: describeWeather(data.daily.weather_code[i]).icon,
      chance: data.daily.precipitation_probability_max[i] ?? 0,
      temp: `${Math.round(data.daily.temperature_2m_max[i])}°/${Math.round(data.daily.temperature_2m_min[i])}°`,
    })),
  };
};
