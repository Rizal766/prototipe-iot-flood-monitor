import { axiosInstance } from "./axios";
import { USE_MOCK, mockResponse } from "./mock";
import {
  MOCK_AVATARS,
  MOCK_PASSWORDS,
  MOCK_PREFS,
  MOCK_SESSIONS,
  defaultPrefs,
  findMockUser,
  sessionsFor,
} from "@/mocks/profileMock";
import { MOCK_USERS } from "@/mocks/userMock";
import { useAuthStore } from "@/stores/useAuthStore";
import { UserRole } from "@/types/auth";
import type { IPasswordChange, IPreferences, IProfile, IProfileUpdate, ISession } from "@/types/profile";
import type { IResponseEntity } from "@/types/response";

const fail = <T>(message: string, code = 400): IResponseEntity<T> => ({ code, status: false, message });
const email = () => useAuthStore.getState().user?.email ?? "";

export const getProfile = async (): Promise<IResponseEntity<IProfile>> => {
  if (USE_MOCK) {
    const auth = useAuthStore.getState().user;
    const u = findMockUser(email());
    if (!u && !auth) return fail("Profil tidak ditemukan", 404);
    return mockResponse<IProfile>({
      name: u?.name ?? auth?.name ?? "",
      email: u?.email ?? auth?.email ?? "",
      phone: u?.phone ?? "",
      role: u?.role ?? auth?.role ?? UserRole.OPERATOR,
      avatar: MOCK_AVATARS.get(email().toLowerCase()) ?? auth?.avatar ?? null,
      lastLogin: u?.lastLogin ?? null,
    });
  }
  const { data } = await axiosInstance.get<IResponseEntity<IProfile>>("/profile");
  return data;
};

export const updateProfile = async (p: IProfileUpdate): Promise<IResponseEntity<IProfile>> => {
  if (USE_MOCK) {
    const u = findMockUser(email());
    if (!u) return fail("Profil tidak ditemukan", 404);
    if (p.phone && MOCK_USERS.some((x) => x.id !== u.id && x.phone === p.phone)) return fail("Nomor HP sudah dipakai pengguna lain");
    u.name = p.name;
    u.phone = p.phone;
    return mockResponse<IProfile>({
      name: u.name,
      email: u.email,
      phone: u.phone,
      role: u.role,
      avatar: MOCK_AVATARS.get(u.email.toLowerCase()) ?? null,
      lastLogin: u.lastLogin,
    });
  }
  const { data } = await axiosInstance.put<IResponseEntity<IProfile>>("/profile", p);
  return data;
};

// avatar: data URL foto, atau null untuk menghapus
export const saveAvatar = async (avatar: string | null): Promise<IResponseEntity<{ avatar: string | null }>> => {
  if (USE_MOCK) {
    const key = email().toLowerCase();
    if (avatar) MOCK_AVATARS.set(key, avatar);
    else MOCK_AVATARS.delete(key);
    return mockResponse({ avatar });
  }
  const { data } = await axiosInstance.put<IResponseEntity<{ avatar: string | null }>>("/profile/avatar", { avatar });
  return data;
};

export const changePassword = async (p: IPasswordChange): Promise<IResponseEntity<number>> => {
  if (USE_MOCK) {
    const key = email();
    const current = MOCK_PASSWORDS.get(key);
    if (current === undefined || current !== p.oldPassword) return fail("Password lama salah");
    if (p.newPassword === current) return fail("Password baru tidak boleh sama dengan password lama");
    MOCK_PASSWORDS.set(key, p.newPassword);
    if (p.signOutOthers) MOCK_SESSIONS.set(key.toLowerCase(), sessionsFor(key).filter((s) => s.current));
    return mockResponse(1);
  }
  const { data } = await axiosInstance.post<IResponseEntity<number>>("/profile/password", p);
  return data;
};

export const getSessions = async (): Promise<IResponseEntity<ISession[]>> => {
  if (USE_MOCK) return mockResponse(sessionsFor(email()).map((s) => ({ ...s })));
  const { data } = await axiosInstance.get<IResponseEntity<ISession[]>>("/profile/sessions");
  return data;
};

export const revokeSession = async (id: string): Promise<IResponseEntity<string>> => {
  if (USE_MOCK) {
    const key = email().toLowerCase();
    MOCK_SESSIONS.set(key, sessionsFor(key).filter((s) => s.id !== id || s.current));
    return mockResponse(id);
  }
  const { data } = await axiosInstance.delete<IResponseEntity<string>>(`/profile/sessions/${id}`);
  return data;
};

// Mengeluarkan semua sesi, termasuk perangkat ini
export const revokeAllSessions = async (): Promise<IResponseEntity<number>> => {
  if (USE_MOCK) {
    MOCK_SESSIONS.set(email().toLowerCase(), []);
    return mockResponse(1);
  }
  const { data } = await axiosInstance.delete<IResponseEntity<number>>("/profile/sessions");
  return data;
};

export const getPreferences = async (): Promise<IResponseEntity<IPreferences>> => {
  if (USE_MOCK) return mockResponse({ ...(MOCK_PREFS.get(email().toLowerCase()) ?? defaultPrefs()) });
  const { data } = await axiosInstance.get<IResponseEntity<IPreferences>>("/profile/preferences");
  return data;
};

export const savePreferences = async (p: IPreferences): Promise<IResponseEntity<IPreferences>> => {
  if (USE_MOCK) {
    MOCK_PREFS.set(email().toLowerCase(), { ...p });
    return mockResponse({ ...p });
  }
  const { data } = await axiosInstance.put<IResponseEntity<IPreferences>>("/profile/preferences", p);
  return data;
};
