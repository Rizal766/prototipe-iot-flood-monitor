import axios from "axios";
import type { IBBox } from "@/types/map";

export type LatLngTuple = [number, number];

interface IGeomNode {
  lat: number;
  lon: number;
}

interface IOverpassElement {
  type: string;
  geometry?: IGeomNode[];
  members?: { type: string; role: string; geometry?: IGeomNode[] }[];
}

const OVERPASS_URL = "https://overpass-api.de/api/interpreter";

const run = async (query: string): Promise<IOverpassElement[]> => {
  const { data } = await axios.get<{ elements: IOverpassElement[] }>(OVERPASS_URL, {
    params: { data: query },
    timeout: 40000,
  });
  return data.elements;
};

const toLine = (nodes: IGeomNode[]): LatLngTuple[] => nodes.map((n) => [n.lat, n.lon]);
const bboxStr = (b: IBBox) => `${b.south},${b.west},${b.north},${b.east}`;

// Garis sungai nyata dari OpenStreetMap
export const getWaterways = async (b: IBBox): Promise<LatLngTuple[][]> => {
  const bb = bboxStr(b);
  const els = await run(
    `[out:json][timeout:30];(way["waterway"~"^(river|canal)$"](${bb});way["waterway"="stream"]["name"](${bb}););out geom;`,
  );
  return els.flatMap((e) => (e.type === "way" && e.geometry ? [toLine(e.geometry)] : []));
};

// Batas kecamatan (admin_level 6) dari OpenStreetMap
export const getDistricts = async (b: IBBox): Promise<LatLngTuple[][]> => {
  const bb = bboxStr(b);
  const els = await run(
    `[out:json][timeout:30];relation["boundary"="administrative"]["admin_level"="6"](${bb});out geom;`,
  );
  return els.flatMap((e) =>
    (e.members ?? []).flatMap((m) => (m.type === "way" && m.geometry ? [toLine(m.geometry)] : [])),
  );
};
