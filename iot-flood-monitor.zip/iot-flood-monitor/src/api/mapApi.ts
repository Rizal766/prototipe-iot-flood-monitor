import { axiosInstance } from "./axios";
import { USE_MOCK, mockResponse } from "./mock";
import { MOCK_EVACUATION } from "@/mocks/dashboardMock";
import type { IResponseEntity } from "@/types/response";
import type { IEvacuationPayload, IEvacuationPoint } from "@/types/map";

const fail = <T>(message: string, code = 400): IResponseEntity<T> => ({ code, status: false, message });

// Mock mengembalikan salinan agar perubahan terdeteksi react-query
export const getEvacuationPoints = async (): Promise<IResponseEntity<IEvacuationPoint[]>> => {
  if (USE_MOCK) return mockResponse(MOCK_EVACUATION.map((e) => ({ ...e })));
  const { data } = await axiosInstance.get<IResponseEntity<IEvacuationPoint[]>>("/map/evacuation-points");
  return data;
};

export const createEvacuationPoint = async (p: IEvacuationPayload): Promise<IResponseEntity<IEvacuationPoint>> => {
  if (USE_MOCK) {
    const point: IEvacuationPoint = { ...p, id: Math.max(0, ...MOCK_EVACUATION.map((e) => e.id)) + 1 };
    MOCK_EVACUATION.push(point);
    return mockResponse({ ...point });
  }
  const { data } = await axiosInstance.post<IResponseEntity<IEvacuationPoint>>("/map/evacuation-points", p);
  return data;
};

export const updateEvacuationPoint = async (id: number, p: IEvacuationPayload): Promise<IResponseEntity<IEvacuationPoint>> => {
  if (USE_MOCK) {
    const e = MOCK_EVACUATION.find((x) => x.id === id);
    if (!e) return fail("Titik evakuasi tidak ditemukan", 404);
    Object.assign(e, p);
    return mockResponse({ ...e });
  }
  const { data } = await axiosInstance.put<IResponseEntity<IEvacuationPoint>>(`/map/evacuation-points/${id}`, p);
  return data;
};

export const deleteEvacuationPoint = async (id: number): Promise<IResponseEntity<number>> => {
  if (USE_MOCK) {
    const idx = MOCK_EVACUATION.findIndex((x) => x.id === id);
    if (idx < 0) return fail("Titik evakuasi tidak ditemukan", 404);
    MOCK_EVACUATION.splice(idx, 1);
    return mockResponse(id);
  }
  const { data } = await axiosInstance.delete<IResponseEntity<number>>(`/map/evacuation-points/${id}`);
  return data;
};
