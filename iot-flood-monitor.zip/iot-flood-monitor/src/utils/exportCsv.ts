import { csvCell } from "./csv";

// Membangun CSV bertahap agar progres bisa ditampilkan dan UI tidak membeku
export const buildCsvAsync = async (
  header: string[],
  rows: (string | number)[][],
  onProgress: (pct: number) => void,
): Promise<Blob> => {
  const CHUNK = 500;
  const lines = [header.map(csvCell).join(",")];
  for (let i = 0; i < rows.length; i += CHUNK) {
    for (const r of rows.slice(i, i + CHUNK)) lines.push(r.map(csvCell).join(","));
    onProgress(Math.round((Math.min(i + CHUNK, rows.length) / rows.length) * 100));
    await new Promise((resolve) => setTimeout(resolve, 0));
  }
  return new Blob(["\ufeff" + lines.join("\r\n")], { type: "text/csv;charset=utf-8;" });
};
