// Menyebut perangkat dari user-agent, contoh: "Windows Chrome", "iPhone Safari"
export const describeDevice = (ua: string): string => {
  const os = /Windows/i.test(ua)
    ? "Windows"
    : /Android/i.test(ua)
      ? "Android"
      : /iPhone|iPad|iPod/i.test(ua)
        ? "iPhone"
        : /Mac OS X/i.test(ua)
          ? "macOS"
          : /Linux/i.test(ua)
            ? "Linux"
            : "Perangkat";
  const browser = /Edg\//i.test(ua)
    ? "Edge"
    : /Firefox\//i.test(ua)
      ? "Firefox"
      : /Chrome\//i.test(ua)
        ? "Chrome"
        : /Safari\//i.test(ua)
          ? "Safari"
          : "Browser";
  return `${os} ${browser}`;
};

export const isMobileDevice = (device: string): boolean => /Android|iPhone/i.test(device);
