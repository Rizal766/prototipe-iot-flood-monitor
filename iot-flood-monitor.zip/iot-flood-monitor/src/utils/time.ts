export const formatAgo = (minutes: number | null): string => {
  if (minutes === null) return "Belum pernah";
  if (minutes < 1) return "Baru saja";
  if (minutes < 60) return `${Math.floor(minutes)} menit lalu`;
  if (minutes < 1440) return `${Math.floor(minutes / 60)} jam lalu`;
  return `${Math.floor(minutes / 1440)} hari lalu`;
};

// Versi singkat: "36 mnt lalu", "2 jam lalu", "3 hari lalu"
export const formatAgoShort = (iso: string): string => {
  const minutes = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 60000));
  if (minutes < 1) return "baru saja";
  if (minutes < 60) return `${minutes} mnt lalu`;
  if (minutes < 1440) return `${Math.floor(minutes / 60)} jam lalu`;
  return `${Math.floor(minutes / 1440)} hari lalu`;
};

export const formatClock = (iso: string): string =>
  new Date(iso).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", hour12: false }).replace(".", ":");

export const formatDateTime = (iso: string): string =>
  new Date(iso)
    .toLocaleString("id-ID", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", hour12: false })
    .replace(",", "")
    .replace(/(\d{2})\.(\d{2})$/, "$1:$2");

export const formatBytes = (bytes: number): string =>
  bytes >= 1024 * 1024 ? `${(bytes / 1024 / 1024).toFixed(1)} MB` : `${(bytes / 1024).toFixed(1)} KB`;

export const formatDate = (iso: string): string =>
  new Date(iso).toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" });

export const formatPeriod = (from: string, to: string): string =>
  new Date(from).toDateString() === new Date(to).toDateString()
    ? formatDate(from)
    : `${formatDate(from)} - ${formatDate(to)}`;
