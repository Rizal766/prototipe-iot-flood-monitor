import dayjs from "dayjs";
import { ReportType } from "@/types/report";
import type { ISensor } from "@/types/sensor";
import type { IRange } from "./historyRange";

export const ALL_AREA_LABEL = "Semarang (Semua)";

// Nilai pilihan wilayah: "d:<kecamatan>" atau "s:<id sensor>"
export const resolveScope = (scope: string[], sensors: ISensor[]): { ids: number[] | null; label: string } => {
  if (scope.length === 0) return { ids: null, label: ALL_AREA_LABEL };
  const ids = new Set<number>();
  const names: string[] = [];
  scope.forEach((v) => {
    if (v.startsWith("d:")) {
      const district = v.slice(2);
      names.push(district);
      sensors.filter((s) => s.district === district).forEach((s) => ids.add(s.id));
    } else {
      const id = Number(v.slice(2));
      const sensor = sensors.find((s) => s.id === id);
      if (sensor) {
        ids.add(id);
        names.push(sensor.code);
      }
    }
  });
  if (ids.size === 0) return { ids: null, label: ALL_AREA_LABEL };
  const label = names.length > 3 ? `${names.slice(0, 3).join(", ")} +${names.length - 3}` : names.join(", ");
  return { ids: [...ids], label };
};

// Periode bawaan menurut jenis laporan
export const presetForType = (type: ReportType): IRange => {
  const now = dayjs();
  let from = now.startOf("day");
  if (type === ReportType.MINGGUAN) from = now.subtract(6, "day").startOf("day");
  if (type === ReportType.BULANAN) from = now.startOf("month");
  return { from: from.toISOString(), to: now.toISOString() };
};
