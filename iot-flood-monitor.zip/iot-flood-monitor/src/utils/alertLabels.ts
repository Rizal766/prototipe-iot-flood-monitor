import { AlertLevel } from "@/types/notification";

// Label teks biasa (tanpa JSX) untuk dipakai di PDF/Excel
export const LEVEL_LABEL: Record<AlertLevel, string> = {
  [AlertLevel.TINGGI]: "Tinggi",
  [AlertLevel.SEDANG]: "Sedang",
  [AlertLevel.RENDAH]: "Rendah",
  [AlertLevel.OFFLINE]: "Offline",
};
