// Kode cuaca WMO (Open-Meteo) -> teks Indonesia + emoji
export const describeWeather = (code: number): { label: string; icon: string } => {
  if (code === 0) return { label: "Cerah", icon: "☀️" };
  if (code === 1) return { label: "Cerah Berawan", icon: "🌤️" };
  if (code === 2) return { label: "Berawan Sebagian", icon: "⛅" };
  if (code === 3) return { label: "Berawan", icon: "☁️" };
  if (code === 45 || code === 48) return { label: "Berkabut", icon: "🌫️" };
  if (code >= 51 && code <= 57) return { label: "Gerimis", icon: "🌦️" };
  if (code >= 61 && code <= 67) return { label: "Hujan", icon: "🌧️" };
  if ((code >= 71 && code <= 77) || code === 85 || code === 86) return { label: "Salju", icon: "❄️" };
  if (code >= 80 && code <= 82) return { label: "Hujan Deras", icon: "🌧️" };
  if (code >= 95) return { label: "Badai Petir", icon: "⛈️" };
  return { label: "Berawan", icon: "☁️" };
};
