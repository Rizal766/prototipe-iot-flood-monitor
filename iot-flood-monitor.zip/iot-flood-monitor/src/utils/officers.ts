// Daftar petugas lapangan yang dapat ditugaskan pada alert
export const OFFICERS = ["Andi Pratama", "Siti Rahayu", "Budi Santoso", "Rizky Maulana", "Dewi Lestari", "Ahmad Fauzi"];
