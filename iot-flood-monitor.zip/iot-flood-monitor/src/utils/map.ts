import type { BaseMap, IBBox, IGeoPoint } from "@/types/map";
import type { ISensor } from "@/types/sensor";

// Pusat default: Kota Semarang
export const DEFAULT_CENTER: IGeoPoint = { lat: -6.9932, lng: 110.4203 };
export const DEFAULT_ZOOM = 12;
export const FOCUS_ZOOM = 15;
export const CLUSTER_MAX_ZOOM = 14;
const CLUSTER_CELL_PX = 56;

const DEFAULT_BBOX: IBBox = { south: -7.1, west: 110.3, north: -6.9, east: 110.55 };

export interface ITileConfig {
  url: string;
  attribution: string;
  maxZoom: number;
}

export const TILES: Record<BaseMap, ITileConfig> = {
  peta: {
    url: "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    maxZoom: 19,
  },
  satelit: {
    url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    attribution: "Tiles &copy; Esri &mdash; Source: Esri, Maxar, Earthstar Geographics, and the GIS User Community",
    maxZoom: 19,
  },
};

export interface IPoint {
  x: number;
  y: number;
}

export type MapItem =
  | { kind: "single"; sensor: ISensor }
  | { kind: "cluster"; key: string; members: ISensor[]; lat: number; lng: number };

interface IProjected {
  sensor: ISensor;
  pt: IPoint;
}

// Pengelompokan sensor berdasarkan jarak piksel pada layar (grid sederhana)
export const buildMapItems = (
  sensors: ISensor[],
  toPoint: (lat: number, lng: number) => IPoint,
  size: { w: number; h: number },
  zoom: number,
): MapItem[] => {
  const margin = 40;
  const visible: IProjected[] = sensors
    .map((sensor) => ({ sensor, pt: toPoint(sensor.lat, sensor.lng) }))
    .filter(({ pt }) => pt.x >= -margin && pt.x <= size.w + margin && pt.y >= -margin && pt.y <= size.h + margin);

  if (zoom > CLUSTER_MAX_ZOOM) return visible.map(({ sensor }) => ({ kind: "single", sensor }));

  const buckets = new Map<string, IProjected[]>();
  visible.forEach((o) => {
    const key = `${Math.floor(o.pt.x / CLUSTER_CELL_PX)}:${Math.floor(o.pt.y / CLUSTER_CELL_PX)}`;
    buckets.set(key, [...(buckets.get(key) ?? []), o]);
  });

  const items: MapItem[] = [];
  buckets.forEach((group, key) => {
    if (group.length === 1) {
      items.push({ kind: "single", sensor: group[0].sensor });
      return;
    }
    const members = group.map((g) => g.sensor);
    items.push({
      kind: "cluster",
      key,
      members,
      lat: members.reduce((a, s) => a + s.lat, 0) / members.length,
      lng: members.reduce((a, s) => a + s.lng, 0) / members.length,
    });
  });
  return items;
};

export const sensorsBBox = (sensors: ISensor[], pad = 0.05): IBBox => {
  if (sensors.length === 0) return DEFAULT_BBOX;
  const lats = sensors.map((s) => s.lat);
  const lngs = sensors.map((s) => s.lng);
  return {
    south: Math.floor((Math.min(...lats) - pad) * 100) / 100,
    north: Math.ceil((Math.max(...lats) + pad) * 100) / 100,
    west: Math.floor((Math.min(...lngs) - pad) * 100) / 100,
    east: Math.ceil((Math.max(...lngs) + pad) * 100) / 100,
  };
};

export const metersPerPixel = (lat: number, zoom: number): number =>
  (156543.03392 * Math.cos((lat * Math.PI) / 180)) / 2 ** zoom;

// Skala "bulat" untuk bar ~80 piksel
export const formatScale = (zoom: number, lat: number): { label: string; width: number } => {
  const mpp = metersPerPixel(lat, zoom);
  const raw = mpp * 80;
  const pow = 10 ** Math.floor(Math.log10(raw));
  const n = raw / pow;
  const nice = (n >= 5 ? 5 : n >= 2 ? 2 : 1) * pow;
  return {
    label: nice >= 1000 ? `${nice / 1000} km` : `${nice} m`,
    width: Math.round(nice / mpp),
  };
};

export const hourLabels = (updatedAt: string, n = 6): string[] => {
  const h = Number(updatedAt.split(":")[0]);
  const base = Number.isNaN(h) ? 0 : h;
  return Array.from({ length: n }, (_, i) => `${String((base - (n - 1 - i) + 24) % 24).padStart(2, "0")}:00`);
};
