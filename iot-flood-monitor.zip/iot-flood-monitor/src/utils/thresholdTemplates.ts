import type { IThresholds } from "./thresholds";

export interface IThresholdTemplate {
  name: string;
  thresholds: IThresholds;
}

export const THRESHOLD_TEMPLATES: IThresholdTemplate[] = [
  { name: "Sungai Besar (Default)", thresholds: { waspada: 80, siaga: 120, bahaya: 200 } },
  { name: "Sungai Sedang", thresholds: { waspada: 100, siaga: 150, bahaya: 200 } },
  { name: "Anak Sungai", thresholds: { waspada: 50, siaga: 80, bahaya: 120 } },
  { name: "Kanal Banjir", thresholds: { waspada: 120, siaga: 180, bahaya: 240 } },
];

export const matchTemplate = (t: IThresholds): IThresholdTemplate | undefined =>
  THRESHOLD_TEMPLATES.find(
    (x) => x.thresholds.waspada === t.waspada && x.thresholds.siaga === t.siaga && x.thresholds.bahaya === t.bahaya,
  );
