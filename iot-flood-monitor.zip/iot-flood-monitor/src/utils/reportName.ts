import { ReportType, type IReportParams } from "@/types/report";
import { formatDate } from "./time";

export const reportTitle = (p: Pick<IReportParams, "type" | "from" | "to" | "areaLabel">): string => {
  switch (p.type) {
    case ReportType.HARIAN:
      return `Laporan Harian ${formatDate(p.from)}`;
    case ReportType.MINGGUAN:
      return `Laporan Mingguan ${formatDate(p.from)} - ${formatDate(p.to)}`;
    case ReportType.BULANAN:
      return `Laporan Bulanan ${new Date(p.from).toLocaleDateString("id-ID", { month: "long", year: "numeric" })}`;
    default:
      return `Laporan Kejadian ${p.areaLabel} ${formatDate(p.from)}`;
  }
};
