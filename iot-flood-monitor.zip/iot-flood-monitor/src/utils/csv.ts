import type { ISensor } from "@/types/sensor";
import { STATUS_META } from "./status";
import { formatAgo } from "./time";

const HEADER = [
  "ID Sensor",
  "Lokasi",
  "Sungai",
  "Kecamatan",
  "Tinggi Air (cm)",
  "Tren (cm/jam)",
  "Status",
  "Baterai (%)",
  "Sinyal (0-4)",
  "Jaringan",
  "Update Terakhir",
];

// Cegah CSV/formula injection di Excel
export const csvCell = (v: string | number): string => {
  const text = typeof v === "string" && /^[=+\-@\t\r]/.test(v) ? `'${v}` : String(v);
  return `"${text.replace(/"/g, '""')}"`;
};

export const downloadSensorCsv = (rows: ISensor[]) => {
  const lines = [
    HEADER.map(csvCell).join(","),
    ...rows.map((s) =>
      [
        s.code,
        s.location,
        s.river,
        s.district,
        s.waterLevel,
        s.trend,
        STATUS_META[s.status].label,
        s.battery,
        s.signal,
        s.network,
        formatAgo(s.lastSeenMinutes),
      ]
        .map(csvCell)
        .join(","),
    ),
  ];
  const blob = new Blob(["\ufeff" + lines.join("\r\n")], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `data-sensor-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
};
