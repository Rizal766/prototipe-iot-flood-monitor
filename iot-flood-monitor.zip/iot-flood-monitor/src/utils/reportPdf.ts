import type { jsPDF } from "jspdf";
import { FloodStatus } from "@/types/sensor";
import { AlertStatus } from "@/types/notification";
import type { IReportData } from "@/types/report";
import { LEVEL_LABEL } from "./alertLabels";
import { STATUS_META } from "./status";
import { formatDateTime } from "./time";

const PAGE_W = 210;
const MARGIN = 14;
const ALERT_STATUS_TEXT: Record<AlertStatus, string> = {
  [AlertStatus.BELUM]: "Belum ditangani",
  [AlertStatus.DIPROSES]: "Diproses",
  [AlertStatus.SELESAI]: "Selesai",
};

const BLUE: [number, number, number] = [37, 99, 235];

const hex = (c: string): [number, number, number] => [
  parseInt(c.slice(1, 3), 16),
  parseInt(c.slice(3, 5), 16),
  parseInt(c.slice(5, 7), 16),
];

const drawLineChart = (doc: jsPDF, x: number, y: number, w: number, h: number, d: IReportData) => {
  const n = d.times.length;
  if (n < 2 || d.series.length === 0) return;
  const max = Math.max(50, Math.ceil(Math.max(...d.series.flatMap((s) => s.values)) / 50) * 50);
  const px = (i: number) => x + (i / (n - 1)) * w;
  const py = (v: number) => y + h - (v / max) * h;

  doc.setLineWidth(0.2);
  doc.setFontSize(7);
  for (let i = 0; i <= 4; i++) {
    const yy = y + h - (i / 4) * h;
    doc.setDrawColor(226, 232, 240);
    doc.line(x, yy, x + w, yy);
    doc.setTextColor(100, 116, 139);
    doc.text(String(Math.round((max * i) / 4)), x - 2, yy + 1, { align: "right" });
  }

  const spanDays = (new Date(d.times[n - 1]).getTime() - new Date(d.times[0]).getTime()) / 86400000;
  for (let k = 0; k < 6; k++) {
    const idx = Math.round((k * (n - 1)) / 5);
    const date = new Date(d.times[idx]);
    const label =
      spanDays <= 2
        ? date.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", hour12: false }).replace(".", ":")
        : date.toLocaleDateString("id-ID", { day: "numeric", month: "short" });
    doc.text(label, px(idx), y + h + 4, { align: "center" });
  }

  d.series.forEach((s) => {
    doc.setDrawColor(...hex(s.color));
    doc.setLineWidth(0.5);
    for (let j = 1; j < s.values.length; j++) {
      doc.line(px(j - 1), py(s.values[j - 1]), px(j), py(s.values[j]));
    }
  });

  // legenda
  let lx = x;
  doc.setFontSize(8);
  d.series.forEach((s) => {
    doc.setFillColor(...hex(s.color));
    doc.rect(lx, y + h + 8, 3, 3, "F");
    doc.setTextColor(51, 65, 85);
    doc.text(s.code, lx + 4.5, y + h + 10.5);
    lx += 28;
  });
};

export const buildReportPdf = async (d: IReportData): Promise<Blob> => {
  const [{ jsPDF: JsPDF }, autoTableMod] = await Promise.all([import("jspdf"), import("jspdf-autotable")]);
  const autoTable = autoTableMod.default;
  const doc = new JsPDF({ unit: "mm", format: "a4" });
  let y = 0;

  const finalY = () => (doc as unknown as { lastAutoTable?: { finalY: number } }).lastAutoTable?.finalY ?? y;
  const ensure = (need: number) => {
    if (y + need > 280) {
      doc.addPage();
      y = 20;
    }
  };
  const heading = (text: string) => {
    ensure(14);
    doc.setTextColor(30, 41, 59);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.text(text, MARGIN, y);
    doc.setFont("helvetica", "normal");
    y += 5;
  };
  const tableStyle = {
    styles: { fontSize: 8, cellPadding: 1.8 },
    headStyles: { fillColor: BLUE },
    margin: { left: MARGIN, right: MARGIN },
  };

  // Kop laporan
  doc.setFillColor(...BLUE);
  doc.rect(0, 0, PAGE_W, 28, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.text(d.title, MARGIN, 13);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text("IoT Flood Monitor - Early Warning System", MARGIN, 20);

  doc.setTextColor(51, 65, 85);
  doc.setFontSize(9);
  y = 36;
  [
    ["Jenis", d.typeLabel],
    ["Periode", d.periodLabel],
    ["Wilayah / Sensor", d.areaLabel],
    ["Dibuat oleh", d.createdBy],
    ["Tanggal dibuat", formatDateTime(d.generatedAt)],
  ].forEach(([k, v]) => {
    doc.text(k, MARGIN, y);
    doc.text(`: ${v}`, MARGIN + 36, y);
    y += 5;
  });
  y += 3;

  const s = d.summary;

  if (d.includes.summary) {
    heading("Ringkasan Status");
    autoTable(doc, {
      ...tableStyle,
      startY: y,
      head: [["Aman", "Waspada", "Siaga", "Bahaya", "Offline", "Total Sensor"]],
      body: [
        [
          s.byStatus[FloodStatus.AMAN],
          s.byStatus[FloodStatus.WASPADA],
          s.byStatus[FloodStatus.SIAGA],
          s.byStatus[FloodStatus.BAHAYA],
          s.byStatus[FloodStatus.OFFLINE],
          s.totalSensor,
        ],
      ],
    });
    y = finalY() + 4;
    doc.setFontSize(9);
    doc.setTextColor(51, 65, 85);
    [
      `Sensor aktif: ${s.activeSensor} dari ${s.totalSensor} (${s.activePct}%)`,
      `Tinggi air tertinggi: ${s.maxLevel ? `${s.maxLevel.value} cm (${s.maxLevel.code})` : "-"}`,
      `Jumlah alert pada periode: ${s.alertTotal} (belum ditangani: ${s.alertUnhandled})`,
      `Rata-rata waktu respons: ${s.avgResponseMin !== null ? `${s.avgResponseMin} menit` : "-"}`,
    ].forEach((line) => {
      ensure(6);
      doc.text(`- ${line}`, MARGIN, y);
      y += 5;
    });
    y += 2;

    heading("Statistik per Sensor");
    autoTable(doc, {
      ...tableStyle,
      startY: y,
      head: [["ID", "Lokasi", "Status", "Maks (cm)", "Min (cm)", "Rata2 (cm)", "Jam di atas siaga", "Hujan (mm)", "Baterai"]],
      body: d.sensorStats.map((t) => [
        t.code,
        t.location,
        STATUS_META[t.status].label,
        t.max,
        t.min,
        t.avg,
        t.hoursSiaga,
        t.rainTotal,
        `${t.battery}%`,
      ]),
    });
    y = finalY() + 8;
  }

  if (d.includes.charts) {
    ensure(80);
    heading("Grafik Tinggi Muka Air (cm)");
    if (d.series.length === 0 || d.times.length < 2) {
      doc.setFontSize(9);
      doc.text("Tidak ada data pada periode ini.", MARGIN, y + 4);
      y += 10;
    } else {
      drawLineChart(doc, MARGIN + 8, y + 2, PAGE_W - MARGIN * 2 - 10, 55, d);
      y += 80;
    }
  }

  if (d.includes.alerts) {
    ensure(30);
    heading("Daftar Alert & Waktu Respons");
    if (d.alerts.length === 0) {
      doc.setFontSize(9);
      doc.text("Tidak ada alert pada periode ini.", MARGIN, y + 4);
      y += 10;
    } else {
      autoTable(doc, {
        ...tableStyle,
        startY: y,
        head: [["Waktu", "Level", "Judul", "Sensor", "Status", "Petugas", "Respons (mnt)"]],
        body: d.alerts.map((a) => [
          formatDateTime(a.time),
          LEVEL_LABEL[a.level],
          a.title,
          a.sensorCode,
          ALERT_STATUS_TEXT[a.status],
          a.officer ?? "-",
          a.responseMin ?? "-",
        ]),
      });
      y = finalY() + 8;
    }
  }

  if (d.includes.problemSensors) {
    ensure(30);
    heading("Sensor Bermasalah");
    if (d.problems.length === 0) {
      doc.setFontSize(9);
      doc.text("Tidak ada sensor bermasalah.", MARGIN, y + 4);
    } else {
      autoTable(doc, {
        ...tableStyle,
        startY: y,
        head: [["ID Sensor", "Lokasi", "Masalah"]],
        body: d.problems.map((p) => [p.code, p.location, p.issue]),
      });
    }
  }

  const pages = doc.getNumberOfPages();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    doc.text(`Dibuat ${formatDateTime(d.generatedAt)} oleh ${d.createdBy}`, MARGIN, 290);
    doc.text(`Halaman ${i} dari ${pages}`, PAGE_W - MARGIN, 290, { align: "right" });
  }

  return doc.output("blob");
};
