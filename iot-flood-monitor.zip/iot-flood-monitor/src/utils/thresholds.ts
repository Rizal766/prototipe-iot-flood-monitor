import { FloodStatus } from "@/types/sensor";

export interface IThresholds {
  waspada: number;
  siaga: number;
  bahaya: number;
}

// Ambang tinggi muka air (cm) bila sensor belum punya konfigurasi sendiri
export const DEFAULT_THRESHOLDS: IThresholds = { waspada: 80, siaga: 120, bahaya: 200 };
export const WATER_THRESHOLDS = DEFAULT_THRESHOLDS;

export const levelToStatus = (cm: number, t: IThresholds = DEFAULT_THRESHOLDS): FloodStatus => {
  if (cm >= t.bahaya) return FloodStatus.BAHAYA;
  if (cm >= t.siaga) return FloodStatus.SIAGA;
  if (cm >= t.waspada) return FloodStatus.WASPADA;
  return FloodStatus.AMAN;
};
