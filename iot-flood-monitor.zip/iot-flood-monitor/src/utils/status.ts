import { FloodStatus } from "@/types/sensor";
import type { StatusFilter } from "@/types/map";

export const STATUS_META: Record<FloodStatus, { label: string; color: string }> = {
  [FloodStatus.AMAN]: { label: "Aman", color: "#22c55e" },
  [FloodStatus.WASPADA]: { label: "Waspada", color: "#eab308" },
  [FloodStatus.SIAGA]: { label: "Siaga", color: "#f97316" },
  [FloodStatus.BAHAYA]: { label: "Bahaya", color: "#ef4444" },
  [FloodStatus.OFFLINE]: { label: "Offline", color: "#9ca3af" },
};

// Tingkat keparahan, dipakai untuk menentukan sensor yang ditampilkan pertama di peta
export const STATUS_SEVERITY: Record<FloodStatus, number> = {
  [FloodStatus.BAHAYA]: 4,
  [FloodStatus.SIAGA]: 3,
  [FloodStatus.WASPADA]: 2,
  [FloodStatus.AMAN]: 1,
  [FloodStatus.OFFLINE]: 0,
};

export const STATUS_MESSAGE: Record<FloodStatus, string> = {
  [FloodStatus.BAHAYA]: "Ketinggian air sudah melebihi batas aman. Segera lakukan pemantauan dan siapkan evakuasi.",
  [FloodStatus.SIAGA]: "Ketinggian air mendekati batas bahaya. Tingkatkan pemantauan dan siapkan petugas.",
  [FloodStatus.WASPADA]: "Ketinggian air mulai meningkat. Lakukan pemantauan berkala.",
  [FloodStatus.AMAN]: "Kondisi normal. Tidak ada tindakan yang diperlukan.",
  [FloodStatus.OFFLINE]: "Sensor tidak terhubung. Periksa daya dan koneksi perangkat.",
};

export const STATUS_FILTERS: { key: StatusFilter; label: string; color: string }[] = [
  { key: "ALL", label: "Semua", color: "#3b82f6" },
  { key: FloodStatus.AMAN, label: "Normal", color: STATUS_META[FloodStatus.AMAN].color },
  { key: FloodStatus.WASPADA, label: "Waspada", color: STATUS_META[FloodStatus.WASPADA].color },
  { key: FloodStatus.SIAGA, label: "Siaga", color: STATUS_META[FloodStatus.SIAGA].color },
  { key: FloodStatus.BAHAYA, label: "Bahaya", color: STATUS_META[FloodStatus.BAHAYA].color },
  { key: FloodStatus.OFFLINE, label: "Offline", color: STATUS_META[FloodStatus.OFFLINE].color },
];

export const formatTrend = (trend: number): string =>
  trend > 0 ? `↑ ${trend} cm/jam` : trend < 0 ? `↓ ${Math.abs(trend)} cm/jam` : "Stabil";
