export const TEMPLATE_VARS = ["sensor", "lokasi", "tinggi", "status", "waktu"] as const;

export const renderTemplate = (text: string, vars: Record<string, string>): string =>
  text.replace(/\{(\w+)\}/g, (m, k: string) => (k in vars ? vars[k] : m));

// Placeholder yang tidak dikenali (salah ketik) agar bisa ditandai sebelum disimpan
export const unknownVars = (text: string): string[] => {
  const known: readonly string[] = TEMPLATE_VARS;
  return [...new Set([...text.matchAll(/\{(\w+)\}/g)].map((m) => m[1]).filter((k) => !known.includes(k)))];
};
