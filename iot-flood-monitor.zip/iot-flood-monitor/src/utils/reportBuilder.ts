import { getAlertConfigs } from "@/api/alertConfigApi";
import { getHistory } from "@/api/historyApi";
import { getNotifications } from "@/api/notificationApi";
import { getSensors } from "@/api/sensorApi";
import { INTERVAL_HOURS, type IHistorySeries } from "@/types/history";
import { AlertStatus, type INotification } from "@/types/notification";
import {
  REPORT_TYPE_LABEL,
  type IReportAlertRow,
  type IReportData,
  type IReportParams,
  type IReportProblem,
  type IReportSensorStat,
} from "@/types/report";
import { FloodStatus, type ISensor } from "@/types/sensor";
import { defaultInterval } from "./historyRange";
import { reportTitle } from "./reportName";
import { STATUS_META } from "./status";
import { WATER_THRESHOLDS } from "./thresholds";
import { formatPeriod } from "./time";

const COLORS = ["#3b82f6", "#ef4444", "#a855f7", "#f59e0b", "#22c55e"];
const round1 = (n: number) => Math.round(n * 10) / 10;

export const composeReport = (
  p: IReportParams,
  scope: ISensor[],
  history: IHistorySeries[],
  alerts: INotification[],
  creator: string,
  intervalHours: number,
  siagaOf: (sensorId: number) => number = () => WATER_THRESHOLDS.siaga,
): IReportData => {
  const byId = new Map(history.map((h) => [h.sensorId, h]));

  const sensorStats: IReportSensorStat[] = scope.map((s) => {
    const pts = byId.get(s.id)?.points ?? [];
    const w = pts.map((x) => x.waterLevel);
    return {
      sensorId: s.id,
      code: s.code,
      location: s.location,
      district: s.district,
      status: s.status,
      battery: s.battery,
      max: w.length ? Math.max(...w) : 0,
      min: w.length ? Math.min(...w) : 0,
      avg: w.length ? Math.round(w.reduce((a, v) => a + v, 0) / w.length) : 0,
      hoursSiaga: w.filter((v) => v >= siagaOf(s.id)).length * intervalHours,
      rainTotal: round1(pts.reduce((a, x) => a + x.rainfall, 0)),
    };
  });

  const byStatus: Record<FloodStatus, number> = {
    [FloodStatus.AMAN]: 0,
    [FloodStatus.WASPADA]: 0,
    [FloodStatus.SIAGA]: 0,
    [FloodStatus.BAHAYA]: 0,
    [FloodStatus.OFFLINE]: 0,
  };
  scope.forEach((s) => {
    byStatus[s.status] += 1;
  });

  const codes = new Set(scope.map((s) => s.code));
  const from = new Date(p.from).getTime();
  const to = new Date(p.to).getTime();
  const alertRows: IReportAlertRow[] = alerts
    .filter((a) => codes.has(a.sensorCode))
    .filter((a) => {
      const t = new Date(a.createdAt).getTime();
      return t >= from && t <= to;
    })
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
    .map((a) => ({
      id: a.id,
      time: a.createdAt,
      level: a.level,
      title: a.title,
      sensorCode: a.sensorCode,
      status: a.status,
      officer: a.officer,
      responseMin: a.respondedAt
        ? Math.max(0, Math.round((new Date(a.respondedAt).getTime() - new Date(a.createdAt).getTime()) / 60000))
        : null,
    }));

  const responses = alertRows.map((a) => a.responseMin).filter((v): v is number => v !== null);

  const problems: IReportProblem[] = scope
    .filter((s) => s.status !== FloodStatus.AMAN || s.battery < 20)
    .map((s) => {
      const issues: string[] = [];
      if (s.status !== FloodStatus.AMAN) issues.push(STATUS_META[s.status].label);
      if (s.battery < 20) issues.push(`baterai ${s.battery}%`);
      return { code: s.code, location: s.location, issue: issues.join(", ") };
    });

  const top = [...sensorStats].sort((a, b) => b.max - a.max).slice(0, 5);
  const series = top.map((t, i) => ({
    code: t.code,
    color: COLORS[i % COLORS.length],
    values: (byId.get(t.sensorId)?.points ?? []).map((x) => x.waterLevel),
  }));
  const times = (byId.get(top[0]?.sensorId ?? -1)?.points ?? []).map((x) => x.t);

  const maxSensor = [...sensorStats].sort((a, b) => b.max - a.max)[0];
  const active = scope.length - byStatus[FloodStatus.OFFLINE];

  return {
    title: reportTitle(p),
    typeLabel: REPORT_TYPE_LABEL[p.type],
    periodLabel: formatPeriod(p.from, p.to),
    areaLabel: p.areaLabel,
    generatedAt: new Date().toISOString(),
    createdBy: creator,
    includes: p.includes,
    summary: {
      totalSensor: scope.length,
      activeSensor: active,
      offlineSensor: byStatus[FloodStatus.OFFLINE],
      activePct: scope.length ? Math.round((active / scope.length) * 100) : 0,
      byStatus,
      alertTotal: alertRows.length,
      alertUnhandled: alertRows.filter((a) => a.status === AlertStatus.BELUM).length,
      avgResponseMin: responses.length ? Math.round(responses.reduce((a, v) => a + v, 0) / responses.length) : null,
      maxLevel: maxSensor && maxSensor.max > 0 ? { code: maxSensor.code, value: maxSensor.max } : null,
    },
    times,
    series,
    sensorStats,
    alerts: alertRows,
    problems,
  };
};

// Mengambil data dari API lalu menyusun laporan
export const loadReportData = async (
  p: IReportParams,
  creator: string,
  onProgress?: (pct: number) => void,
): Promise<IReportData> => {
  onProgress?.(10);
  const sensorsRes = await getSensors({ page: 1, limit: 100 });
  const all = sensorsRes.data ?? [];
  const ids = p.sensorIds;
  const scope = ids ? all.filter((s) => ids.includes(s.id)) : all;

  onProgress?.(35);
  const interval = defaultInterval({ from: p.from, to: p.to });
  const historyRes =
    scope.length > 0
      ? await getHistory({ sensorIds: scope.map((s) => s.id), from: p.from, to: p.to, interval })
      : null;

  onProgress?.(65);
  const alertsRes = await getNotifications();

  onProgress?.(80);
  const configsRes = await getAlertConfigs();
  const siaga = new Map((configsRes.data ?? []).map((c) => [c.sensorId, c.thresholds.siaga]));

  onProgress?.(90);
  const data = composeReport(
    p,
    scope,
    historyRes?.data ?? [],
    alertsRes.data ?? [],
    creator,
    INTERVAL_HOURS[interval],
    (id) => siaga.get(id) ?? WATER_THRESHOLDS.siaga,
  );
  onProgress?.(100);
  return data;
};
