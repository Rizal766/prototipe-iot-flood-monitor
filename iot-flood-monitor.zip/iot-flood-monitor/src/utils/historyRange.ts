import dayjs, { type Dayjs } from "dayjs";
import { HistoryInterval } from "@/types/history";

export type RangeKey = "today" | "7d" | "30d" | "custom";

export interface IRange {
  from: string; // ISO
  to: string; // ISO
}

export const presetRange = (key: Exclude<RangeKey, "custom">): IRange => {
  const to = dayjs();
  const from = key === "today" ? to.startOf("day") : to.subtract(key === "7d" ? 7 : 30, "day");
  return { from: from.toISOString(), to: to.toISOString() };
};

export const customRange = (a: Dayjs, b: Dayjs): IRange => {
  const end = b.endOf("day");
  const now = dayjs();
  return { from: a.startOf("day").toISOString(), to: (end.isAfter(now) ? now : end).toISOString() };
};

// Interval bawaan menurut panjang rentang agar grafik tetap terbaca
export const defaultInterval = (r: IRange): HistoryInterval => {
  const days = dayjs(r.to).diff(dayjs(r.from), "day", true);
  if (days <= 2) return HistoryInterval.HOUR;
  if (days <= 10) return HistoryInterval.SIX_HOURS;
  return HistoryInterval.DAY;
};
