import type { IAlertConfig, IAlertMatrix, IAlertRules } from "@/types/alertConfig";
import type { IThresholds } from "./thresholds";

export const defaultRules = (): IAlertRules => ({ rainfallMmPerHour: 50, offlineMinutes: 30, batteryPercent: 20 });

export const defaultMatrix = (): IAlertMatrix => ({
  WASPADA: { admin: true, operator: true, petugas: true, bpbd: false, push: true, sms: true, whatsapp: true, email: true, sirene: false },
  SIAGA: { admin: true, operator: true, petugas: true, bpbd: true, push: true, sms: true, whatsapp: true, email: true, sirene: false },
  BAHAYA: { admin: true, operator: true, petugas: true, bpbd: true, push: true, sms: true, whatsapp: true, email: true, sirene: true },
});

export const buildDefaultConfig = (
  sensorId: number,
  thresholds: IThresholds,
  updatedBy: string,
  updatedAt: string = new Date().toISOString(),
): IAlertConfig => ({
  sensorId,
  thresholds: { ...thresholds },
  rules: defaultRules(),
  matrix: defaultMatrix(),
  updatedAt,
  updatedBy,
});
