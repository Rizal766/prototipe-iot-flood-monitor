import type { Worksheet } from "exceljs";
import { FloodStatus } from "@/types/sensor";
import { AlertStatus } from "@/types/notification";
import type { IReportData } from "@/types/report";
import { LEVEL_LABEL } from "./alertLabels";
import { STATUS_META } from "./status";
import { formatDateTime } from "./time";

const styleHeader = (ws: Worksheet) => {
  const row = ws.getRow(1);
  row.font = { bold: true, color: { argb: "FFFFFFFF" } };
  row.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF2563EB" } };
  ws.views = [{ state: "frozen", ySplit: 1 }];
};

const ALERT_STATUS_TEXT: Record<AlertStatus, string> = {
  [AlertStatus.BELUM]: "Belum ditangani",
  [AlertStatus.DIPROSES]: "Diproses",
  [AlertStatus.SELESAI]: "Selesai",
};

export const buildReportExcel = async (d: IReportData): Promise<Blob> => {
  const mod = await import("exceljs");
  const Workbook = mod.Workbook ?? (mod as unknown as { default: typeof mod }).default.Workbook;
  const wb = new Workbook();
  wb.creator = d.createdBy;
  wb.created = new Date(d.generatedAt);
  const s = d.summary;

  const info = wb.addWorksheet("Ringkasan");
  info.columns = [
    { header: "Keterangan", key: "k", width: 32 },
    { header: "Nilai", key: "v", width: 44 },
  ];
  info.addRows([
    { k: "Judul", v: d.title },
    { k: "Jenis", v: d.typeLabel },
    { k: "Periode", v: d.periodLabel },
    { k: "Wilayah / Sensor", v: d.areaLabel },
    { k: "Dibuat oleh", v: d.createdBy },
    { k: "Tanggal dibuat", v: formatDateTime(d.generatedAt) },
  ]);
  if (d.includes.summary) {
    info.addRows([
      { k: "", v: "" },
      { k: "Total sensor", v: s.totalSensor },
      { k: "Sensor aktif", v: `${s.activeSensor} (${s.activePct}%)` },
      { k: "Aman", v: s.byStatus[FloodStatus.AMAN] },
      { k: "Waspada", v: s.byStatus[FloodStatus.WASPADA] },
      { k: "Siaga", v: s.byStatus[FloodStatus.SIAGA] },
      { k: "Bahaya", v: s.byStatus[FloodStatus.BAHAYA] },
      { k: "Offline", v: s.byStatus[FloodStatus.OFFLINE] },
      { k: "Tinggi air tertinggi", v: s.maxLevel ? `${s.maxLevel.value} cm (${s.maxLevel.code})` : "-" },
      { k: "Jumlah alert pada periode", v: s.alertTotal },
      { k: "Alert belum ditangani", v: s.alertUnhandled },
      { k: "Rata-rata respons (menit)", v: s.avgResponseMin ?? "-" },
    ]);
  }
  styleHeader(info);

  if (d.includes.summary) {
    const ws = wb.addWorksheet("Statistik Sensor");
    ws.columns = [
      { header: "ID Sensor", key: "code", width: 12 },
      { header: "Lokasi", key: "location", width: 28 },
      { header: "Kecamatan", key: "district", width: 18 },
      { header: "Status", key: "status", width: 12 },
      { header: "Tertinggi (cm)", key: "max", width: 14 },
      { header: "Terendah (cm)", key: "min", width: 14 },
      { header: "Rata-rata (cm)", key: "avg", width: 14 },
      { header: "Jam di atas ambang siaga", key: "hours", width: 22 },
      { header: "Curah hujan total (mm)", key: "rain", width: 20 },
      { header: "Baterai (%)", key: "battery", width: 12 },
    ];
    d.sensorStats.forEach((t) =>
      ws.addRow({
        code: t.code,
        location: t.location,
        district: t.district,
        status: STATUS_META[t.status].label,
        max: t.max,
        min: t.min,
        avg: t.avg,
        hours: t.hoursSiaga,
        rain: t.rainTotal,
        battery: t.battery,
      }),
    );
    styleHeader(ws);
  }

  if (d.includes.charts) {
    const ws = wb.addWorksheet("Data Grafik");
    ws.columns = [{ header: "Waktu", key: "t", width: 20 }, ...d.series.map((x) => ({ header: `${x.code} (cm)`, key: x.code, width: 16 }))];
    d.times.forEach((t, i) => {
      const row: Record<string, string | number> = { t: formatDateTime(t) };
      d.series.forEach((x) => {
        row[x.code] = x.values[i] ?? "";
      });
      ws.addRow(row);
    });
    styleHeader(ws);
  }

  if (d.includes.alerts) {
    const ws = wb.addWorksheet("Alert");
    ws.columns = [
      { header: "Waktu", key: "time", width: 20 },
      { header: "Level", key: "level", width: 10 },
      { header: "Judul", key: "title", width: 32 },
      { header: "Sensor", key: "sensor", width: 12 },
      { header: "Status", key: "status", width: 18 },
      { header: "Petugas", key: "officer", width: 18 },
      { header: "Respons (menit)", key: "resp", width: 16 },
    ];
    d.alerts.forEach((a) =>
      ws.addRow({
        time: formatDateTime(a.time),
        level: LEVEL_LABEL[a.level],
        title: a.title,
        sensor: a.sensorCode,
        status: ALERT_STATUS_TEXT[a.status],
        officer: a.officer ?? "-",
        resp: a.responseMin ?? "-",
      }),
    );
    styleHeader(ws);
  }

  if (d.includes.problemSensors) {
    const ws = wb.addWorksheet("Sensor Bermasalah");
    ws.columns = [
      { header: "ID Sensor", key: "code", width: 12 },
      { header: "Lokasi", key: "location", width: 30 },
      { header: "Masalah", key: "issue", width: 34 },
    ];
    d.problems.forEach((p) => ws.addRow(p));
    styleHeader(ws);
  }

  const buf = await wb.xlsx.writeBuffer();
  return new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
};
