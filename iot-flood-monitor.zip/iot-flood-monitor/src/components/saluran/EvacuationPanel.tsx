import { useMemo, useState } from "react";
import type { GridColDef } from "@mui/x-data-grid";
import { Button, Input, Modal, Switch, message } from "antd";
import { DeleteOutlined, EditOutlined, PlusOutlined } from "@ant-design/icons";
import { Controller, useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import SimpleGrid from "@/components/common/SimpleGrid";
import Panel from "@/components/dashboard/Panel";
import MapPicker from "@/components/map/MapPicker";
import { useEvacuationMutations, useEvacuationPoints } from "@/hooks/useMapData";
import { evacuationSchema, type EvacuationFormValues } from "@/schemas/notificationSettingsSchema";
import type { IEvacuationPayload, IEvacuationPoint } from "@/types/map";
import { DEFAULT_CENTER } from "@/utils/map";

const EvacuationForm = ({ point, onClose }: { point: IEvacuationPoint | "new"; onClose: () => void }) => {
  const { create, update } = useEvacuationMutations();
  const existing = point === "new" ? null : point;
  const {
    control,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<EvacuationFormValues>({
    resolver: zodResolver(evacuationSchema),
    defaultValues: {
      name: existing?.name ?? "",
      address: existing?.address ?? "",
      capacity: existing ? String(existing.capacity) : "",
      lat: String(existing?.lat ?? DEFAULT_CENTER.lat.toFixed(6)),
      lng: String(existing?.lng ?? DEFAULT_CENTER.lng.toFixed(6)),
      active: existing?.active ?? true,
    },
  });
  const v = useWatch({ control });
  const lat = Number(v.lat);
  const lng = Number(v.lng);
  const picked = v.lat && v.lng && !Number.isNaN(lat) && !Number.isNaN(lng) ? { lat, lng } : null;

  const onSubmit = async (values: EvacuationFormValues) => {
    const payload: IEvacuationPayload = {
      name: values.name.trim(),
      address: values.address.trim(),
      capacity: Number(values.capacity),
      lat: Number(values.lat),
      lng: Number(values.lng),
      active: values.active,
    };
    const res = existing ? await update.mutateAsync({ id: existing.id, payload }) : await create.mutateAsync(payload);
    if (res.status) {
      message.success(existing ? "Titik evakuasi diperbarui" : "Titik evakuasi ditambahkan");
      onClose();
    } else {
      message.error(res.message || "Gagal menyimpan titik evakuasi");
    }
  };

  const err = (m?: string) => (m ? <p className="m-0 mt-0.5 text-xs text-red-500">{m}</p> : null);
  const label = "mb-1 block text-xs font-medium text-slate-600";

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="grid grid-cols-1 gap-3 sm:grid-cols-2">
      <div className="sm:col-span-2">
        <label htmlFor="ev-name" className={label}>Nama Titik Evakuasi</label>
        <Controller name="name" control={control} render={({ field }) => <Input {...field} id="ev-name" />} />
        {err(errors.name?.message)}
      </div>
      <div className="sm:col-span-2">
        <label htmlFor="ev-address" className={label}>Alamat</label>
        <Controller name="address" control={control} render={({ field }) => <Input {...field} id="ev-address" />} />
        {err(errors.address?.message)}
      </div>
      <div>
        <label htmlFor="ev-cap" className={label}>Kapasitas (orang)</label>
        <Controller name="capacity" control={control} render={({ field }) => <Input {...field} id="ev-cap" inputMode="numeric" />} />
        {err(errors.capacity?.message)}
      </div>
      <Controller
        name="active"
        control={control}
        render={({ field }) => (
          <label className="flex items-center gap-2 pt-5 text-xs">
            <Switch size="small" checked={field.value} onChange={field.onChange} />
            Aktif (tampil di peta)
          </label>
        )}
      />
      <div className="sm:col-span-2">
        <MapPicker
          value={picked}
          height={190}
          onChange={(p) => {
            setValue("lat", p.lat.toFixed(6), { shouldValidate: true });
            setValue("lng", p.lng.toFixed(6), { shouldValidate: true });
          }}
        />
        <p className="m-0 mt-1 text-[11px] text-slate-400">Klik peta atau geser pin untuk memilih koordinat.</p>
      </div>
      <div>
        <Controller name="lat" control={control} render={({ field }) => <Input {...field} placeholder="Latitude" aria-label="Latitude" />} />
        {err(errors.lat?.message)}
      </div>
      <div>
        <Controller name="lng" control={control} render={({ field }) => <Input {...field} placeholder="Longitude" aria-label="Longitude" />} />
        {err(errors.lng?.message)}
      </div>
      <div className="flex justify-end gap-2 sm:col-span-2">
        <Button onClick={onClose}>Batal</Button>
        <Button type="primary" htmlType="submit" loading={create.isPending || update.isPending}>
          Simpan
        </Button>
      </div>
    </form>
  );
};

const EvacuationPanel = ({ canEdit }: { canEdit: boolean }) => {
  const { data, isLoading } = useEvacuationPoints();
  const points = useMemo(() => data?.data ?? [], [data]);
  const { update, remove } = useEvacuationMutations();
  const [editing, setEditing] = useState<IEvacuationPoint | "new" | null>(null);

  const toggleActive = async (p: IEvacuationPoint, active: boolean) => {
    const { id, ...rest } = p;
    const res = await update.mutateAsync({ id, payload: { ...rest, active } });
    if (!res.status) message.error(res.message || "Gagal mengubah status");
  };

  const confirmDelete = (p: IEvacuationPoint) =>
    Modal.confirm({
      title: "Hapus titik evakuasi?",
      content: p.name,
      okText: "Hapus",
      okButtonProps: { danger: true },
      cancelText: "Batal",
      onOk: async () => {
        const res = await remove.mutateAsync(p.id);
        if (res.status) message.success("Titik evakuasi dihapus");
        else message.error(res.message || "Gagal menghapus titik evakuasi");
      },
    });

  const columns: GridColDef<IEvacuationPoint>[] = [
    { field: "no", headerName: "No", width: 56, sortable: false, renderCell: (p) => p.api.getRowIndexRelativeToVisibleRows(p.row.id) + 1 },
    { field: "name", headerName: "Nama", flex: 1, minWidth: 180 },
    { field: "address", headerName: "Alamat", flex: 1, minWidth: 200 },
    {
      field: "lat",
      headerName: "Koordinat",
      width: 170,
      sortable: false,
      renderCell: (p) => (
        <span className="tabular-nums">
          {p.row.lat.toFixed(4)}, {p.row.lng.toFixed(4)}
        </span>
      ),
    },
    { field: "capacity", headerName: "Kapasitas", type: "number", width: 100, align: "left", headerAlign: "left" },
    {
      field: "active",
      headerName: "Status",
      width: 110,
      renderCell: (p) => (
        <label className="flex items-center gap-1.5">
          <Switch size="small" checked={p.row.active} disabled={!canEdit} onChange={(on) => void toggleActive(p.row, on)} />
          <span className={p.row.active ? "text-green-600" : "text-slate-400"}>{p.row.active ? "Aktif" : "Nonaktif"}</span>
        </label>
      ),
    },
    {
      field: "actions",
      headerName: "Aksi",
      width: 90,
      sortable: false,
      renderCell: (p) =>
        canEdit ? (
          <span className="flex">
            <Button size="small" type="text" aria-label="Edit titik evakuasi" icon={<EditOutlined />} onClick={() => setEditing(p.row)} />
            <Button size="small" type="text" danger aria-label="Hapus titik evakuasi" icon={<DeleteOutlined />} onClick={() => confirmDelete(p.row)} />
          </span>
        ) : null,
    },
  ];

  return (
    <Panel
      title="Titik Evakuasi"
      actions={
        canEdit && (
          <Button size="small" type="primary" icon={<PlusOutlined />} onClick={() => setEditing("new")}>
            Tambah Titik
          </Button>
        )
      }
    >
      <SimpleGrid rows={points} columns={columns} loading={isLoading} emptyText="Belum ada titik evakuasi" />
      <Modal open={editing !== null} title={editing === "new" ? "Tambah Titik Evakuasi" : "Edit Titik Evakuasi"} footer={null} onCancel={() => setEditing(null)} width={560}>
        {editing && <EvacuationForm key={editing === "new" ? "new" : editing.id} point={editing} onClose={() => setEditing(null)} />}
      </Modal>
    </Panel>
  );
};

export default EvacuationPanel;
