import { useMemo } from "react";
import { Button, Input, Modal, message } from "antd";
import { Controller, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useSettingsMutations } from "@/hooks/useNotificationSettings";
import type { IChannel } from "@/types/notificationSettings";

const Form = ({ channel, onClose }: { channel: IChannel; onClose: () => void }) => {
  const { channel: mutation } = useSettingsMutations();

  // Aturan dibangun dari daftar kolom saluran; kolom rahasia boleh kosong (tidak diubah)
  const schema = useMemo(
    () =>
      z.record(z.string(), z.string()).superRefine((v, ctx) => {
        channel.fields.forEach((f) => {
          const val = (v[f.key] ?? "").trim();
          if (!f.secret && !val) {
            ctx.addIssue({ code: "custom", path: [f.key], message: `${f.label} wajib diisi` });
            return;
          }
          if (f.key === "port" && (!/^\d+$/.test(val) || Number(val) < 1 || Number(val) > 65535)) {
            ctx.addIssue({ code: "custom", path: [f.key], message: "Port harus angka 1-65535" });
          }
          if (f.key === "endpoint" && !/^https?:\/\/\S+$/i.test(val)) {
            ctx.addIssue({ code: "custom", path: [f.key], message: "Endpoint harus diawali http:// atau https://" });
          }
        });
      }),
    [channel.fields],
  );

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<Record<string, string>>({
    resolver: zodResolver(schema),
    // nilai rahasia tidak pernah diisi ulang di form
    defaultValues: Object.fromEntries(channel.fields.map((f) => [f.key, f.secret ? "" : f.value])),
  });

  const onSubmit = async (v: Record<string, string>) => {
    const fields: Record<string, string> = {};
    channel.fields.forEach((f) => {
      const val = (v[f.key] ?? "").trim();
      if (!f.secret || val) fields[f.key] = val;
    });
    const res = await mutation.mutateAsync({ type: channel.type, fields });
    if (res.status) {
      message.success(`Konfigurasi ${channel.name} disimpan. Jalankan Uji Kirim untuk memastikan berfungsi.`);
      onClose();
    } else {
      message.error(res.message || "Gagal menyimpan konfigurasi");
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="flex flex-col gap-3">
      {channel.fields.map((f) => (
        <div key={f.key}>
          <label htmlFor={`ch-${f.key}`} className="mb-1 block text-xs font-medium text-slate-600">
            {f.label}
          </label>
          <Controller
            name={f.key}
            control={control}
            render={({ field }) =>
              f.secret ? (
                <Input.Password
                  {...field}
                  id={`ch-${f.key}`}
                  autoComplete="new-password"
                  placeholder={`Tersimpan (${f.value}) - kosongkan jika tidak diubah`}
                />
              ) : (
                <Input {...field} id={`ch-${f.key}`} status={errors[f.key] ? "error" : undefined} />
              )
            }
          />
          {errors[f.key] && <p className="m-0 mt-0.5 text-xs text-red-500">{errors[f.key]?.message}</p>}
        </div>
      ))}
      <div className="flex justify-end gap-2">
        <Button onClick={onClose}>Batal</Button>
        <Button type="primary" htmlType="submit" loading={mutation.isPending}>
          Simpan Konfigurasi
        </Button>
      </div>
    </form>
  );
};

interface IChannelConfigModalProps {
  channel: IChannel | null;
  onClose: () => void;
}

const ChannelConfigModal = ({ channel, onClose }: IChannelConfigModalProps) => (
  <Modal open={channel !== null} title={channel ? `Konfigurasi ${channel.name}` : "Konfigurasi"} footer={null} onCancel={onClose} width={480}>
    {channel && <Form key={channel.type} channel={channel} onClose={onClose} />}
  </Modal>
);

export default ChannelConfigModal;
