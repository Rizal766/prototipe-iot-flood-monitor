import { useMemo, useState } from "react";
import type { GridColDef } from "@mui/x-data-grid";
import { Button, Input, Modal, Select, Switch, message } from "antd";
import { DeleteOutlined, EditOutlined, PhoneOutlined, PlusOutlined } from "@ant-design/icons";
import { Controller, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import SimpleGrid from "@/components/common/SimpleGrid";
import Panel from "@/components/dashboard/Panel";
import { useContacts, useSettingsMutations } from "@/hooks/useNotificationSettings";
import { contactSchema, type ContactFormValues } from "@/schemas/notificationSettingsSchema";
import { CONTACT_CATEGORIES, type IEmergencyContact } from "@/types/contact";

const ContactForm = ({ contact, onClose }: { contact: IEmergencyContact | "new"; onClose: () => void }) => {
  const { addContact, editContact } = useSettingsMutations();
  const existing = contact === "new" ? null : contact;
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<ContactFormValues>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      name: existing?.name ?? "",
      phone: existing?.phone ?? "",
      category: (CONTACT_CATEGORIES.find((c) => c === existing?.category) ?? "BPBD") as ContactFormValues["category"],
      showInAlert: existing?.showInAlert ?? true,
    },
  });

  const onSubmit = async (v: ContactFormValues) => {
    const payload = { ...v, name: v.name.trim(), phone: v.phone.trim() };
    const res = existing
      ? await editContact.mutateAsync({ id: existing.id, payload })
      : await addContact.mutateAsync(payload);
    if (res.status) {
      message.success(existing ? "Kontak diperbarui" : "Kontak ditambahkan");
      onClose();
    } else {
      message.error(res.message || "Gagal menyimpan kontak");
    }
  };

  const err = (m?: string) => (m ? <p className="m-0 mt-0.5 text-xs text-red-500">{m}</p> : null);
  const label = "mb-1 block text-xs font-medium text-slate-600";

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="flex flex-col gap-3">
      <div>
        <label htmlFor="ct-name" className={label}>Nama</label>
        <Controller name="name" control={control} render={({ field }) => <Input {...field} id="ct-name" placeholder="Contoh: Posko BPBD" />} />
        {err(errors.name?.message)}
      </div>
      <div>
        <label htmlFor="ct-phone" className={label}>Nomor Telepon</label>
        <Controller name="phone" control={control} render={({ field }) => <Input {...field} id="ct-phone" placeholder="112 atau (024) 1234567" />} />
        {err(errors.phone?.message)}
      </div>
      <div>
        <label className={label}>Kategori</label>
        <Controller
          name="category"
          control={control}
          render={({ field }) => <Select {...field} className="w-full" options={CONTACT_CATEGORIES.map((c) => ({ value: c, label: c }))} />}
        />
      </div>
      <Controller
        name="showInAlert"
        control={control}
        render={({ field }) => (
          <label className="flex items-center gap-2 text-xs">
            <Switch size="small" checked={field.value} onChange={field.onChange} />
            Cantumkan nomor ini pada pesan alert
          </label>
        )}
      />
      <div className="flex justify-end gap-2">
        <Button onClick={onClose}>Batal</Button>
        <Button type="primary" htmlType="submit" loading={addContact.isPending || editContact.isPending}>
          Simpan
        </Button>
      </div>
    </form>
  );
};

const ContactsPanel = ({ canEdit }: { canEdit: boolean }) => {
  const { data, isLoading } = useContacts();
  const contacts = useMemo(() => data?.data ?? [], [data]);
  const { removeContact } = useSettingsMutations();
  const [editing, setEditing] = useState<IEmergencyContact | "new" | null>(null);

  const confirmDelete = (c: IEmergencyContact) =>
    Modal.confirm({
      title: "Hapus kontak?",
      content: `${c.name} (${c.phone})`,
      okText: "Hapus",
      okButtonProps: { danger: true },
      cancelText: "Batal",
      onOk: async () => {
        const res = await removeContact.mutateAsync(c.id);
        if (res.status) message.success("Kontak dihapus");
        else message.error(res.message || "Gagal menghapus kontak");
      },
    });

  const columns: GridColDef<IEmergencyContact>[] = [
    { field: "no", headerName: "No", width: 56, sortable: false, renderCell: (p) => p.api.getRowIndexRelativeToVisibleRows(p.row.id) + 1 },
    { field: "name", headerName: "Nama", flex: 1, minWidth: 160 },
    {
      field: "phone",
      headerName: "Nomor Telepon",
      width: 140,
      renderCell: (p) => (
        <a href={`tel:${p.row.phone.replace(/[^\d+]/g, "")}`} className="flex items-center gap-1.5 text-blue-600 no-underline">
          <PhoneOutlined /> {p.row.phone}
        </a>
      ),
    },
    { field: "category", headerName: "Kategori", width: 150 },
    {
      field: "showInAlert",
      headerName: "Di Alert",
      width: 80,
      renderCell: (p) => (p.row.showInAlert ? <span className="font-semibold text-green-600">Ya</span> : <span className="text-slate-400">Tidak</span>),
    },
    {
      field: "actions",
      headerName: "Aksi",
      width: 90,
      sortable: false,
      renderCell: (p) =>
        canEdit ? (
          <span className="flex">
            <Button size="small" type="text" aria-label="Edit kontak" icon={<EditOutlined />} onClick={() => setEditing(p.row)} />
            <Button size="small" type="text" danger aria-label="Hapus kontak" icon={<DeleteOutlined />} onClick={() => confirmDelete(p.row)} />
          </span>
        ) : null,
    },
  ];

  return (
    <Panel
      title="Kontak Darurat"
      actions={
        canEdit && (
          <Button size="small" type="primary" icon={<PlusOutlined />} onClick={() => setEditing("new")}>
            Tambah Kontak
          </Button>
        )
      }
    >
      <SimpleGrid rows={contacts} columns={columns} loading={isLoading} emptyText="Belum ada kontak darurat" />
      <Modal open={editing !== null} title={editing === "new" ? "Tambah Kontak Darurat" : "Edit Kontak Darurat"} footer={null} onCancel={() => setEditing(null)} width={440}>
        {editing && <ContactForm key={editing === "new" ? "new" : editing.id} contact={editing} onClose={() => setEditing(null)} />}
      </Modal>
    </Panel>
  );
};

export default ContactsPanel;
