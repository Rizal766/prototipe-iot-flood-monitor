import type { ReactNode } from "react";
import { Button, Switch } from "antd";
import {
  ApiOutlined,
  BellFilled,
  MailFilled,
  MessageFilled,
  SoundFilled,
  WhatsAppOutlined,
} from "@ant-design/icons";
import { ChannelHealth, ChannelType, type IChannel } from "@/types/notificationSettings";
import { formatAgoShort, formatDateTime } from "@/utils/time";

const ICON: Record<ChannelType, { node: ReactNode; color: string }> = {
  [ChannelType.SMS]: { node: <MessageFilled />, color: "#0ea5e9" },
  [ChannelType.WHATSAPP]: { node: <WhatsAppOutlined />, color: "#22c55e" },
  [ChannelType.EMAIL]: { node: <MailFilled />, color: "#ef4444" },
  [ChannelType.PUSH]: { node: <BellFilled />, color: "#f97316" },
  [ChannelType.SIREN]: { node: <SoundFilled />, color: "#f59e0b" },
  [ChannelType.API]: { node: <ApiOutlined />, color: "#0369a1" },
};

interface IChannelCardProps {
  channel: IChannel;
  enabled: boolean; // nilai draft pada form
  canEdit: boolean;
  testing: boolean;
  onToggle: (on: boolean) => void;
  onTest: () => void;
  onConfig: () => void;
}

const ChannelCard = ({ channel: c, enabled, canEdit, testing, onToggle, onTest, onConfig }: IChannelCardProps) => {
  const trouble = c.health === ChannelHealth.GANGGUAN;
  const status = !enabled
    ? { text: "Nonaktif", cls: "bg-slate-100 text-slate-500" }
    : trouble
      ? { text: "Gangguan", cls: "bg-red-100 text-red-600" }
      : { text: "Aktif", cls: "bg-green-100 text-green-700" };
  const icon = ICON[c.type];

  return (
    <article className="flex min-w-0 flex-col gap-3 rounded-lg border border-slate-200 bg-white p-3 shadow-sm">
      <header className="flex items-center gap-3">
        <span className="text-3xl" style={{ color: icon.color }}>
          {icon.node}
        </span>
        <h3 className="m-0 flex-1 text-sm font-semibold">{c.name}</h3>
        <span className={`rounded px-2 py-0.5 text-[11px] font-semibold ${status.cls}`}>{status.text}</span>
        <Switch size="small" checked={enabled} disabled={!canEdit} onChange={onToggle} aria-label={`Aktifkan ${c.name}`} />
      </header>

      <dl className="m-0 grid grid-cols-[110px_minmax(0,1fr)] gap-x-2 gap-y-0.5 text-xs">
        {c.fields.map((f) => (
          <div key={f.key} className="contents">
            <dt className="text-slate-500">{f.label}</dt>
            <dd className="m-0 truncate font-medium" title={f.value}>
              {f.value || "-"}
            </dd>
          </div>
        ))}
      </dl>

      <footer className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-2 text-[11px] text-slate-500">
        <span>
          Pengiriman Terakhir: {c.lastDeliveryAt ? formatDateTime(c.lastDeliveryAt) : "belum pernah"}
          {c.lastTest && (
            <>
              {" · "}
              <b className={c.lastTest.ok ? "text-green-600" : "text-red-500"}>{c.lastTest.ok ? "Uji berhasil" : "Uji gagal"}</b>{" "}
              {formatAgoShort(c.lastTest.at)}
            </>
          )}
        </span>
        <span className="flex gap-1.5">
          <Button size="small" loading={testing} disabled={!enabled} onClick={onTest}>
            Uji Kirim
          </Button>
          <Button size="small" disabled={!canEdit} onClick={onConfig}>
            Konfigurasi
          </Button>
        </span>
      </footer>
    </article>
  );
};

export default ChannelCard;
