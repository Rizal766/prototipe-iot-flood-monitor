import { useRef, useState } from "react";
import { Input } from "antd";
import type { TextAreaRef } from "antd/es/input/TextArea";
import Panel from "@/components/dashboard/Panel";
import {
  TEMPLATE_KEYS,
  TEMPLATE_LABEL,
  type IMessageTemplate,
  type ITemplates,
  type TemplateKey,
} from "@/types/notificationSettings";
import { TEMPLATE_VARS, renderTemplate, unknownVars } from "@/utils/templateVars";
import { formatDateTime } from "@/utils/time";

const COLOR: Record<TemplateKey, string> = { BAHAYA: "#ef4444", SIAGA: "#f97316", WASPADA: "#eab308", NORMAL: "#22c55e" };
const SAMPLE_LEVEL: Record<TemplateKey, string> = { BAHAYA: "205", SIAGA: "150", WASPADA: "105", NORMAL: "45" };
const MAX_BODY = 480;
const SMS_SEGMENT = 160;

interface ITemplatePanelProps {
  templates: ITemplates;
  canEdit: boolean;
  onChange: (key: TemplateKey, t: IMessageTemplate) => void;
}

const TemplatePanel = ({ templates, canEdit, onChange }: ITemplatePanelProps) => {
  const [tab, setTab] = useState<TemplateKey>("BAHAYA");
  const ref = useRef<TextAreaRef>(null);
  const tpl = templates[tab];

  const unknown = unknownVars(`${tpl.title} ${tpl.body}`);
  const vars = {
    sensor: "SMG-015",
    lokasi: "Sungai Muktiharjo (Kali Timo)",
    tinggi: SAMPLE_LEVEL[tab],
    status: TEMPLATE_LABEL[tab].toUpperCase(),
    waktu: formatDateTime(new Date().toISOString()),
  };

  const insertVar = (name: string) => {
    const el = ref.current?.resizableTextArea?.textArea;
    const start = el?.selectionStart ?? tpl.body.length;
    const end = el?.selectionEnd ?? start;
    const body = `${tpl.body.slice(0, start)}{${name}}${tpl.body.slice(end)}`.slice(0, MAX_BODY);
    onChange(tab, { ...tpl, body });
    setTimeout(() => {
      el?.focus();
      el?.setSelectionRange(start + name.length + 2, start + name.length + 2);
    }, 0);
  };

  return (
    <Panel title="Template Pesan & Notifikasi">
      <div className="mb-3 flex gap-1.5 overflow-x-auto" role="tablist">
        {TEMPLATE_KEYS.map((k) => (
          <button
            key={k}
            type="button"
            role="tab"
            aria-selected={tab === k}
            onClick={() => setTab(k)}
            className={`flex shrink-0 cursor-pointer items-center gap-1.5 rounded-md border px-3 py-1 text-xs font-medium ${
              tab === k ? "border-blue-600 bg-blue-50 text-blue-700" : "border-slate-200 bg-white text-slate-600"
            }`}
          >
            <span className="h-2.5 w-2.5 rounded-full" style={{ background: COLOR[k] }} />
            {TEMPLATE_LABEL[k]}
          </button>
        ))}
      </div>

      <label htmlFor="tpl-title" className="mb-1 block text-xs font-medium text-slate-600">
        Judul (Email & Push)
      </label>
      <Input id="tpl-title" value={tpl.title} disabled={!canEdit} maxLength={80} onChange={(e) => onChange(tab, { ...tpl, title: e.target.value })} />

      <label htmlFor="tpl-body" className="mb-1 mt-3 block text-xs font-medium text-slate-600">
        Isi Pesan (SMS, WhatsApp, Email, Push)
      </label>
      <Input.TextArea
        id="tpl-body"
        ref={ref}
        rows={5}
        value={tpl.body}
        disabled={!canEdit}
        maxLength={MAX_BODY}
        onChange={(e) => onChange(tab, { ...tpl, body: e.target.value })}
      />
      <div className="mt-1 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500">
        <span className="flex flex-wrap items-center gap-1">
          Sisipkan:
          {TEMPLATE_VARS.map((v) => (
            <button
              key={v}
              type="button"
              disabled={!canEdit}
              onClick={() => insertVar(v)}
              className="cursor-pointer rounded border border-slate-200 bg-slate-50 px-1.5 py-0.5 text-[11px] text-slate-700 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {`{${v}}`}
            </button>
          ))}
        </span>
        <span>
          {tpl.body.length}/{MAX_BODY} · ±{Math.max(1, Math.ceil(tpl.body.length / SMS_SEGMENT))} SMS
        </span>
      </div>
      {unknown.length > 0 && (
        <p className="m-0 mt-1 text-[11px] text-red-500">Placeholder tidak dikenal: {unknown.map((u) => `{${u}}`).join(", ")}</p>
      )}
      {!tpl.body.trim() && <p className="m-0 mt-1 text-[11px] text-red-500">Isi pesan tidak boleh kosong</p>}

      <p className="m-0 mb-1 mt-3 text-xs font-semibold">Preview Pesan</p>
      <div className="rounded-md border p-3 text-xs" style={{ borderColor: COLOR[tab], background: `${COLOR[tab]}12` }}>
        <p className="m-0 font-bold" style={{ color: COLOR[tab] }}>
          {renderTemplate(tpl.title, vars)}
        </p>
        <p className="m-0 mt-1 whitespace-pre-wrap break-words text-slate-700">{renderTemplate(tpl.body, vars)}</p>
      </div>
    </Panel>
  );
};

export default TemplatePanel;
