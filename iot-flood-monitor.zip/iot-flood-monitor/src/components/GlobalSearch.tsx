import { useMemo, useRef, useState } from "react";
import { AutoComplete, Input } from "antd";
import { EnvironmentOutlined, SearchOutlined, WifiOutlined } from "@ant-design/icons";
import { useNavigate } from "react-router-dom";
import { useSensors } from "@/hooks/useSensors";
import { useMapStore } from "@/stores/useMapStore";
import { useSensorStore } from "@/stores/useSensorStore";
import { STATUS_META } from "@/utils/status";

const MAX_SENSORS = 6;
const MAX_AREAS = 3;

// Pencarian di header: sensor, sungai, dan kecamatan. Memilih hasil membuka Peta Monitoring.
const GlobalSearch = () => {
  const navigate = useNavigate();
  const { data } = useSensors({ page: 1, limit: 100 });
  const sensors = useMemo(() => data?.data ?? [], [data]);
  const selectSensor = useSensorStore((s) => s.selectSensor);
  const flyTo = useMapStore((s) => s.flyTo);
  const resetFilters = useMapStore((s) => s.resetFilters);
  const setDistrict = useMapStore((s) => s.setDistrict);
  const setRiver = useMapStore((s) => s.setRiver);

  const [text, setText] = useState("");
  const justPicked = useRef(false);

  const options = useMemo(() => {
    const q = text.trim().toLowerCase();
    if (!q) return [];
    const match = (...fields: string[]) => fields.some((f) => f.toLowerCase().includes(q));

    const sensorHits = sensors.filter((s) => match(s.code, s.location, s.river, s.district)).slice(0, MAX_SENSORS);
    const districtHits = [...new Set(sensors.map((s) => s.district))].filter((d) => match(d)).slice(0, MAX_AREAS);
    const riverHits = [...new Set(sensors.map((s) => s.river))].filter((r) => match(r)).slice(0, MAX_AREAS);

    const groups = [];
    if (sensorHits.length) {
      groups.push({
        label: "Sensor",
        options: sensorHits.map((s) => ({
          value: `s:${s.id}`,
          label: (
            <span className="flex items-center gap-2 text-xs">
              <WifiOutlined />
              <span className="font-semibold">{s.code}</span>
              <span className="min-w-0 flex-1 truncate text-slate-500">{s.location}</span>
              <span style={{ color: STATUS_META[s.status].color }}>{STATUS_META[s.status].label}</span>
            </span>
          ),
        })),
      });
    }
    const areaOptions = [
      ...districtHits.map((d) => ({ value: `d:${d}`, text: `Kecamatan ${d}` })),
      ...riverHits.map((r) => ({ value: `r:${r}`, text: `Sungai ${r}` })),
    ];
    if (areaOptions.length) {
      groups.push({
        label: "Wilayah",
        options: areaOptions.map((o) => ({
          value: o.value,
          label: (
            <span className="flex items-center gap-2 text-xs">
              <EnvironmentOutlined />
              {o.text}
            </span>
          ),
        })),
      });
    }
    return groups;
  }, [text, sensors]);

  const handleSelect = (value: string) => {
    justPicked.current = true;
    const [kind, ...rest] = value.split(":");
    const key = rest.join(":");
    resetFilters(); // pastikan hasil pilihan tidak tersembunyi oleh filter lama di peta
    if (kind === "s") {
      const sensor = sensors.find((s) => s.id === Number(key));
      if (sensor) {
        selectSensor(sensor.id);
        flyTo({ lat: sensor.lat, lng: sensor.lng });
      }
    } else if (kind === "d") {
      setDistrict(key);
    } else if (kind === "r") {
      setRiver(key);
    }
    navigate("/peta");
  };

  return (
    <AutoComplete
      className="w-full"
      value={text}
      options={options}
      popupMatchSelectWidth={380}
      notFoundContent={text.trim() ? "Sensor atau wilayah tidak ditemukan" : null}
      onSearch={setText}
      onSelect={handleSelect}
      onChange={(v) => {
        // antd mengirim nilai opsi ke onChange setelah memilih; kosongkan kolom sebagai gantinya
        if (justPicked.current) {
          justPicked.current = false;
          setText("");
        } else {
          setText(v);
        }
      }}
    >
      <Input
        size="large"
        allowClear
        prefix={<SearchOutlined />}
        placeholder="Cari lokasi, sensor, atau nama daerah..."
        className="!bg-blue-50"
        aria-label="Cari lokasi, sensor, atau nama daerah"
      />
    </AutoComplete>
  );
};

export default GlobalSearch;
