import { divIcon, type DivIcon } from "leaflet";
import { FloodStatus } from "@/types/sensor";
import { STATUS_META } from "@/utils/status";

const cache = new Map<string, DivIcon>();

export const sensorIcon = (status: FloodStatus, active: boolean): DivIcon => {
  const key = `${status}-${active}`;
  const hit = cache.get(key);
  if (hit) return hit;
  const size = active ? 22 : 16;
  const pulse = active && status === FloodStatus.BAHAYA ? " is-pulse" : "";
  const icon = divIcon({
    className: "",
    html: `<span class="sensor-pin${pulse}" style="background:${STATUS_META[status].color}"></span>`,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
  });
  cache.set(key, icon);
  return icon;
};

export const clusterIcon = (count: number): DivIcon =>
  divIcon({
    className: "",
    html: `<span class="cluster-pin"><span>${count}</span></span>`,
    iconSize: [36, 36],
    iconAnchor: [18, 18],
  });

export const evacuationIcon: DivIcon = divIcon({
  className: "",
  html: '<span class="evac-pin"><svg viewBox="0 0 24 24" width="12" height="12" fill="#fff"><path d="M12 3 2 12h3v8h5v-5h4v5h5v-8h3z"/></svg></span>',
  iconSize: [22, 22],
  iconAnchor: [11, 11],
});

export const myLocationIcon: DivIcon = divIcon({
  className: "",
  html: '<span class="me-pin"></span>',
  iconSize: [18, 18],
  iconAnchor: [9, 9],
});

export const pickIcon: DivIcon = divIcon({
  className: "",
  html: '<span class="pick-pin"></span>',
  iconSize: [20, 20],
  iconAnchor: [10, 10],
});
