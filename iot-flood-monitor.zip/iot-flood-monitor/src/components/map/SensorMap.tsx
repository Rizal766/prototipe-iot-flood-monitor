import { useCallback, useEffect, useMemo, useState } from "react";
import { latLngBounds } from "leaflet";
import {
  MapContainer,
  Marker,
  Polyline,
  Popup,
  ScaleControl,
  TileLayer,
  useMap,
  useMapEvents,
} from "react-leaflet";
import { Button } from "antd";
import { CloseOutlined } from "@ant-design/icons";
import type { LatLngTuple } from "@/api/overpassApi";
import { useMapStore } from "@/stores/useMapStore";
import type { BaseMap, IEvacuationPoint, IGeoPoint } from "@/types/map";
import { FloodStatus, type ISensor } from "@/types/sensor";
import { STATUS_META, formatTrend } from "@/utils/status";
import { DEFAULT_CENTER, DEFAULT_ZOOM, TILES, buildMapItems } from "@/utils/map";
import { clusterIcon, evacuationIcon, myLocationIcon, sensorIcon } from "./icons";

// Menghubungkan instance peta ke store (zoom, fokus, layar penuh)
const MapController = () => {
  const map = useMap();
  const setMap = useMapStore((s) => s.setMap);
  const setZoom = useMapStore((s) => s.setZoom);
  const focus = useMapStore((s) => s.focus);
  const clearFocus = useMapStore((s) => s.clearFocus);

  useEffect(() => {
    setMap(map);
    setZoom(map.getZoom());
    return () => setMap(null);
  }, [map, setMap, setZoom]);

  useMapEvents({ zoomend: () => setZoom(map.getZoom()) });

  useEffect(() => {
    if (!focus) return;
    map.flyTo([focus.lat, focus.lng], focus.zoom, { duration: 0.8 });
    clearFocus();
  }, [focus, map, clearFocus]);

  useEffect(() => {
    const onChange = () => setTimeout(() => map.invalidateSize(), 150);
    document.addEventListener("fullscreenchange", onChange);
    return () => document.removeEventListener("fullscreenchange", onChange);
  }, [map]);

  return null;
};

// Menyesuaikan tampilan awal agar semua sensor yang diberikan terlihat
const FitToSensors = ({ sensors }: { sensors: ISensor[] }) => {
  const map = useMap();
  const bounds = useMemo(
    () => (sensors.length > 0 ? latLngBounds(sensors.map((s) => [s.lat, s.lng] as LatLngTuple)) : null),
    [sensors],
  );
  useEffect(() => {
    if (bounds) map.fitBounds(bounds.pad(0.3), { maxZoom: 14 });
  }, [map, bounds]);
  return null;
};

interface ISensorMarkersProps {
  sensors: ISensor[];
  selectedId: number | null;
  dismissedId: number | null;
  onSelect: (id: number) => void;
  onDismiss: (id: number) => void;
  onDetail?: () => void;
}

const SensorMarkers = ({ sensors, selectedId, dismissedId, onSelect, onDismiss, onDetail }: ISensorMarkersProps) => {
  const map = useMap();
  const [tick, setTick] = useState(0);
  const bump = () => setTick((t) => t + 1);
  useMapEvents({ moveend: bump, zoomend: bump, resize: bump });

  const items = useMemo(() => {
    const size = map.getSize();
    return buildMapItems(
      sensors,
      (lat, lng) => map.latLngToContainerPoint([lat, lng]),
      { w: size.x, h: size.y },
      map.getZoom(),
    );
    // tick memicu hitung ulang saat peta bergeser/zoom
  }, [sensors, map, tick]);

  const popupItem =
    selectedId !== null && dismissedId !== selectedId
      ? items.find((it) => it.kind === "single" && it.sensor.id === selectedId)
      : undefined;
  const popupSensor = popupItem?.kind === "single" ? popupItem.sensor : null;

  return (
    <>
      {items.map((it) =>
        it.kind === "cluster" ? (
          <Marker
            key={`c-${it.key}`}
            position={[it.lat, it.lng]}
            icon={clusterIcon(it.members.length)}
            eventHandlers={{
              click: () =>
                map.fitBounds(latLngBounds(it.members.map((m) => [m.lat, m.lng] as LatLngTuple)).pad(0.4), {
                  maxZoom: 17,
                }),
            }}
          />
        ) : (
          <Marker
            key={it.sensor.id}
            position={[it.sensor.lat, it.sensor.lng]}
            icon={sensorIcon(it.sensor.status, it.sensor.id === selectedId)}
            zIndexOffset={it.sensor.id === selectedId ? 1000 : 0}
            eventHandlers={{ click: () => onSelect(it.sensor.id) }}
          />
        ),
      )}

      {popupSensor && (
        <Popup
          key={popupSensor.id}
          position={[popupSensor.lat, popupSensor.lng]}
          offset={[0, -12]}
          closeButton={false}
          closeOnClick={false}
          autoClose={false}
          autoPan={false}
          className="sensor-popup"
        >
          <div className="w-48 text-[11px] leading-snug">
            <div className="flex items-start justify-between gap-2">
              <p className="m-0 font-semibold">#{popupSensor.code}</p>
              <button
                type="button"
                aria-label="Tutup"
                onClick={() => onDismiss(popupSensor.id)}
                className="cursor-pointer border-none bg-transparent p-0 text-white/70"
              >
                <CloseOutlined />
              </button>
            </div>
            <p className="m-0 text-white/80">{popupSensor.location}</p>
            <p className="m-0">
              Tinggi Air: <b>{popupSensor.status === FloodStatus.OFFLINE ? "-" : `${popupSensor.waterLevel} cm`}</b>
            </p>
            <p className="m-0">
              Status:{" "}
              <b style={{ color: STATUS_META[popupSensor.status].color }}>{STATUS_META[popupSensor.status].label}</b>
            </p>
            <p className="m-0">Tren: {formatTrend(popupSensor.trend)}</p>
            <p className="m-0 text-white/70">
              Koordinat: {popupSensor.lat.toFixed(4)}, {popupSensor.lng.toFixed(4)}
            </p>
            {onDetail && (
              <Button size="small" type="primary" block className="mt-1.5" onClick={onDetail}>
                Detail
              </Button>
            )}
          </div>
        </Popup>
      )}
    </>
  );
};

interface ISensorMapProps {
  sensors: ISensor[];
  selectedId: number | null;
  onSelect: (id: number) => void;
  baseMap?: BaseMap;
  evacuation?: IEvacuationPoint[];
  rivers?: LatLngTuple[][];
  districts?: LatLngTuple[][];
  radarUrl?: string | null;
  myLocation?: IGeoPoint | null;
  onDetail?: () => void;
  fitToSensors?: boolean;
}

const SensorMap = ({
  sensors,
  selectedId,
  onSelect,
  baseMap = "peta",
  evacuation,
  rivers,
  districts,
  radarUrl,
  myLocation,
  onDetail,
  fitToSensors,
}: ISensorMapProps) => {
  const tile = TILES[baseMap];
  const [dismissedId, setDismissedId] = useState<number | null>(null);

  const handleSelect = useCallback(
    (id: number) => {
      setDismissedId(null);
      onSelect(id);
    },
    [onSelect],
  );

  return (
    <MapContainer
      center={[DEFAULT_CENTER.lat, DEFAULT_CENTER.lng]}
      zoom={DEFAULT_ZOOM}
      minZoom={5}
      maxZoom={tile.maxZoom}
      zoomControl={false}
      className="h-full w-full"
    >
      <TileLayer key={baseMap} url={tile.url} attribution={tile.attribution} maxZoom={tile.maxZoom} />
      <MapController />
      {fitToSensors && <FitToSensors sensors={sensors} />}
      <ScaleControl position="bottomleft" imperial={false} />

      {radarUrl && <TileLayer key={radarUrl} url={radarUrl} opacity={0.6} maxNativeZoom={7} zIndex={5} />}
      {districts && districts.length > 0 && (
        <Polyline
          positions={districts}
          pathOptions={{
            color: baseMap === "satelit" ? "#f8fafc" : "#7c3aed",
            weight: 1.5,
            dashArray: "6 4",
            interactive: false,
          }}
        />
      )}
      {rivers && rivers.length > 0 && (
        <Polyline positions={rivers} pathOptions={{ color: "#2563eb", weight: 2, opacity: 0.85, interactive: false }} />
      )}

      {(evacuation ?? []).map((e) => (
        <Marker key={`e-${e.id}`} position={[e.lat, e.lng]} icon={evacuationIcon} title={`${e.name} (kapasitas ${e.capacity})`} />
      ))}

      <SensorMarkers
        sensors={sensors}
        selectedId={selectedId}
        dismissedId={dismissedId}
        onSelect={handleSelect}
        onDismiss={setDismissedId}
        onDetail={onDetail}
      />

      {myLocation && <Marker position={[myLocation.lat, myLocation.lng]} icon={myLocationIcon} title="Lokasi Anda" />}
    </MapContainer>
  );
};

export default SensorMap;
