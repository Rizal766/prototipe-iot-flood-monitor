import { MapContainer, Marker, TileLayer, useMapEvents } from "react-leaflet";
import type { Marker as LeafletMarker } from "leaflet";
import type { IGeoPoint } from "@/types/map";
import { DEFAULT_CENTER, TILES } from "@/utils/map";
import { pickIcon } from "./icons";

const ClickHandler = ({ onPick }: { onPick: (p: IGeoPoint) => void }) => {
  useMapEvents({ click: (e) => onPick({ lat: e.latlng.lat, lng: e.latlng.lng }) });
  return null;
};

interface IMapPickerProps {
  value: IGeoPoint | null;
  onChange: (p: IGeoPoint) => void;
  height?: number;
}

// Klik peta atau geser pin untuk memilih koordinat
const MapPicker = ({ value, onChange, height = 170 }: IMapPickerProps) => {
  const center = value ?? DEFAULT_CENTER;
  return (
    <div className="isolate overflow-hidden rounded-md border border-slate-200" style={{ height }}>
      <MapContainer center={[center.lat, center.lng]} zoom={value ? 14 : 12} className="h-full w-full">
        <TileLayer url={TILES.peta.url} attribution={TILES.peta.attribution} maxZoom={TILES.peta.maxZoom} />
        <ClickHandler onPick={onChange} />
        {value && (
          <Marker
            position={[value.lat, value.lng]}
            icon={pickIcon}
            draggable
            eventHandlers={{
              dragend: (e) => {
                const ll = (e.target as LeafletMarker).getLatLng();
                onChange({ lat: ll.lat, lng: ll.lng });
              },
            }}
          />
        )}
      </MapContainer>
    </div>
  );
};

export default MapPicker;
