const batteryColor = (pct: number): string => (pct < 20 ? "#ef4444" : pct < 50 ? "#f59e0b" : "#22c55e");

const BatteryIcon = ({ percent }: { percent: number }) => {
  const color = batteryColor(percent);
  return (
    <span className="inline-flex items-center gap-1.5">
      <svg width="12" height="20" viewBox="0 0 12 20" aria-hidden="true">
        <rect x="4" y="0.5" width="4" height="2" rx="0.5" fill={color} />
        <rect x="1" y="2.5" width="10" height="17" rx="2" fill="none" stroke={color} strokeWidth="1.2" />
        <rect x="2.6" y={4 + (1 - Math.min(100, percent) / 100) * 14} width="6.8" height={(Math.min(100, percent) / 100) * 14} rx="0.8" fill={color} />
      </svg>
      <span className="text-[11px] font-semibold" style={{ color: percent < 50 ? color : "#475569" }}>
        {percent}%
      </span>
    </span>
  );
};

export default BatteryIcon;
