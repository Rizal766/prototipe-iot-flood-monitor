import { useMemo } from "react";
import {
  DataGrid,
  type GridColDef,
  type GridPaginationModel,
  type GridRowSelectionModel,
} from "@mui/x-data-grid";
import { Button, Checkbox, Pagination, Select } from "antd";
import { EditOutlined, UnorderedListOutlined } from "@ant-design/icons";
import StatusBadge from "@/components/StatusBadge";
import BatteryIcon from "./BatteryIcon";
import SignalBars from "./SignalBars";
import { FloodStatus, type ISensor } from "@/types/sensor";
import { STATUS_SEVERITY } from "@/utils/status";
import { formatAgo } from "@/utils/time";

const PAGE_SIZES = [10, 25, 50];

const NoRows = () => (
  <div className="flex h-full items-center justify-center text-sm text-slate-400">Tidak ada sensor yang cocok</div>
);

interface ISensorTableProps {
  rows: ISensor[];
  loading: boolean;
  selection: GridRowSelectionModel;
  selectedCount: number;
  paging: GridPaginationModel;
  canEdit: boolean;
  onSelectionChange: (m: GridRowSelectionModel) => void;
  onPagingChange: (m: GridPaginationModel) => void;
  onToggleSelectAll: () => void;
  onExportSelected: () => void;
  onView: (s: ISensor) => void;
  onEdit: (s: ISensor) => void;
}

const SensorTable = ({
  rows,
  loading,
  selection,
  selectedCount,
  paging,
  canEdit,
  onSelectionChange,
  onPagingChange,
  onToggleSelectAll,
  onExportSelected,
  onView,
  onEdit,
}: ISensorTableProps) => {
  const columns = useMemo<GridColDef<ISensor>[]>(
    () => [
      {
        field: "code",
        headerName: "ID Sensor",
        width: 110,
        renderCell: (p) => <span className="font-medium">#{p.row.code}</span>,
      },
      {
        field: "location",
        headerName: "Nama Lokasi & Sungai",
        flex: 1,
        minWidth: 220,
        renderCell: (p) => (
          <div className="leading-tight">
            <div className="font-medium">{p.row.location}</div>
            <div className="text-[11px] text-slate-500">Sungai {p.row.river}</div>
          </div>
        ),
      },
      {
        field: "waterLevel",
        headerName: "Tinggi Air (cm)",
        type: "number",
        width: 150,
        align: "left",
        headerAlign: "left",
        renderCell: (p) => {
          if (p.row.status === FloodStatus.OFFLINE) return <span className="text-slate-400">-</span>;
          const t = p.row.trend;
          return (
            <span>
              <b>{p.row.waterLevel}</b>{" "}
              <span className={`text-[11px] font-semibold ${t > 0 ? "text-red-500" : t < 0 ? "text-green-600" : "text-slate-400"}`}>
                {t > 0 ? `↑ +${t}` : t < 0 ? `↓ ${t}` : "0"}
              </span>
            </span>
          );
        },
      },
      {
        field: "status",
        headerName: "Status",
        width: 120,
        sortComparator: (a: FloodStatus, b: FloodStatus) => STATUS_SEVERITY[a] - STATUS_SEVERITY[b],
        renderCell: (p) => <StatusBadge status={p.row.status} />,
      },
      {
        field: "battery",
        headerName: "Baterai",
        type: "number",
        width: 100,
        align: "left",
        headerAlign: "left",
        renderCell: (p) => <BatteryIcon percent={p.row.battery} />,
      },
      {
        field: "signal",
        headerName: "Sinyal",
        type: "number",
        width: 110,
        align: "left",
        headerAlign: "left",
        renderCell: (p) => <SignalBars level={p.row.signal} network={p.row.network} />,
      },
      {
        field: "lastSeenMinutes",
        headerName: "Update Terakhir",
        width: 140,
        sortComparator: (a: number | null, b: number | null) => (a ?? Infinity) - (b ?? Infinity),
        renderCell: (p) => <span className="text-xs text-slate-600">{formatAgo(p.row.lastSeenMinutes)}</span>,
      },
      {
        field: "actions",
        headerName: "Aksi",
        width: 170,
        sortable: false,
        filterable: false,
        disableColumnMenu: true,
        renderCell: (p) => (
          <span className="flex gap-1.5">
            <Button size="small" type="primary" icon={<UnorderedListOutlined />} onClick={() => onView(p.row)}>
              Lihat
            </Button>
            <Button size="small" icon={<EditOutlined />} disabled={!canEdit} onClick={() => onEdit(p.row)}>
              Edit
            </Button>
          </span>
        ),
      },
    ],
    [canEdit, onView, onEdit],
  );

  const allSelected = rows.length > 0 && selectedCount === rows.length;

  return (
    <div className="rounded-lg border border-slate-200 bg-white p-2 shadow-sm">
      <DataGrid
        rows={rows}
        columns={columns}
        loading={loading}
        autoHeight
        rowHeight={56}
        columnHeaderHeight={44}
        hideFooter
        checkboxSelection
        disableRowSelectionOnClick
        disableColumnMenu
        rowSelectionModel={selection}
        onRowSelectionModelChange={onSelectionChange}
        paginationModel={paging}
        onPaginationModelChange={onPagingChange}
        pageSizeOptions={PAGE_SIZES}
        slots={{ noRowsOverlay: NoRows }}
        sx={{
          border: 0,
          fontSize: 12,
          "& .MuiDataGrid-columnHeaders": { backgroundColor: "#f8fafc" },
          "& .MuiDataGrid-columnHeaderTitle": { fontWeight: 600 },
          "& .MuiDataGrid-overlayWrapper": { minHeight: 120 },
        }}
      />

      <div className="mt-2 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-2 text-xs text-slate-600">
        <div className="flex items-center gap-3">
          <Checkbox checked={allSelected} indeterminate={selectedCount > 0 && !allSelected} onChange={onToggleSelectAll}>
            Pilih Semua
          </Checkbox>
          <Button size="small" disabled={selectedCount === 0} onClick={onExportSelected}>
            Ekspor CSV ({selectedCount})
          </Button>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <span>Tampilkan</span>
          <Select
            size="small"
            value={paging.pageSize}
            onChange={(v) => onPagingChange({ page: 0, pageSize: v })}
            options={PAGE_SIZES.map((n) => ({ value: n, label: n }))}
          />
          <span>baris per halaman</span>
          <Pagination
            size="small"
            current={paging.page + 1}
            pageSize={paging.pageSize}
            total={rows.length}
            showSizeChanger={false}
            onChange={(p) => onPagingChange({ ...paging, page: p - 1 })}
          />
        </div>
      </div>
    </div>
  );
};

export default SensorTable;
