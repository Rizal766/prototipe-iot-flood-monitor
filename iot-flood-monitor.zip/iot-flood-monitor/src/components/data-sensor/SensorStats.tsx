import { memo, type ReactNode } from "react";
import {
  BellFilled,
  CheckCircleFilled,
  DisconnectOutlined,
  WarningFilled,
} from "@ant-design/icons";
import { FloodStatus } from "@/types/sensor";
import type { StatusFilter } from "@/types/map";
import { STATUS_META } from "@/utils/status";

interface ICardDef {
  status: FloodStatus;
  label: string;
  icon: ReactNode;
}

const CARDS: ICardDef[] = [
  { status: FloodStatus.BAHAYA, label: "Bahaya", icon: <WarningFilled /> },
  { status: FloodStatus.SIAGA, label: "Siaga", icon: <BellFilled /> },
  { status: FloodStatus.WASPADA, label: "Waspada", icon: <BellFilled /> },
  { status: FloodStatus.AMAN, label: "Normal", icon: <CheckCircleFilled /> },
  { status: FloodStatus.OFFLINE, label: "Offline", icon: <DisconnectOutlined /> },
];

interface IStatCardProps {
  def: ICardDef;
  count: number;
  active: boolean;
  onClick: (s: StatusFilter) => void;
}

const StatCard = memo(function StatCard({ def, count, active, onClick }: IStatCardProps) {
  const color = STATUS_META[def.status].color;
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={() => onClick(active ? "ALL" : def.status)}
      className={`flex w-full cursor-pointer items-center gap-3 rounded-lg border bg-white p-3 text-left shadow-sm ${
        active ? "border-blue-500 ring-1 ring-blue-500" : "border-slate-200"
      }`}
    >
      <span className="text-3xl" style={{ color }}>
        {def.icon}
      </span>
      <span>
        <span className="block text-xs font-semibold text-slate-700">{def.label}</span>
        <span className="block text-2xl font-bold leading-tight" style={{ color }}>
          {count}
        </span>
        <span className="block text-[10px] text-slate-400">unit</span>
      </span>
    </button>
  );
});

interface ISensorStatsProps {
  counts: Record<StatusFilter, number>;
  active: StatusFilter;
  onSelect: (s: StatusFilter) => void;
}

const SensorStats = ({ counts, active, onSelect }: ISensorStatsProps) => (
  <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
    {CARDS.map((c) => (
      <StatCard key={c.status} def={c} count={counts[c.status]} active={active === c.status} onClick={onSelect} />
    ))}
  </div>
);

export default SensorStats;
