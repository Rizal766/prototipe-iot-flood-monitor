const HEIGHTS = [5, 8, 11, 14];

const SignalBars = ({ level, network }: { level: number; network: string }) => (
  <span className="inline-flex items-end gap-2" title={`Sinyal ${level}/4`}>
    <span className="inline-flex items-end gap-0.5" aria-label={`Sinyal ${level} dari 4`}>
      {HEIGHTS.map((h, i) => (
        <span key={h} className="w-1 rounded-sm" style={{ height: h, background: i < level ? "#0f172a" : "#cbd5e1" }} />
      ))}
    </span>
    <span className="text-[11px] text-slate-500">{network}</span>
  </span>
);

export default SignalBars;
