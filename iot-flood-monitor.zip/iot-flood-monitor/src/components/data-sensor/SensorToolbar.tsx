import { Button, Input, Select, Switch } from "antd";
import { DownloadOutlined, ReloadOutlined, SearchOutlined } from "@ant-design/icons";
import type { StatusFilter } from "@/types/map";
import { STATUS_FILTERS } from "@/utils/status";

export const ALL = "ALL";

export interface ISensorFilters {
  search: string;
  status: StatusFilter;
  river: string;
  district: string;
  onlyIssues: boolean;
}

export const DEFAULT_FILTERS: ISensorFilters = {
  search: "",
  status: "ALL",
  river: ALL,
  district: ALL,
  onlyIssues: false,
};

interface ISensorToolbarProps {
  filters: ISensorFilters;
  rivers: string[];
  districts: string[];
  refreshing: boolean;
  onChange: (patch: Partial<ISensorFilters>) => void;
  onRefresh: () => void;
  onExport: () => void;
}

const SensorToolbar = ({ filters, rivers, districts, refreshing, onChange, onRefresh, onExport }: ISensorToolbarProps) => (
  <div className="flex flex-wrap items-center gap-2 rounded-lg border border-slate-200 bg-white p-2 shadow-sm">
    <Input
      allowClear
      className="min-w-[220px] flex-1 md:max-w-sm"
      prefix={<SearchOutlined />}
      placeholder="Cari ID sensor, nama lokasi atau sungai"
      value={filters.search}
      onChange={(e) => onChange({ search: e.target.value })}
    />
    <Select
      className="w-36"
      value={filters.status}
      onChange={(v: StatusFilter) => onChange({ status: v })}
      options={STATUS_FILTERS.map((f) => ({ value: f.key, label: f.key === "ALL" ? "Semua status" : f.label }))}
    />
    <Select
      className="w-44"
      value={filters.river}
      onChange={(v) => onChange({ river: v })}
      options={[{ value: ALL, label: "Semua sungai" }, ...rivers.map((r) => ({ value: r, label: r }))]}
    />
    <Select
      className="w-44"
      value={filters.district}
      onChange={(v) => onChange({ district: v })}
      options={[{ value: ALL, label: "Semua kecamatan" }, ...districts.map((d) => ({ value: d, label: d }))]}
    />
    <label className="flex items-center gap-1.5 text-xs text-slate-600">
      <Switch size="small" checked={filters.onlyIssues} onChange={(v) => onChange({ onlyIssues: v })} />
      Hanya bermasalah
    </label>
    <Button aria-label="Muat ulang" icon={<ReloadOutlined spin={refreshing} />} onClick={onRefresh} />
    <Button type="primary" icon={<DownloadOutlined />} className="md:ml-auto" onClick={onExport}>
      Ekspor CSV
    </Button>
  </div>
);

export default SensorToolbar;
