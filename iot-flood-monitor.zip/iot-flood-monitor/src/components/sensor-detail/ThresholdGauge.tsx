import { FloodStatus } from "@/types/sensor";
import { STATUS_META } from "@/utils/status";
import type { IThresholds } from "@/utils/thresholds";

interface IThresholdGaugeProps {
  thresholds: IThresholds;
  level: number;
}

// Batang ambang batas dengan penanda posisi tinggi air saat ini
const ThresholdGauge = ({ thresholds: t, level }: IThresholdGaugeProps) => {
  const max = Math.max(t.bahaya * 1.25, level * 1.05, 1);
  const pct = (v: number) => Math.min(100, Math.max(0, (v / max) * 100));
  const segments = [
    { status: FloodStatus.AMAN, from: 0, to: t.waspada, label: `Normal <${t.waspada}` },
    { status: FloodStatus.WASPADA, from: t.waspada, to: t.siaga, label: `Waspada ${t.waspada}-${t.siaga - 1}` },
    { status: FloodStatus.SIAGA, from: t.siaga, to: t.bahaya, label: `Siaga ${t.siaga}-${t.bahaya - 1}` },
    { status: FloodStatus.BAHAYA, from: t.bahaya, to: max, label: `Bahaya ≥${t.bahaya}` },
  ];

  return (
    <div className="px-1 pt-2">
      <div className="relative h-3">
        <div className="flex h-full overflow-hidden rounded-full">
          {segments.map((s) => (
            <div key={s.status} style={{ width: `${pct(s.to) - pct(s.from)}%`, background: STATUS_META[s.status].color }} />
          ))}
        </div>
        <span
          className="absolute -top-1.5 h-6 w-1 -translate-x-1/2 rounded bg-slate-900 ring-2 ring-white"
          style={{ left: `${pct(level)}%` }}
          title={`Tinggi air saat ini: ${level} cm`}
        />
      </div>
      <div className="mt-2 flex text-[10px]">
        {segments.map((s) => (
          <div key={s.status} className="overflow-visible whitespace-nowrap text-center" style={{ width: `${pct(s.to) - pct(s.from)}%` }}>
            <span className="font-semibold" style={{ color: STATUS_META[s.status].color }}>
              {s.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ThresholdGauge;
