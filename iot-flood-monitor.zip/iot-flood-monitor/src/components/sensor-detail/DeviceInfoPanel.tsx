import { Link } from "react-router-dom";
import Panel from "@/components/dashboard/Panel";
import SignalBars from "@/components/data-sensor/SignalBars";
import { DeviceConnection, type IDevice } from "@/types/device";
import { FloodStatus, type ISensor } from "@/types/sensor";
import { formatDate } from "@/utils/time";

const levelColor = (pct: number): string => (pct < 20 ? "#ef4444" : pct < 50 ? "#f59e0b" : "#22c55e");

const Meter = ({ label, value, suffix }: { label: string; value: number; suffix?: string }) => (
  <div>
    <div className="flex items-center justify-between text-xs">
      <span className="text-slate-500">{label}</span>
      <span className="font-semibold">
        {value}
        {suffix ?? "%"}
      </span>
    </div>
    <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-slate-200">
      <div className="h-full rounded-full" style={{ width: `${Math.min(100, Math.max(0, value))}%`, background: levelColor(value) }} />
    </div>
  </div>
);

interface IDeviceInfoPanelProps {
  sensor: ISensor;
  device: IDevice | undefined;
}

const DeviceInfoPanel = ({ sensor, device }: IDeviceInfoPanelProps) => {
  const offline = sensor.status === FloodStatus.OFFLINE;
  const health = device?.connection === DeviceConnection.MAINTENANCE
    ? { text: "Maintenance", cls: "bg-amber-100 text-amber-700" }
    : offline
      ? { text: "Offline", cls: "bg-slate-200 text-slate-600" }
      : sensor.battery < 20
        ? { text: "Baterai rendah", cls: "bg-amber-100 text-amber-700" }
        : { text: "Baik", cls: "bg-green-100 text-green-700" };

  const rows: [string, string][] = [
    ["Versi Firmware", device?.firmware ?? "-"],
    ["Tanggal Pasang", device ? formatDate(device.registeredAt) : "-"],
    ["Penanggung Jawab", device?.officer ?? "-"],
    ["Koordinat", `${sensor.lat.toFixed(4)}, ${sensor.lng.toFixed(4)}`],
  ];

  return (
    <Panel title="Informasi Perangkat" actions={<span className={`rounded px-2 py-0.5 text-[11px] font-semibold ${health.cls}`}>{health.text}</span>}>
      <div className="flex flex-col gap-3">
        <Meter label="Baterai" value={sensor.battery} />
        <Meter label="Pengisian Panel Surya" value={sensor.solar} />
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-500">Sinyal</span>
          <span className="flex items-center gap-2 font-semibold">
            <SignalBars level={sensor.signal} network={sensor.network} />
            {sensor.rssi !== null && <span className="text-[11px] font-normal text-slate-500">{sensor.rssi} dBm</span>}
          </span>
        </div>
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-500">Suhu Perangkat</span>
          <span className="font-semibold">{offline ? "-" : `${sensor.temperature}°C`}</span>
        </div>
      </div>

      <dl className="m-0 mt-3 grid grid-cols-[110px_minmax(0,1fr)] gap-x-2 gap-y-1.5 border-t border-slate-100 pt-3 text-xs">
        {rows.map(([k, v]) => (
          <div key={k} className="contents">
            <dt className="text-slate-500">{k}</dt>
            <dd className="m-0 break-words font-medium">{v}</dd>
          </div>
        ))}
      </dl>

      <p className="m-0 mb-1 mt-3 text-xs font-semibold">Foto Lokasi</p>
      {device?.photo ? (
        <img src={device.photo} alt={`Foto lokasi ${sensor.location}`} className="h-28 w-full rounded-md object-cover" />
      ) : (
        <div className="flex h-20 items-center justify-center rounded-md border border-dashed border-slate-300 text-[11px] text-slate-400">
          Belum ada foto lokasi
        </div>
      )}
      {!device && (
        <p className="m-0 mt-2 text-[11px] text-slate-500">
          Perangkat belum terdaftar untuk sensor ini. <Link to="/pengaturan/perangkat">Kelola Perangkat</Link>
        </p>
      )}
    </Panel>
  );
};

export default DeviceInfoPanel;
