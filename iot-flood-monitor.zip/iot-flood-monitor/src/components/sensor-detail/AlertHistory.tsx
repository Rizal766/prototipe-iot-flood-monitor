import { useNavigate } from "react-router-dom";
import { Button } from "antd";
import Panel from "@/components/dashboard/Panel";
import { LEVEL_META } from "@/components/notifikasi/meta";
import type { INotification } from "@/types/notification";
import { formatDateTime } from "@/utils/time";

interface IAlertHistoryProps {
  code: string;
  alerts: INotification[]; // sudah difilter untuk sensor ini
  loading: boolean;
}

const AlertHistory = ({ code, alerts, loading }: IAlertHistoryProps) => {
  const navigate = useNavigate();
  const latest = [...alerts].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5);

  return (
    <Panel
      title="Riwayat Alert (5 Terakhir)"
      actions={
        <Button size="small" type="link" onClick={() => navigate(`/notifikasi?sensor=${encodeURIComponent(code)}`)}>
          Lihat Semua →
        </Button>
      }
    >
      <div className="overflow-x-auto">
        <table className="w-full min-w-[480px] border-collapse text-xs">
          <thead>
            <tr className="border-b border-slate-200 text-left text-slate-500">
              <th className="px-2 py-2 font-medium">Waktu</th>
              <th className="px-2 py-2 font-medium">Level</th>
              <th className="px-2 py-2 font-medium">Nilai</th>
              <th className="px-2 py-2 font-medium">Keterangan</th>
            </tr>
          </thead>
          <tbody>
            {latest.map((a) => {
              const meta = LEVEL_META[a.level];
              return (
                <tr key={a.id} className="border-b border-slate-100">
                  <td className="px-2 py-2.5 whitespace-nowrap">{formatDateTime(a.createdAt)}</td>
                  <td className="px-2 py-2.5">
                    <span className="flex items-center gap-1.5 font-medium" style={{ color: meta.color }}>
                      <span className="h-2.5 w-2.5 rounded-full" style={{ background: meta.color }} />
                      {meta.label}
                    </span>
                  </td>
                  <td className="px-2 py-2.5">{a.value === null ? "-" : `${a.value} ${a.unit}`}</td>
                  <td className="px-2 py-2.5">{a.title}</td>
                </tr>
              );
            })}
            {latest.length === 0 && (
              <tr>
                <td colSpan={4} className="py-5 text-center text-slate-400">
                  {loading ? "Memuat riwayat alert…" : "Belum ada alert untuk sensor ini"}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </Panel>
  );
};

export default AlertHistory;
