import { FloodStatus } from "@/types/sensor";
import { STATUS_META } from "@/utils/status";

const StatusBadge = ({ status }: { status: FloodStatus }) => {
  const { color, label } = STATUS_META[status];
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-md border px-2 py-0.5 text-[11px] font-semibold"
      style={{ color, borderColor: color, background: `${color}14` }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
      {status === FloodStatus.AMAN ? "Normal" : label}
    </span>
  );
};

export default StatusBadge;
