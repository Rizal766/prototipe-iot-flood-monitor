import { useState } from "react";
import { Button, Descriptions, Modal, Select } from "antd";
import { AlertStatus, type INotification } from "@/types/notification";
import { OFFICERS } from "@/utils/officers";
import { formatAgoShort, formatDateTime } from "@/utils/time";
import { ALERT_STATUS_META, LEVEL_META, TYPE_LABEL } from "./meta";

interface IDetailModalProps {
  alert: INotification | null;
  onClose: () => void;
  onSetStatus: (ids: number[], status: AlertStatus) => void;
}

export const AlertDetailModal = ({ alert, onClose, onSetStatus }: IDetailModalProps) => (
  <Modal
    open={alert !== null}
    title="Detail Alert"
    onCancel={onClose}
    footer={
      alert && (
        <div className="flex justify-end gap-2">
          {alert.status === AlertStatus.BELUM && (
            <Button type="primary" onClick={() => { onSetStatus([alert.id], AlertStatus.DIPROSES); onClose(); }}>
              Tandai Diproses
            </Button>
          )}
          {alert.status === AlertStatus.DIPROSES && (
            <Button type="primary" onClick={() => { onSetStatus([alert.id], AlertStatus.SELESAI); onClose(); }}>
              Tandai Selesai
            </Button>
          )}
          <Button onClick={onClose}>Tutup</Button>
        </div>
      )
    }
  >
    {alert && (
      <Descriptions column={1} size="small" bordered>
        <Descriptions.Item label="Judul">{alert.title}</Descriptions.Item>
        <Descriptions.Item label="Level">
          <span style={{ color: LEVEL_META[alert.level].color }}>{LEVEL_META[alert.level].label}</span>
        </Descriptions.Item>
        <Descriptions.Item label="Jenis">{TYPE_LABEL[alert.type]}</Descriptions.Item>
        <Descriptions.Item label="Sensor">{alert.sensorCode}</Descriptions.Item>
        <Descriptions.Item label="Lokasi">{alert.location}</Descriptions.Item>
        <Descriptions.Item label="Nilai / Ambang">
          {alert.value === null || alert.threshold === null
            ? "- / -"
            : `${alert.value} ${alert.unit} / ${alert.threshold} ${alert.unit}`}
        </Descriptions.Item>
        <Descriptions.Item label="Waktu">
          {formatDateTime(alert.createdAt)} ({formatAgoShort(alert.createdAt)})
        </Descriptions.Item>
        <Descriptions.Item label="Direspons">
          {alert.respondedAt
            ? `${formatDateTime(alert.respondedAt)} (${Math.max(0, Math.round((new Date(alert.respondedAt).getTime() - new Date(alert.createdAt).getTime()) / 60000))} menit)`
            : "Belum"}
        </Descriptions.Item>
        <Descriptions.Item label="Status">
          <span style={{ color: ALERT_STATUS_META[alert.status].color }}>{ALERT_STATUS_META[alert.status].label}</span>
        </Descriptions.Item>
        <Descriptions.Item label="Petugas">{alert.officer ?? "-"}</Descriptions.Item>
      </Descriptions>
    )}
  </Modal>
);

interface IAssignModalProps {
  ids: number[] | null;
  onClose: () => void;
  onAssign: (ids: number[], officer: string) => void;
}

export const AssignModal = ({ ids, onClose, onAssign }: IAssignModalProps) => {
  const [officer, setOfficer] = useState<string | null>(null);
  const close = () => {
    setOfficer(null);
    onClose();
  };
  return (
    <Modal
      open={ids !== null}
      title={ids && ids.length > 1 ? `Tugaskan petugas (${ids.length} alert)` : "Tugaskan petugas"}
      okText="Tugaskan"
      okButtonProps={{ disabled: !officer }}
      onCancel={close}
      onOk={() => {
        if (ids && officer) onAssign(ids, officer);
        close();
      }}
    >
      <p className="m-0 mb-2 text-xs text-slate-500">
        Alert berstatus "Belum ditangani" otomatis menjadi "Diproses" setelah petugas ditugaskan.
      </p>
      <Select
        className="w-full"
        placeholder="Pilih petugas"
        value={officer}
        onChange={setOfficer}
        options={OFFICERS.map((o) => ({ value: o, label: o }))}
      />
    </Modal>
  );
};
