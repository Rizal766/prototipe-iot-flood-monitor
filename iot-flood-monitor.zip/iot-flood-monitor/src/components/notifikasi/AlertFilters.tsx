import { Button, DatePicker, Select } from "antd";
import type { Dayjs } from "dayjs";
import { AlertLevel, AlertType } from "@/types/notification";
import { LEVEL_META, TYPE_LABEL } from "./meta";

export interface IAlertFilters {
  level: AlertLevel | "ALL";
  sensor: string; // kode sensor atau "ALL"
  type: AlertType | "ALL";
  range: [Dayjs, Dayjs] | null;
}

export const DEFAULT_ALERT_FILTERS: IAlertFilters = { level: "ALL", sensor: "ALL", type: "ALL", range: null };

interface IAlertFiltersProps {
  draft: IAlertFilters;
  sensorCodes: string[];
  onChange: (f: IAlertFilters) => void;
  onApply: () => void;
  onReset: () => void;
}

const AlertFilters = ({ draft, sensorCodes, onChange, onApply, onReset }: IAlertFiltersProps) => (
  <div className="flex flex-wrap items-end gap-3 rounded-lg border border-slate-200 bg-white p-3 shadow-sm">
    <label className="flex flex-col gap-1 text-[11px] text-slate-500">
      Level
      <Select
        className="w-36"
        value={draft.level}
        onChange={(v: AlertLevel | "ALL") => onChange({ ...draft, level: v })}
        options={[
          { value: "ALL", label: "Semua" },
          ...Object.values(AlertLevel).map((l) => ({ value: l, label: LEVEL_META[l].label })),
        ]}
      />
    </label>
    <label className="flex flex-col gap-1 text-[11px] text-slate-500">
      Sensor
      <Select
        className="w-40"
        value={draft.sensor}
        onChange={(v: string) => onChange({ ...draft, sensor: v })}
        options={[{ value: "ALL", label: "Semua Sensor" }, ...sensorCodes.map((c) => ({ value: c, label: c }))]}
      />
    </label>
    <label className="flex flex-col gap-1 text-[11px] text-slate-500">
      Jenis
      <Select
        className="w-44"
        value={draft.type}
        onChange={(v: AlertType | "ALL") => onChange({ ...draft, type: v })}
        options={[
          { value: "ALL", label: "Semua Jenis" },
          ...Object.values(AlertType).map((t) => ({ value: t, label: TYPE_LABEL[t] })),
        ]}
      />
    </label>
    <label className="flex flex-col gap-1 text-[11px] text-slate-500">
      Tanggal
      <DatePicker.RangePicker
        value={draft.range}
        placeholder={["Semua tanggal", "Semua tanggal"]}
        onChange={(v) => onChange({ ...draft, range: v && v[0] && v[1] ? [v[0], v[1]] : null })}
      />
    </label>
    <div className="ml-auto flex gap-2">
      <Button onClick={onReset}>Reset Filter</Button>
      <Button type="primary" onClick={onApply}>
        Terapkan
      </Button>
    </div>
  </div>
);

export default AlertFilters;
