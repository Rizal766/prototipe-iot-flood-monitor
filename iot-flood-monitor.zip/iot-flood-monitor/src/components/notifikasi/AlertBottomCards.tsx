import { Button } from "antd";
import { BellOutlined } from "@ant-design/icons";
import { useNavigate } from "react-router-dom";
import Panel from "@/components/dashboard/Panel";
import { AlertLevel, type INotification } from "@/types/notification";
import { formatAgoShort, formatClock } from "@/utils/time";
import { LEVEL_META } from "./meta";

interface IAlertBottomCardsProps {
  all: INotification[];
  unhandled: INotification[];
  onShowUnhandled: () => void;
  onDetail: (n: INotification) => void;
}

const AlertBottomCards = ({ all, unhandled, onShowUnhandled, onDetail }: IAlertBottomCardsProps) => {
  const navigate = useNavigate();
  const latest = [...unhandled].sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];

  return (
    <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
      <Panel title="Status penanganan">
        <div className="flex items-center gap-3">
          <BellOutlined className="text-4xl text-slate-600" />
          {unhandled.length === 0 ? (
            <div className="text-xs">
              <p className="m-0 font-semibold">Tidak ada alert yang perlu ditangani</p>
              <p className="m-0 mb-2 text-slate-500">Semua notifikasi telah ditangani dengan baik.</p>
              <Button size="small" type="primary" onClick={() => navigate("/")}>
                Kembali ke Dashboard
              </Button>
            </div>
          ) : (
            <div className="text-xs">
              <p className="m-0 font-semibold">{unhandled.length} alert belum ditangani</p>
              <p className="m-0 mb-2 text-slate-500">Segera tindak lanjuti alert prioritas tinggi.</p>
              <Button size="small" type="primary" onClick={onShowUnhandled}>
                Tampilkan yang belum ditangani
              </Button>
            </div>
          )}
        </div>
      </Panel>

      <Panel title="Alert Baru Masuk">
        {latest ? (
          <div className="text-xs">
            <p className="m-0 font-medium">
              {latest.title} di {latest.location}
            </p>
            <p className="m-0 mb-2 text-slate-500">
              {formatClock(latest.createdAt)} ({formatAgoShort(latest.createdAt)})
            </p>
            <Button size="small" type="primary" onClick={() => onDetail(latest)}>
              Lihat Detail
            </Button>
          </div>
        ) : (
          <p className="m-0 text-xs text-slate-400">Belum ada alert baru.</p>
        )}
      </Panel>

      <Panel title="Ringkasan level">
        <ul className="m-0 grid list-none grid-cols-2 gap-2 p-0 text-xs">
          {Object.values(AlertLevel).map((l) => (
            <li key={l} className="flex items-center justify-between rounded border border-slate-100 px-2 py-1">
              <span style={{ color: LEVEL_META[l].color }}>{LEVEL_META[l].label}</span>
              <b>{all.filter((n) => n.level === l).length}</b>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
};

export default AlertBottomCards;
