import type { ReactNode } from "react";
import {
  BellOutlined,
  ExclamationCircleOutlined,
  InfoCircleOutlined,
  WarningOutlined,
} from "@ant-design/icons";
import { AlertLevel, AlertStatus, AlertType } from "@/types/notification";

export const LEVEL_META: Record<AlertLevel, { label: string; color: string; icon: ReactNode }> = {
  [AlertLevel.TINGGI]: { label: "Tinggi", color: "#ef4444", icon: <WarningOutlined /> },
  [AlertLevel.SEDANG]: { label: "Sedang", color: "#f59e0b", icon: <BellOutlined /> },
  [AlertLevel.RENDAH]: { label: "Rendah", color: "#0ea5e9", icon: <InfoCircleOutlined /> },
  [AlertLevel.OFFLINE]: { label: "Offline", color: "#64748b", icon: <ExclamationCircleOutlined /> },
};

export const ALERT_STATUS_META: Record<AlertStatus, { label: string; color: string }> = {
  [AlertStatus.BELUM]: { label: "Belum ditangani", color: "#ef4444" },
  [AlertStatus.DIPROSES]: { label: "Diproses", color: "#f97316" },
  [AlertStatus.SELESAI]: { label: "Selesai", color: "#16a34a" },
};

export const TYPE_LABEL: Record<AlertType, string> = {
  [AlertType.TINGGI_AIR]: "Tinggi Air",
  [AlertType.CURAH_HUJAN]: "Curah Hujan",
  [AlertType.OFFLINE]: "Sensor Offline",
  [AlertType.BATERAI]: "Baterai Lemah",
};
