import { useMemo } from "react";
import { DataGrid, type GridColDef, type GridPaginationModel, type GridRowSelectionModel } from "@mui/x-data-grid";
import { Button, Dropdown, Pagination, Select } from "antd";
import { MoreOutlined, UserAddOutlined } from "@ant-design/icons";
import { AlertStatus, type INotification } from "@/types/notification";
import { formatAgoShort, formatClock } from "@/utils/time";
import { ALERT_STATUS_META, LEVEL_META } from "./meta";

const PAGE_SIZES = [10, 25, 50];

const NoRows = () => (
  <div className="flex h-full items-center justify-center text-sm text-slate-400">Tidak ada alert yang cocok</div>
);

interface IAlertTableProps {
  rows: INotification[];
  loading: boolean;
  isAdmin: boolean;
  selection: GridRowSelectionModel;
  paging: GridPaginationModel;
  onSelectionChange: (m: GridRowSelectionModel) => void;
  onPagingChange: (m: GridPaginationModel) => void;
  onSetStatus: (ids: number[], status: AlertStatus) => void;
  onAssign: (ids: number[]) => void;
  onDetail: (n: INotification) => void;
  onDelete: (n: INotification) => void;
}

const AlertTable = ({
  rows,
  loading,
  isAdmin,
  selection,
  paging,
  onSelectionChange,
  onPagingChange,
  onSetStatus,
  onAssign,
  onDetail,
  onDelete,
}: IAlertTableProps) => {
  const columns = useMemo<GridColDef<INotification>[]>(
    () => [
      {
        field: "level",
        headerName: "Level",
        width: 100,
        renderCell: (p) => {
          const m = LEVEL_META[p.row.level];
          return (
            <span className="flex items-center gap-1.5 font-medium" style={{ color: m.color }}>
              <span className="text-base">{m.icon}</span>
              {m.label}
            </span>
          );
        },
      },
      { field: "title", headerName: "Judul Alert", flex: 1, minWidth: 190 },
      {
        field: "sensorCode",
        headerName: "Sensor & Lokasi",
        width: 190,
        renderCell: (p) => (
          <div className="leading-tight">
            <div className="font-semibold">{p.row.sensorCode}</div>
            <div className="text-[11px] text-slate-500">{p.row.location}</div>
          </div>
        ),
      },
      {
        field: "value",
        headerName: "Nilai Pemicu/Ambang",
        width: 160,
        sortable: false,
        renderCell: (p) =>
          p.row.value === null || p.row.threshold === null ? (
            <span className="text-slate-400">- / -</span>
          ) : (
            <span>
              {p.row.value} {p.row.unit} / {p.row.threshold} {p.row.unit}
            </span>
          ),
      },
      {
        field: "createdAt",
        headerName: "Waktu",
        width: 130,
        renderCell: (p) => (
          <div className="leading-tight">
            <div>{formatClock(p.row.createdAt)}</div>
            <div className="text-[11px] text-slate-500">({formatAgoShort(p.row.createdAt)})</div>
          </div>
        ),
      },
      {
        field: "status",
        headerName: "Status Tindak Lanjut",
        width: 160,
        renderCell: (p) => {
          const m = ALERT_STATUS_META[p.row.status];
          return (
            <span className="font-medium" style={{ color: m.color }}>
              {m.label}
            </span>
          );
        },
      },
      {
        field: "officer",
        headerName: "Petugas",
        width: 130,
        valueGetter: (v: string | null) => v ?? "-",
      },
      {
        field: "actions",
        headerName: "Aksi",
        width: 250,
        sortable: false,
        disableColumnMenu: true,
        renderCell: (p) => {
          const n = p.row;
          const menu = [
            { key: "detail", label: "Lihat Detail", onClick: () => onDetail(n) },
            ...(isAdmin ? [{ key: "delete", label: "Hapus Alert", danger: true, onClick: () => onDelete(n) }] : []),
          ];
          return (
            <span className="flex items-center gap-1">
              {n.status === AlertStatus.BELUM && (
                <Button size="small" type="primary" onClick={() => onSetStatus([n.id], AlertStatus.DIPROSES)}>
                  Tandai Diproses
                </Button>
              )}
              {n.status === AlertStatus.DIPROSES && (
                <Button size="small" type="primary" onClick={() => onSetStatus([n.id], AlertStatus.SELESAI)}>
                  Tandai Selesai
                </Button>
              )}
              {n.status === AlertStatus.SELESAI && (
                <Button size="small" onClick={() => onDetail(n)}>
                  Lihat Detail
                </Button>
              )}
              <Button
                size="small"
                type="text"
                aria-label="Tugaskan petugas"
                title="Tugaskan petugas"
                icon={<UserAddOutlined />}
                disabled={n.status === AlertStatus.SELESAI}
                onClick={() => onAssign([n.id])}
              />
              <Dropdown trigger={["click"]} menu={{ items: menu }}>
                <Button size="small" type="text" aria-label="Menu lainnya" icon={<MoreOutlined />} />
              </Dropdown>
            </span>
          );
        },
      },
    ],
    [isAdmin, onSetStatus, onAssign, onDetail, onDelete],
  );

  const start = rows.length === 0 ? 0 : paging.page * paging.pageSize + 1;
  const end = Math.min((paging.page + 1) * paging.pageSize, rows.length);

  return (
    <>
      <DataGrid
        rows={rows}
        columns={columns}
        loading={loading}
        autoHeight
        rowHeight={58}
        columnHeaderHeight={44}
        hideFooter
        checkboxSelection
        disableRowSelectionOnClick
        disableColumnMenu
        rowSelectionModel={selection}
        onRowSelectionModelChange={onSelectionChange}
        paginationModel={paging}
        onPaginationModelChange={onPagingChange}
        pageSizeOptions={PAGE_SIZES}
        slots={{ noRowsOverlay: NoRows }}
        sx={{
          border: 0,
          fontSize: 12,
          "& .MuiDataGrid-columnHeaders": { backgroundColor: "#f8fafc" },
          "& .MuiDataGrid-overlayWrapper": { minHeight: 120 },
        }}
      />
      <div className="mt-2 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-2 text-xs text-slate-600">
        <span>
          Menampilkan {start} - {end} dari {rows.length} Alert
        </span>
        <span className="flex items-center gap-2">
          Tampilkan
          <Select
            size="small"
            value={paging.pageSize}
            onChange={(v) => onPagingChange({ page: 0, pageSize: v })}
            options={PAGE_SIZES.map((n) => ({ value: n, label: n }))}
          />
        </span>
        <Pagination
          size="small"
          current={paging.page + 1}
          pageSize={paging.pageSize}
          total={rows.length}
          showSizeChanger={false}
          onChange={(p) => onPagingChange({ ...paging, page: p - 1 })}
        />
      </div>
    </>
  );
};

export default AlertTable;
