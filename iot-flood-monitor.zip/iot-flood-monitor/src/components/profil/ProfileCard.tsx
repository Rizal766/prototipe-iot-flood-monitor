import { useRef, useState } from "react";
import { Avatar, Button, Input, message } from "antd";
import { UserOutlined } from "@ant-design/icons";
import { Controller, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import Panel from "@/components/dashboard/Panel";
import { useProfileMutations } from "@/hooks/useProfile";
import { profileSchema, type ProfileFormValues } from "@/schemas/profileSchema";
import { ROLE_LABEL } from "@/types/auth";
import type { IProfile } from "@/types/profile";
import { resizeImageToDataUrl } from "@/utils/image";
import { formatDateTime } from "@/utils/time";
import Notice from "./Notice";

const MAX_PHOTO = 2 * 1024 * 1024;

const ProfileCard = ({ profile }: { profile: IProfile }) => {
  const { save, avatar } = useProfileMutations();
  const fileRef = useRef<HTMLInputElement>(null);
  const [notice, setNotice] = useState<{ ok: boolean; title: string; text?: string } | null>(null);

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors, isDirty },
  } = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: { name: profile.name, phone: profile.phone },
  });

  const onSubmit = async (v: ProfileFormValues) => {
    const res = await save.mutateAsync({ name: v.name.trim(), phone: v.phone.trim() });
    if (res.status && res.data) {
      reset({ name: res.data.name, phone: res.data.phone });
      setNotice({ ok: true, title: "Profile berhasil disimpan" });
    } else {
      setNotice({ ok: false, title: "Profile gagal disimpan", text: res.message });
    }
  };

  const pickPhoto = async (file: File | undefined) => {
    if (fileRef.current) fileRef.current.value = ""; // agar file yang sama bisa dipilih lagi
    if (!file) return;
    if (!["image/jpeg", "image/png"].includes(file.type)) {
      message.error("Format foto harus JPG atau PNG");
      return;
    }
    if (file.size > MAX_PHOTO) {
      message.error("Ukuran foto maksimal 2 MB");
      return;
    }
    try {
      const dataUrl = await resizeImageToDataUrl(file, 256);
      const res = await avatar.mutateAsync(dataUrl);
      if (res.status) message.success("Foto profil diperbarui");
      else message.error(res.message || "Gagal menyimpan foto");
    } catch (e) {
      message.error(e instanceof Error ? e.message : "Gagal memproses foto");
    }
  };

  const removePhoto = async () => {
    const res = await avatar.mutateAsync(null);
    if (res.status) message.success("Foto profil dihapus");
    else message.error(res.message || "Gagal menghapus foto");
  };

  const err = (m?: string) => (m ? <p className="m-0 mt-0.5 text-xs text-red-500">{m}</p> : null);
  const label = "mb-1 block text-xs font-medium text-slate-600";

  return (
    <Panel title="Informasi Profile" className="h-full">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-[160px_minmax(0,1fr)]">
        <div className="flex flex-col items-center gap-2">
          <Avatar size={120} src={profile.avatar ?? undefined} icon={<UserOutlined />} />
          <input ref={fileRef} type="file" accept="image/jpeg,image/png" className="hidden" onChange={(e) => void pickPhoto(e.target.files?.[0])} />
          <Button type="primary" size="small" loading={avatar.isPending} onClick={() => fileRef.current?.click()}>
            Ubah Foto
          </Button>
          {profile.avatar && (
            <Button size="small" type="link" danger disabled={avatar.isPending} onClick={() => void removePhoto()}>
              Hapus foto
            </Button>
          )}
          <p className="m-0 text-center text-[10px] text-slate-400">JPG atau PNG, maks. 2 MB</p>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} noValidate className="flex flex-col gap-3 text-xs">
          <div>
            <label htmlFor="pf-name" className={label}>Nama Lengkap</label>
            <Controller name="name" control={control} render={({ field }) => <Input {...field} id="pf-name" status={errors.name ? "error" : undefined} />} />
            {err(errors.name?.message)}
          </div>
          <div>
            <label htmlFor="pf-email" className={label}>Email</label>
            <Input id="pf-email" value={profile.email} disabled />
            <p className="m-0 mt-0.5 text-[11px] text-slate-400">Email dipakai untuk login; perubahan email dilakukan oleh Admin di menu Pengguna & Role.</p>
          </div>
          <div>
            <label htmlFor="pf-phone" className={label}>No HP</label>
            <Controller name="phone" control={control} render={({ field }) => <Input {...field} id="pf-phone" placeholder="081234567890" status={errors.phone ? "error" : undefined} />} />
            {err(errors.phone?.message)}
          </div>
          <p className="m-0 text-[11px] text-slate-500">
            Role: <b>{ROLE_LABEL[profile.role]}</b>
            {profile.lastLogin && <> · Login terakhir {formatDateTime(profile.lastLogin)}</>}
          </p>
          {notice && <Notice {...notice} onClose={() => setNotice(null)} />}
          <div className="flex justify-end">
            <Button type="primary" htmlType="submit" loading={save.isPending} disabled={!isDirty}>
              Simpan Profile
            </Button>
          </div>
        </form>
      </div>
    </Panel>
  );
};

export default ProfileCard;
