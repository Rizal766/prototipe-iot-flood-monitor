import Panel from "@/components/dashboard/Panel";
import { useThemeStore, type Theme } from "@/stores/useThemeStore";

const OPTIONS: { key: Theme; icon: string; title: string; desc: string }[] = [
  { key: "light", icon: "☀️", title: "Terang", desc: "Tampilan lebih cerah dan nyaman di siang hari" },
  { key: "dark", icon: "🌙", title: "Gelap", desc: "Lebih nyaman di malam hari dan mengurangi cahaya layar" },
];

const ThemeCard = () => {
  const theme = useThemeStore((s) => s.theme);
  const setTheme = useThemeStore((s) => s.setTheme);

  return (
    <Panel title="Tampilan Tema" className="h-full">
      <p className="m-0 mb-2 text-xs text-slate-500">Pilih tema sesuai preferensi Anda.</p>
      <div className="flex flex-col gap-2" role="radiogroup" aria-label="Tema tampilan">
        {OPTIONS.map((o) => {
          const active = theme === o.key;
          return (
            <button
              key={o.key}
              type="button"
              role="radio"
              aria-checked={active}
              onClick={() => setTheme(o.key)}
              className={`flex w-full cursor-pointer items-center gap-3 rounded-md border bg-white p-3 text-left ${
                active ? "border-blue-500 ring-1 ring-blue-500" : "border-slate-200"
              }`}
            >
              <span className="text-2xl" aria-hidden="true">{o.icon}</span>
              <span className="min-w-0 flex-1 leading-tight">
                <span className="block text-xs font-semibold">{o.title}</span>
                <span className="block text-[11px] text-slate-500">{o.desc}</span>
              </span>
              <span className={`flex h-4 w-4 items-center justify-center rounded-full border-2 ${active ? "border-blue-600" : "border-slate-300"}`}>
                {active && <span className="h-2 w-2 rounded-full bg-blue-600" />}
              </span>
            </button>
          );
        })}
      </div>
      <p className="m-0 mt-2 text-[11px] text-slate-400">Tema disimpan di perangkat ini dan tidak memengaruhi perangkat lain.</p>
    </Panel>
  );
};

export default ThemeCard;
