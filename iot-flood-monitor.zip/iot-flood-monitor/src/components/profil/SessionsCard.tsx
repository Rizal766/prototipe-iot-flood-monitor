import { Button, Modal, Spin, message } from "antd";
import { DesktopOutlined, MobileOutlined } from "@ant-design/icons";
import Panel from "@/components/dashboard/Panel";
import { useProfileMutations, useSessions } from "@/hooks/useProfile";
import { useAuthStore } from "@/stores/useAuthStore";
import { formatDateTime } from "@/utils/time";
import { isMobileDevice } from "@/utils/device";

const SessionsCard = () => {
  const { data, isLoading } = useSessions();
  const sessions = data?.data ?? [];
  const { revoke, revokeAll } = useProfileMutations();
  const logout = useAuthStore((s) => s.logout);

  const confirmAll = () =>
    Modal.confirm({
      title: "Keluarkan semua sesi?",
      content: "Anda akan keluar dari semua perangkat, termasuk perangkat ini, dan perlu login ulang.",
      okText: "Keluarkan semua",
      okButtonProps: { danger: true },
      cancelText: "Batal",
      onOk: async () => {
        const res = await revokeAll.mutateAsync();
        if (res.status) logout();
        else message.error(res.message || "Gagal mengeluarkan sesi");
      },
    });

  return (
    <Panel title="Sesi Login Aktif" className="h-full">
      <p className="m-0 mb-2 text-xs text-slate-500">Daftar perangkat yang login ke akun Anda.</p>
      {isLoading ? (
        <Spin className="block py-6" />
      ) : sessions.length === 0 ? (
        <p className="m-0 py-6 text-center text-xs text-slate-400">Tidak ada sesi aktif.</p>
      ) : (
        <ul className="m-0 flex list-none flex-col gap-2 p-0">
          {sessions.map((s) => (
            <li key={s.id} className="flex items-center gap-3 rounded-md border border-slate-200 p-2.5 text-xs">
              <span className="text-2xl text-slate-600">{isMobileDevice(s.device) ? <MobileOutlined /> : <DesktopOutlined />}</span>
              <div className="min-w-0 flex-1 leading-tight">
                <p className="m-0 font-semibold">{s.device}</p>
                <p className="m-0 truncate text-slate-500">
                  IP {s.ip} · {s.location}
                </p>
              </div>
              <div className="shrink-0 text-right leading-tight">
                <p className={`m-0 font-semibold ${s.current ? "text-green-600" : "text-slate-500"}`}>{s.current ? "Aktif Sekarang" : "Aktif"}</p>
                <p className="m-0 text-[11px] text-slate-500">{formatDateTime(s.lastActive)}</p>
                {!s.current && (
                  <Button
                    size="small"
                    type="link"
                    danger
                    className="!h-auto !p-0 !text-[11px]"
                    loading={revoke.isPending && revoke.variables === s.id}
                    onClick={async () => {
                      const res = await revoke.mutateAsync(s.id);
                      if (res.status) message.success(`${s.device} dikeluarkan`);
                      else message.error(res.message || "Gagal mengeluarkan sesi");
                    }}
                  >
                    Keluarkan
                  </Button>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
      <div className="mt-3 flex justify-end">
        <Button type="primary" disabled={sessions.length === 0} loading={revokeAll.isPending} onClick={confirmAll}>
          Keluarkan Semua Sesi
        </Button>
      </div>
    </Panel>
  );
};

export default SessionsCard;
