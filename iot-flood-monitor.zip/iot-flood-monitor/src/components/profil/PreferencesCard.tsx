import type { ReactNode } from "react";
import { Modal, Spin, Switch, message } from "antd";
import {
  AlertOutlined,
  BellOutlined,
  FileTextOutlined,
  MailOutlined,
  MessageOutlined,
  WhatsAppOutlined,
} from "@ant-design/icons";
import Panel from "@/components/dashboard/Panel";
import { usePreferences, useProfileMutations } from "@/hooks/useProfile";
import type { IPreferences } from "@/types/profile";

const ITEMS: { key: keyof IPreferences; title: string; desc: string; icon: ReactNode }[] = [
  { key: "floodAlert", title: "Peringatan Banjir", desc: "Notifikasi peringatan saat ada bahaya", icon: <AlertOutlined /> },
  { key: "systemInfo", title: "Informasi Sistem", desc: "Update, pemeliharaan, dan informasi umum", icon: <BellOutlined /> },
  { key: "dailyReport", title: "Laporan Harian", desc: "Ringkasan kondisi harian", icon: <FileTextOutlined /> },
  { key: "email", title: "Email", desc: "Terima notifikasi melalui email", icon: <MailOutlined /> },
  { key: "sms", title: "SMS", desc: "Terima notifikasi melalui SMS", icon: <MessageOutlined /> },
  { key: "whatsapp", title: "WhatsApp", desc: "Terima notifikasi melalui WhatsApp", icon: <WhatsAppOutlined /> },
];

const PreferencesCard = () => {
  const { data, isLoading } = usePreferences();
  const prefs = data?.data;
  const { prefs: mutation } = useProfileMutations();

  const apply = (next: IPreferences) =>
    mutation.mutate(next, { onError: (e) => message.error(e instanceof Error ? e.message : "Gagal menyimpan preferensi") });

  const toggle = (key: keyof IPreferences, on: boolean) => {
    if (!prefs) return;
    const next = { ...prefs, [key]: on };
    if (key === "floodAlert" && !on) {
      Modal.confirm({
        title: "Nonaktifkan peringatan banjir?",
        content: "Anda tidak akan menerima notifikasi saat status Siaga atau Bahaya.",
        okText: "Nonaktifkan",
        okButtonProps: { danger: true },
        cancelText: "Batal",
        onOk: () => apply(next),
      });
      return;
    }
    apply(next);
  };

  const noChannel = prefs ? !prefs.email && !prefs.sms && !prefs.whatsapp : false;

  return (
    <Panel title="Preferensi Notifikasi" className="h-full">
      <p className="m-0 mb-2 text-xs text-slate-500">Atur jenis notifikasi yang ingin Anda terima.</p>
      {isLoading || !prefs ? (
        <Spin className="block py-6" />
      ) : (
        <ul className="m-0 flex list-none flex-col p-0">
          {ITEMS.map((i) => (
            <li key={i.key} className="flex items-center gap-3 border-b border-slate-100 py-2.5 last:border-b-0">
              <span className="text-xl text-slate-600">{i.icon}</span>
              <div className="min-w-0 flex-1 leading-tight">
                <p className="m-0 text-xs font-semibold">{i.title}</p>
                <p className="m-0 text-[11px] text-slate-500">{i.desc}</p>
              </div>
              <Switch size="small" checked={prefs[i.key]} onChange={(on) => toggle(i.key, on)} aria-label={i.title} />
            </li>
          ))}
        </ul>
      )}
      {noChannel && prefs?.floodAlert && (
        <p className="m-0 mt-2 rounded bg-amber-50 p-2 text-[11px] text-amber-700">
          Semua saluran (Email, SMS, WhatsApp) nonaktif. Aktifkan minimal satu agar peringatan sampai ke Anda.
        </p>
      )}
    </Panel>
  );
};

export default PreferencesCard;
