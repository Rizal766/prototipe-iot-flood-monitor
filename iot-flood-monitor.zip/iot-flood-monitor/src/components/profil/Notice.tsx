import { CheckCircleFilled, CloseCircleFilled } from "@ant-design/icons";

interface INoticeProps {
  ok: boolean;
  title: string;
  text?: string;
  onClose: () => void;
}

const Notice = ({ ok, title, text, onClose }: INoticeProps) => (
  <div
    role={ok ? "status" : "alert"}
    className={`flex items-start gap-2 rounded-md border p-2.5 text-xs ${
      ok ? "border-green-200 bg-green-50 text-green-700" : "border-red-200 bg-red-50 text-red-600"
    }`}
  >
    {ok ? <CheckCircleFilled className="mt-0.5 text-base" /> : <CloseCircleFilled className="mt-0.5 text-base" />}
    <div className="flex-1">
      <p className="m-0 font-semibold">{title}</p>
      {text && <p className="m-0 opacity-80">{text}</p>}
    </div>
    <button type="button" aria-label="Tutup" onClick={onClose} className="cursor-pointer border-none bg-transparent p-0 opacity-60">
      ×
    </button>
  </div>
);

export default Notice;
