import { useState } from "react";
import { Button, Checkbox, Input } from "antd";
import { Controller, useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import Panel from "@/components/dashboard/Panel";
import { useProfileMutations } from "@/hooks/useProfile";
import { passwordSchema, passwordStrength, type PasswordFormValues } from "@/schemas/profileSchema";
import Notice from "./Notice";

const EMPTY: PasswordFormValues = { oldPassword: "", newPassword: "", confirm: "", signOutOthers: true };
const STRENGTH = [
  { text: "Terlalu pendek", color: "#ef4444" },
  { text: "Lemah", color: "#f97316" },
  { text: "Cukup", color: "#eab308" },
  { text: "Kuat", color: "#22c55e" },
  { text: "Sangat kuat", color: "#16a34a" },
];

const PasswordCard = () => {
  const { password } = useProfileMutations();
  const [notice, setNotice] = useState<{ ok: boolean; title: string; text?: string } | null>(null);

  const {
    control,
    handleSubmit,
    reset,
    setError,
    formState: { errors },
  } = useForm<PasswordFormValues>({ resolver: zodResolver(passwordSchema), defaultValues: EMPTY });
  const newPassword = useWatch({ control, name: "newPassword" }) ?? "";
  const strength = STRENGTH[passwordStrength(newPassword)];

  const onSubmit = async (v: PasswordFormValues) => {
    const res = await password.mutateAsync({
      oldPassword: v.oldPassword,
      newPassword: v.newPassword,
      signOutOthers: v.signOutOthers,
    });
    if (res.status) {
      reset(EMPTY);
      setNotice({
        ok: true,
        title: "Password berhasil diganti",
        text: v.signOutOthers ? "Perangkat lain telah dikeluarkan." : undefined,
      });
    } else {
      if (/lama/i.test(res.message)) setError("oldPassword", { message: res.message });
      setNotice({ ok: false, title: res.message || "Gagal mengganti password" });
    }
  };

  const err = (m?: string) => (m ? <p className="m-0 mt-0.5 text-xs text-red-500">{m}</p> : null);
  const label = "mb-1 block text-xs font-medium text-slate-600";

  return (
    <Panel title="Ganti Sandi" className="h-full">
      <form onSubmit={handleSubmit(onSubmit)} noValidate className="flex flex-col gap-3 text-xs">
        <div>
          <label htmlFor="pw-old" className={label}>Password Lama</label>
          <Controller
            name="oldPassword"
            control={control}
            render={({ field }) => <Input.Password {...field} id="pw-old" autoComplete="current-password" placeholder="Masukkan password lama" status={errors.oldPassword ? "error" : undefined} />}
          />
          {err(errors.oldPassword?.message)}
        </div>
        <div>
          <label htmlFor="pw-new" className={label}>Password Baru</label>
          <Controller
            name="newPassword"
            control={control}
            render={({ field }) => <Input.Password {...field} id="pw-new" autoComplete="new-password" placeholder="Minimal 8 karakter, huruf dan angka" status={errors.newPassword ? "error" : undefined} />}
          />
          {err(errors.newPassword?.message)}
          {newPassword && (
            <div className="mt-1.5 flex items-center gap-2" aria-live="polite">
              <div className="flex flex-1 gap-1">
                {[0, 1, 2, 3].map((i) => (
                  <span key={i} className="h-1.5 flex-1 rounded-full" style={{ background: i < passwordStrength(newPassword) ? strength.color : "#e2e8f0" }} />
                ))}
              </div>
              <span className="w-20 text-right text-[11px]" style={{ color: strength.color }}>
                {strength.text}
              </span>
            </div>
          )}
        </div>
        <div>
          <label htmlFor="pw-confirm" className={label}>Konfirmasi Password Baru</label>
          <Controller
            name="confirm"
            control={control}
            render={({ field }) => <Input.Password {...field} id="pw-confirm" autoComplete="new-password" placeholder="Ulangi password baru" status={errors.confirm ? "error" : undefined} />}
          />
          {err(errors.confirm?.message)}
        </div>
        <Controller
          name="signOutOthers"
          control={control}
          render={({ field }) => (
            <Checkbox checked={field.value} onChange={(e) => field.onChange(e.target.checked)}>
              Keluarkan dari semua perangkat lain
            </Checkbox>
          )}
        />
        {notice && <Notice {...notice} onClose={() => setNotice(null)} />}
        <div className="flex justify-end gap-2">
          <Button
            onClick={() => {
              reset(EMPTY);
              setNotice(null);
            }}
          >
            Batal
          </Button>
          <Button type="primary" htmlType="submit" loading={password.isPending}>
            Ganti Password
          </Button>
        </div>
      </form>
    </Panel>
  );
};

export default PasswordCard;
