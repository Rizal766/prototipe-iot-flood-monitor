import { useState } from "react";
import { Outlet } from "react-router-dom";
import { Drawer } from "antd";
import Header from "./Header";
import Sidebar from "./Sidebar";

const MainLayout = () => {
  const [open, setOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      <Header onMenuClick={() => setOpen(true)} />
      <div className="flex">
        <aside className="sticky top-[53px] hidden h-[calc(100vh-53px)] w-60 shrink-0 border-r border-slate-200 bg-white lg:block">
          <Sidebar />
        </aside>
        <Drawer
          placement="left"
          width={250}
          open={open}
          onClose={() => setOpen(false)}
          styles={{ body: { padding: 0 } }}
        >
          <Sidebar onNavigate={() => setOpen(false)} />
        </Drawer>
        <main className="min-w-0 flex-1 p-3 sm:p-4">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default MainLayout;
