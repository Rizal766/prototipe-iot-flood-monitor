import { InputNumber, Switch, message } from "antd";
import Panel from "@/components/dashboard/Panel";
import { useUserMutations } from "@/hooks/useUsers";
import type { IArea } from "@/types/user";

interface IAreaTableProps {
  areas: IArea[];
  isAdmin: boolean;
}

const AreaTable = ({ areas, isAdmin }: IAreaTableProps) => {
  const { area } = useUserMutations();
  const total = areas.reduce((a, x) => a + x.residents, 0);

  const patch = async (district: string, p: Partial<Pick<IArea, "residents" | "active">>) => {
    const res = await area.mutateAsync({ district, patch: p });
    if (!res.status) message.error(res.message || "Gagal memperbarui wilayah");
  };

  return (
    <Panel title="Warga Terdaftar">
      <p className="m-0 mb-2 text-xs text-slate-500">
        Warga di wilayah berstatus Aktif ikut menerima peringatan publik (SMS/WhatsApp) saat status Siaga atau Bahaya.
      </p>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[420px] border-collapse text-xs">
          <thead>
            <tr className="border-b border-slate-200 text-left text-slate-600">
              <th className="px-2 py-2 font-semibold">Wilayah</th>
              <th className="px-2 py-2 font-semibold">Jumlah Warga</th>
              <th className="px-2 py-2 font-semibold">Status Siaran</th>
            </tr>
          </thead>
          <tbody>
            {areas.map((a) => (
              <tr key={a.district} className="border-b border-slate-100">
                <td className="px-2 py-2.5 font-medium">{a.district}</td>
                <td className="px-2 py-2.5">
                  <InputNumber
                    size="small"
                    min={0}
                    className="w-28"
                    defaultValue={a.residents}
                    disabled={!isAdmin}
                    aria-label={`Jumlah warga ${a.district}`}
                    onBlur={(e) => {
                      const n = Number(e.target.value.replace(/[^\d]/g, ""));
                      if (!Number.isNaN(n) && n !== a.residents) void patch(a.district, { residents: n });
                    }}
                  />
                </td>
                <td className="px-2 py-2.5">
                  <label className="flex items-center gap-2">
                    <Switch size="small" checked={a.active} disabled={!isAdmin} onChange={(on) => void patch(a.district, { active: on })} />
                    <span className={a.active ? "font-medium text-green-600" : "text-slate-500"}>{a.active ? "Aktif" : "Nonaktif"}</span>
                  </label>
                </td>
              </tr>
            ))}
            {areas.length === 0 && (
              <tr>
                <td colSpan={3} className="py-4 text-center text-slate-400">Belum ada wilayah</td>
              </tr>
            )}
          </tbody>
          <tfoot>
            <tr className="text-slate-700">
              <td className="px-2 py-2 font-semibold">Total</td>
              <td className="px-2 py-2 font-semibold" colSpan={2}>{total.toLocaleString("id-ID")} warga</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </Panel>
  );
};

export default AreaTable;
