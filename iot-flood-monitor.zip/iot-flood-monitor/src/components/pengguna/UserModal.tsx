import { Button, Input, Modal, Select, Switch, message } from "antd";
import { Controller, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useUserMutations } from "@/hooks/useUsers";
import { userFormSchema, type UserFormValues } from "@/schemas/userSchema";
import { ROLE_LABEL, UserRole } from "@/types/auth";
import { UserStatus, type IUser } from "@/types/user";

const Form = ({ user, districts, onClose }: { user: IUser; districts: string[]; onClose: () => void }) => {
  const { update } = useUserMutations();
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<UserFormValues>({
    resolver: zodResolver(userFormSchema),
    defaultValues: {
      name: user.name,
      email: user.email,
      phone: user.phone,
      role: user.role,
      areas: user.areas,
      status: user.status,
    },
  });

  const onSubmit = async (v: UserFormValues) => {
    const res = await update.mutateAsync({
      id: user.id,
      payload: { ...v, name: v.name.trim(), email: v.email.trim(), phone: v.phone.trim() },
    });
    if (res.status) {
      message.success("Data pengguna diperbarui");
      onClose();
    } else {
      message.error(res.message || "Gagal memperbarui pengguna");
    }
  };

  const err = (m?: string) => (m ? <p className="m-0 mt-0.5 text-xs text-red-500">{m}</p> : null);
  const label = "mb-1 block text-xs font-medium text-slate-600";

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="grid grid-cols-1 gap-3 sm:grid-cols-2">
      <div className="sm:col-span-2">
        <label htmlFor="usr-name" className={label}>Nama Lengkap</label>
        <Controller name="name" control={control} render={({ field }) => <Input {...field} id="usr-name" />} />
        {err(errors.name?.message)}
      </div>
      <div>
        <label htmlFor="usr-email" className={label}>Email</label>
        <Controller name="email" control={control} render={({ field }) => <Input {...field} id="usr-email" />} />
        {err(errors.email?.message)}
      </div>
      <div>
        <label htmlFor="usr-phone" className={label}>Nomor HP</label>
        <Controller name="phone" control={control} render={({ field }) => <Input {...field} id="usr-phone" />} />
        {err(errors.phone?.message)}
      </div>
      <div>
        <label className={label}>Role</label>
        <Controller
          name="role"
          control={control}
          render={({ field }) => (
            <Select {...field} className="w-full" options={Object.values(UserRole).map((r) => ({ value: r, label: ROLE_LABEL[r] }))} />
          )}
        />
      </div>
      <div>
        <label className={label}>Status akun</label>
        <Controller
          name="status"
          control={control}
          render={({ field }) => (
            <label className="flex items-center gap-2 text-xs">
              <Switch checked={field.value === UserStatus.AKTIF} onChange={(on) => field.onChange(on ? UserStatus.AKTIF : UserStatus.NONAKTIF)} />
              {field.value === UserStatus.AKTIF ? "Aktif" : "Nonaktif"}
            </label>
          )}
        />
      </div>
      <div className="sm:col-span-2">
        <label className={label}>Wilayah Tugas</label>
        <Controller
          name="areas"
          control={control}
          render={({ field }) => (
            <Select {...field} mode="multiple" className="w-full" placeholder="Semua Wilayah" options={districts.map((d) => ({ value: d, label: d }))} />
          )}
        />
        <p className="m-0 mt-0.5 text-[11px] text-slate-400">Kosongkan untuk memberi akses ke semua wilayah.</p>
      </div>
      <div className="flex justify-end gap-2 sm:col-span-2">
        <Button onClick={onClose}>Batal</Button>
        <Button type="primary" htmlType="submit" loading={update.isPending}>
          Simpan Perubahan
        </Button>
      </div>
    </form>
  );
};

interface IUserModalProps {
  user: IUser | null;
  districts: string[];
  onClose: () => void;
}

const UserModal = ({ user, districts, onClose }: IUserModalProps) => (
  <Modal open={user !== null} title={user ? `Edit Pengguna - ${user.name}` : "Edit Pengguna"} footer={null} onCancel={onClose} width={560}>
    {user && <Form key={user.id} user={user} districts={districts} onClose={onClose} />}
  </Modal>
);

export default UserModal;
