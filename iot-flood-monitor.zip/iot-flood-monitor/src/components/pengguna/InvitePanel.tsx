import { Button, Checkbox, Input, Select, message } from "antd";
import { CheckCircleFilled, CloseCircleFilled } from "@ant-design/icons";
import { Controller, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useState } from "react";
import type { GridColDef } from "@mui/x-data-grid";
import Panel from "@/components/dashboard/Panel";
import SimpleGrid from "@/components/common/SimpleGrid";
import { useInvitations, useUserMutations } from "@/hooks/useUsers";
import { EMAIL_RE, inviteSchema, type InviteFormValues } from "@/schemas/userSchema";
import { ROLE_LABEL, UserRole } from "@/types/auth";
import { INVITE_META, InviteStatus, UserStatus, type IInvitation } from "@/types/user";
import { formatAgoShort } from "@/utils/time";
import RoleBadge from "./RoleBadge";

const DEFAULTS: InviteFormValues = { name: "", target: "", role: UserRole.PETUGAS, areas: [], viaEmail: true };

interface IInvitePanelProps {
  districts: string[];
  isAdmin: boolean;
}

type Feedback = { ok: boolean; text: string } | null;

const InvitePanel = ({ districts, isAdmin }: IInvitePanelProps) => {
  const { data, isLoading } = useInvitations();
  const invitations = data?.data ?? [];
  const { invite, create, resend, cancel } = useUserMutations();
  const [feedback, setFeedback] = useState<Feedback>(null);

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<InviteFormValues>({ resolver: zodResolver(inviteSchema), defaultValues: DEFAULTS });

  const onSubmit = async (v: InviteFormValues) => {
    const target = v.target.trim();
    const common = { name: v.name.trim(), role: v.role, areas: v.areas };
    if (v.viaEmail) {
      const res = await invite.mutateAsync({ ...common, target, viaEmail: true });
      if (!res.status) {
        setFeedback({ ok: false, text: res.message || "Gagal mengirim undangan" });
        return;
      }
      setFeedback(
        res.data?.status === InviteStatus.GAGAL
          ? { ok: false, text: `Gagal mengirim undangan ke ${target}. Periksa alamat email lalu kirim ulang.` }
          : { ok: true, text: `Undangan terkirim ke ${target}.` },
      );
    } else {
      // tanpa undangan: akun langsung dibuat aktif
      const isEmail = EMAIL_RE.test(target);
      const res = await create.mutateAsync({
        ...common,
        email: isEmail ? target : "",
        phone: isEmail ? "" : target,
        status: UserStatus.AKTIF,
      });
      if (!res.status) {
        setFeedback({ ok: false, text: res.message || "Gagal membuat pengguna" });
        return;
      }
      setFeedback({ ok: true, text: `Pengguna ${common.name} dibuat dan langsung aktif.` });
    }
    reset(DEFAULTS);
  };

  const columns: GridColDef<IInvitation>[] = [
    {
      field: "target",
      headerName: "Email / No. HP",
      flex: 1,
      minWidth: 150,
      renderCell: (p) => (
        <div className="leading-tight">
          <div className="break-all">{p.row.target}</div>
          <div className="text-[10px] text-slate-500">{p.row.name}</div>
        </div>
      ),
    },
    { field: "role", headerName: "Role", width: 120, renderCell: (p) => <RoleBadge role={p.row.role} /> },
    { field: "sentAt", headerName: "Dikirim", width: 100, valueFormatter: (v: string) => formatAgoShort(v) },
    {
      field: "status",
      headerName: "Status",
      width: 110,
      renderCell: (p) => (
        <span className="font-medium" style={{ color: INVITE_META[p.row.status].color }}>
          {INVITE_META[p.row.status].label}
        </span>
      ),
    },
    {
      field: "actions",
      headerName: "Aksi",
      width: 150,
      sortable: false,
      renderCell: (p) =>
        isAdmin ? (
          <span className="flex gap-1">
            <Button
              size="small"
              loading={resend.isPending && resend.variables === p.row.id}
              onClick={async () => {
                const res = await resend.mutateAsync(p.row.id);
                if (res.status && res.data?.status !== InviteStatus.GAGAL) message.success("Undangan dikirim ulang");
                else message.error(res.message || "Undangan gagal terkirim lagi");
              }}
            >
              Kirim ulang
            </Button>
            <Button size="small" type="text" danger onClick={() => void cancel.mutateAsync(p.row.id)}>
              Batal
            </Button>
          </span>
        ) : null,
    },
  ];

  const err = (m?: string) => (m ? <p className="m-0 mt-0.5 text-[11px] text-red-500">{m}</p> : null);
  const label = "mb-1 block text-xs font-medium text-slate-600";

  return (
    <div className="flex min-w-0 flex-col gap-3">
      <Panel title="Form Tambah Pengguna">
        {!isAdmin ? (
          <p className="m-0 rounded bg-slate-50 p-3 text-xs text-slate-500">
            Hanya Admin yang dapat menambah pengguna. Anda masuk sebagai Operator.
          </p>
        ) : (
          <form onSubmit={handleSubmit(onSubmit)} noValidate className="flex flex-col gap-3 text-xs">
            <div>
              <label htmlFor="inv-name" className={label}>Nama Lengkap</label>
              <Controller name="name" control={control} render={({ field }) => <Input {...field} id="inv-name" placeholder="Masukkan nama lengkap" />} />
              {err(errors.name?.message)}
            </div>
            <div>
              <label htmlFor="inv-target" className={label}>Email / No. HP</label>
              <Controller name="target" control={control} render={({ field }) => <Input {...field} id="inv-target" placeholder="nama@email.com atau 08xxxxxxxxxx" />} />
              {err(errors.target?.message)}
            </div>
            <div>
              <label className={label}>Role</label>
              <Controller
                name="role"
                control={control}
                render={({ field }) => (
                  <Select {...field} className="w-full" options={Object.values(UserRole).map((r) => ({ value: r, label: ROLE_LABEL[r] }))} />
                )}
              />
            </div>
            <div>
              <label className={label}>Wilayah Tugas</label>
              <Controller
                name="areas"
                control={control}
                render={({ field }) => (
                  <Select {...field} mode="multiple" className="w-full" placeholder="Semua Wilayah" options={districts.map((d) => ({ value: d, label: d }))} />
                )}
              />
            </div>
            <Controller
              name="viaEmail"
              control={control}
              render={({ field }) => (
                <Checkbox checked={field.value} onChange={(e) => field.onChange(e.target.checked)}>
                  Kirim undangan melalui email
                </Checkbox>
              )}
            />
            {feedback && (
              <div
                role="status"
                className={`flex items-start gap-2 rounded-md border p-2 ${feedback.ok ? "border-green-200 bg-green-50 text-green-700" : "border-red-200 bg-red-50 text-red-600"}`}
              >
                {feedback.ok ? <CheckCircleFilled className="mt-0.5" /> : <CloseCircleFilled className="mt-0.5" />}
                <span className="flex-1">{feedback.text}</span>
              </div>
            )}
            <div className="grid grid-cols-2 gap-2">
              <Button onClick={() => { reset(DEFAULTS); setFeedback(null); }}>Batal</Button>
              <Button type="primary" htmlType="submit" loading={invite.isPending || create.isPending}>
                Kirim Undangan
              </Button>
            </div>
          </form>
        )}
      </Panel>

      <Panel title="Undangan Terkirim">
        <SimpleGrid rows={invitations} columns={columns} loading={isLoading} emptyText="Belum ada undangan" rowHeight={52} />
      </Panel>
    </div>
  );
};

export default InvitePanel;
