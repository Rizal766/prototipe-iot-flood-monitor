import { ROLE_LABEL, UserRole } from "@/types/auth";

const COLOR: Record<UserRole, string> = {
  [UserRole.ADMIN]: "#d97706",
  [UserRole.OPERATOR]: "#16a34a",
  [UserRole.PETUGAS]: "#2563eb",
};

const RoleBadge = ({ role }: { role: UserRole }) => (
  <span className="rounded px-2 py-0.5 text-[11px] font-semibold text-white" style={{ background: COLOR[role] }}>
    {ROLE_LABEL[role]}
  </span>
);

export default RoleBadge;
