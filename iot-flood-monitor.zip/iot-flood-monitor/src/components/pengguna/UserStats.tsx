import { memo, type ReactNode } from "react";
import { SafetyCertificateOutlined, TeamOutlined, ToolOutlined, UserOutlined } from "@ant-design/icons";
import { UserRole } from "@/types/auth";
import type { IUser } from "@/types/user";

type Filter = UserRole | "ALL";

interface ICardProps {
  label: string;
  value: number;
  icon: ReactNode;
  color: string;
  active: boolean;
  onClick: () => void;
}

const Card = memo(function Card({ label, value, icon, color, active, onClick }: ICardProps) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={`flex w-full cursor-pointer items-center gap-3 rounded-lg border bg-white p-3 text-left shadow-sm ${
        active ? "border-blue-500 ring-1 ring-blue-500" : "border-slate-200"
      }`}
    >
      <span className="text-3xl" style={{ color }}>
        {icon}
      </span>
      <span>
        <span className="block text-xs text-slate-600">{label}</span>
        <span className="block text-2xl font-bold leading-tight">{value}</span>
        <span className="block text-[11px] text-slate-400">orang</span>
      </span>
    </button>
  );
});

interface IUserStatsProps {
  users: IUser[];
  active: Filter;
  onSelect: (f: Filter) => void;
}

const UserStats = ({ users, active, onSelect }: IUserStatsProps) => {
  const count = (r: UserRole) => users.filter((u) => u.role === r).length;
  const toggle = (f: Filter) => () => onSelect(active === f ? "ALL" : f);
  return (
    <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
      <Card label="Total Pengguna" value={users.length} icon={<TeamOutlined />} color="#0ea5e9" active={active === "ALL"} onClick={() => onSelect("ALL")} />
      <Card label="Admin" value={count(UserRole.ADMIN)} icon={<SafetyCertificateOutlined />} color="#d97706" active={active === UserRole.ADMIN} onClick={toggle(UserRole.ADMIN)} />
      <Card label="Operator" value={count(UserRole.OPERATOR)} icon={<UserOutlined />} color="#16a34a" active={active === UserRole.OPERATOR} onClick={toggle(UserRole.OPERATOR)} />
      <Card label="Petugas Lapangan" value={count(UserRole.PETUGAS)} icon={<ToolOutlined />} color="#2563eb" active={active === UserRole.PETUGAS} onClick={toggle(UserRole.PETUGAS)} />
    </div>
  );
};

export default UserStats;
