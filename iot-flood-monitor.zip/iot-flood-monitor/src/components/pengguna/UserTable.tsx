import { useMemo } from "react";
import { DataGrid, type GridColDef, type GridPaginationModel } from "@mui/x-data-grid";
import { Button, Dropdown } from "antd";
import { EditOutlined, MoreOutlined } from "@ant-design/icons";
import GridFooter from "@/components/common/GridFooter";
import { UserStatus, type IUser } from "@/types/user";
import { formatDateTime } from "@/utils/time";
import RoleBadge from "./RoleBadge";

const NoRows = () => (
  <div className="flex h-full items-center justify-center text-sm text-slate-400">Tidak ada pengguna yang cocok</div>
);

interface IUserTableProps {
  rows: IUser[];
  loading: boolean;
  isAdmin: boolean;
  selfEmail: string;
  paging: GridPaginationModel;
  onPagingChange: (m: GridPaginationModel) => void;
  onEdit: (u: IUser) => void;
  onToggle: (u: IUser) => void;
  onDelete: (u: IUser) => void;
}

const initials = (name: string) =>
  name
    .split(/\s+/)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? "")
    .join("");

const UserTable = ({ rows, loading, isAdmin, selfEmail, paging, onPagingChange, onEdit, onToggle, onDelete }: IUserTableProps) => {
  const columns = useMemo<GridColDef<IUser>[]>(
    () => [
      {
        field: "name",
        headerName: "Nama",
        flex: 1,
        minWidth: 170,
        renderCell: (p) => (
          <span className="flex items-center gap-2">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-slate-200 text-[11px] font-bold text-slate-600">
              {initials(p.row.name)}
            </span>
            <span className="font-medium">{p.row.name}</span>
          </span>
        ),
      },
      {
        field: "email",
        headerName: "Email / Nomor HP",
        flex: 1,
        minWidth: 200,
        renderCell: (p) => (
          <div className="leading-tight">
            <div>{p.row.email || "-"}</div>
            <div className="text-[11px] text-slate-500">{p.row.phone || "-"}</div>
          </div>
        ),
      },
      { field: "role", headerName: "Role", width: 140, renderCell: (p) => <RoleBadge role={p.row.role} /> },
      {
        field: "areas",
        headerName: "Wilayah Tugas",
        width: 170,
        sortable: false,
        renderCell: (p) => <span>{p.row.areas.length ? p.row.areas.join(", ") : "Semua Wilayah"}</span>,
      },
      {
        field: "status",
        headerName: "Status",
        width: 100,
        renderCell: (p) =>
          p.row.status === UserStatus.AKTIF ? (
            <span className="rounded border border-green-600 bg-green-50 px-2 py-0.5 text-[11px] font-semibold text-green-700">Aktif</span>
          ) : (
            <span className="rounded border border-slate-400 bg-slate-50 px-2 py-0.5 text-[11px] font-semibold text-slate-500">Nonaktif</span>
          ),
      },
      {
        field: "lastLogin",
        headerName: "Terakhir Login",
        width: 160,
        valueFormatter: (v: string | null) => (v ? formatDateTime(v) : "Belum pernah"),
      },
      {
        field: "actions",
        headerName: "Aksi",
        width: 100,
        sortable: false,
        disableColumnMenu: true,
        renderCell: (p) => {
          const u = p.row;
          const self = u.email !== "" && u.email.toLowerCase() === selfEmail.toLowerCase();
          const items = [
            { key: "toggle", label: u.status === UserStatus.AKTIF ? "Nonaktifkan" : "Aktifkan", disabled: self, onClick: () => onToggle(u) },
            { key: "delete", label: "Hapus Pengguna", danger: true, disabled: self, onClick: () => onDelete(u) },
          ];
          return (
            <span className="flex items-center gap-1">
              <Button size="small" type="text" aria-label="Edit pengguna" icon={<EditOutlined />} disabled={!isAdmin} onClick={() => onEdit(u)} />
              {isAdmin && (
                <Dropdown trigger={["click"]} menu={{ items }}>
                  <Button size="small" type="text" aria-label="Menu lainnya" icon={<MoreOutlined />} />
                </Dropdown>
              )}
            </span>
          );
        },
      },
    ],
    [isAdmin, selfEmail, onEdit, onToggle, onDelete],
  );

  return (
    <>
      <DataGrid
        rows={rows}
        columns={columns}
        loading={loading}
        autoHeight
        rowHeight={56}
        columnHeaderHeight={44}
        hideFooter
        disableRowSelectionOnClick
        disableColumnMenu
        paginationModel={paging}
        onPaginationModelChange={onPagingChange}
        pageSizeOptions={[10, 25, 50]}
        slots={{ noRowsOverlay: NoRows }}
        sx={{
          border: 0,
          fontSize: 12,
          "& .MuiDataGrid-columnHeaders": { backgroundColor: "#f8fafc" },
          "& .MuiDataGrid-overlayWrapper": { minHeight: 120 },
        }}
      />
      <GridFooter total={rows.length} label="Pengguna" paging={paging} onChange={onPagingChange} />
    </>
  );
};

export default UserTable;
