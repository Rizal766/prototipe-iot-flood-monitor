import { useState } from "react";
import { Button, Checkbox, message } from "antd";
import Panel from "@/components/dashboard/Panel";
import { useUserMutations } from "@/hooks/useUsers";
import { ROLE_LABEL, UserRole } from "@/types/auth";
import { FEATURE_LABEL, Feature, PERMISSION_ROLES, type IPermissionMatrix } from "@/types/permission";

interface IPermissionMatrixProps {
  matrix: IPermissionMatrix;
  isAdmin: boolean;
}

const PermissionMatrix = ({ matrix, isAdmin }: IPermissionMatrixProps) => {
  const { permissions } = useUserMutations();
  const [draft, setDraft] = useState<IPermissionMatrix>(() => structuredClone(matrix));
  const dirty = JSON.stringify(draft) !== JSON.stringify(matrix);

  const toggle = (f: Feature, r: UserRole, value: boolean) =>
    setDraft((d) => ({ ...d, [f]: { ...d[f], [r]: value } }));

  const save = async () => {
    const res = await permissions.mutateAsync(draft);
    if (res.status) message.success("Hak akses disimpan");
    else message.error(res.message || "Gagal menyimpan hak akses");
  };

  return (
    <Panel
      title="Hak Akses per Role"
      actions={
        isAdmin && (
          <span className="flex gap-2">
            <Button size="small" disabled={!dirty} onClick={() => setDraft(structuredClone(matrix))}>
              Reset
            </Button>
            <Button size="small" type="primary" disabled={!dirty} loading={permissions.isPending} onClick={() => void save()}>
              Simpan Hak Akses
            </Button>
          </span>
        )
      }
    >
      <div className="overflow-x-auto">
        <table className="w-full min-w-[420px] border-collapse text-xs">
          <thead>
            <tr className="border-b border-slate-200 text-left text-slate-600">
              <th className="px-2 py-2 font-semibold">Fitur / Menu</th>
              {PERMISSION_ROLES.map((r) => (
                <th key={r} className="px-2 py-2 text-center font-semibold">
                  {ROLE_LABEL[r]}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Object.values(Feature).map((f) => (
              <tr key={f} className="border-b border-slate-100">
                <td className="px-2 py-2.5 font-medium">{FEATURE_LABEL[f]}</td>
                {PERMISSION_ROLES.map((r) => (
                  <td key={r} className="px-2 py-2.5 text-center">
                    <Checkbox
                      checked={r === UserRole.ADMIN ? true : draft[f][r]}
                      disabled={!isAdmin || r === UserRole.ADMIN}
                      onChange={(e) => toggle(f, r, e.target.checked)}
                      aria-label={`${FEATURE_LABEL[f]} - ${ROLE_LABEL[r]}`}
                    />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="m-0 mt-2 text-[11px] text-slate-500">
        Admin selalu memiliki semua akses. Hak akses menentukan menu yang dapat dibuka; menambah, mengubah, dan menghapus data tetap khusus Admin.
      </p>
    </Panel>
  );
};

export default PermissionMatrix;
