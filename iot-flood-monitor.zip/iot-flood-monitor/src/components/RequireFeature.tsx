import type { ReactNode } from "react";
import { Button, Result, Spin } from "antd";
import { useNavigate } from "react-router-dom";
import { usePermissions } from "@/hooks/usePermissions";
import type { Feature } from "@/types/permission";

const RequireFeature = ({ feature, children }: { feature: Feature; children: ReactNode }) => {
  const { can, ready } = usePermissions();
  const navigate = useNavigate();

  if (!ready) return <Spin className="mt-10 block" />;
  if (!can(feature)) {
    return (
      <Result
        status="403"
        title="Akses ditolak"
        subTitle="Peran Anda tidak memiliki izin untuk membuka halaman ini. Hubungi Admin bila perlu akses."
        extra={<Button type="primary" onClick={() => navigate("/")}>Kembali ke Dashboard</Button>}
      />
    );
  }
  return <>{children}</>;
};

export default RequireFeature;
