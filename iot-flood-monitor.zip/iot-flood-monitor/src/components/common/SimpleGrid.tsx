import { useMemo } from "react";
import { DataGrid, type GridColDef, type GridValidRowModel } from "@mui/x-data-grid";

interface ISimpleGridProps<T extends GridValidRowModel> {
  rows: T[];
  columns: GridColDef<T>[];
  loading?: boolean;
  emptyText?: string;
  rowHeight?: number;
}

// Tabel ringkas tanpa pagination untuk daftar pendek
const SimpleGrid = <T extends GridValidRowModel>({
  rows,
  columns,
  loading,
  emptyText = "Belum ada data",
  rowHeight = 52,
}: ISimpleGridProps<T>) => {
  const NoRows = useMemo(
    () => () => <div className="flex h-full items-center justify-center text-sm text-slate-400">{emptyText}</div>,
    [emptyText],
  );
  return (
    <DataGrid
      rows={rows}
      columns={columns}
      loading={loading}
      autoHeight
      rowHeight={rowHeight}
      columnHeaderHeight={42}
      hideFooter
      disableRowSelectionOnClick
      disableColumnMenu
      slots={{ noRowsOverlay: NoRows }}
      sx={{
        border: 0,
        fontSize: 12,
        "& .MuiDataGrid-columnHeaders": { backgroundColor: "#f8fafc" },
        "& .MuiDataGrid-overlayWrapper": { minHeight: 100 },
      }}
    />
  );
};

export default SimpleGrid;
