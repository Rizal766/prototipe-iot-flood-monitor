import type { GridPaginationModel } from "@mui/x-data-grid";
import { Pagination, Select } from "antd";

const PAGE_SIZES = [10, 25, 50];

interface IGridFooterProps {
  total: number;
  label: string; // contoh: "Pengguna"
  paging: GridPaginationModel;
  onChange: (m: GridPaginationModel) => void;
}

const GridFooter = ({ total, label, paging, onChange }: IGridFooterProps) => {
  const start = total === 0 ? 0 : paging.page * paging.pageSize + 1;
  const end = Math.min((paging.page + 1) * paging.pageSize, total);
  return (
    <div className="mt-2 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-2 text-xs text-slate-600">
      <span>
        Menampilkan {start} - {end} dari {total} {label}
      </span>
      <span className="flex items-center gap-2">
        Tampilkan
        <Select
          size="small"
          value={paging.pageSize}
          onChange={(v) => onChange({ page: 0, pageSize: v })}
          options={PAGE_SIZES.map((n) => ({ value: n, label: n }))}
        />
      </span>
      <Pagination
        size="small"
        current={paging.page + 1}
        pageSize={paging.pageSize}
        total={total}
        showSizeChanger={false}
        onChange={(p) => onChange({ ...paging, page: p - 1 })}
      />
    </div>
  );
};

export default GridFooter;
