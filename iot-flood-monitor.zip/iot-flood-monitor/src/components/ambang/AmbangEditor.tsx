import { useMemo, useState, type ReactNode } from "react";
import { Alert, Button, InputNumber, Modal, Select } from "antd";
import { BellOutlined, CheckCircleFilled, LineChartOutlined } from "@ant-design/icons";
import { Controller, useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import Panel from "@/components/dashboard/Panel";
import { alertFormSchema, toFormValues, toPayload, type AlertFormValues } from "@/schemas/alertConfigSchema";
import type { IAlertConfig, IAlertConfigPayload } from "@/types/alertConfig";
import type { ISensor } from "@/types/sensor";
import { THRESHOLD_TEMPLATES, matchTemplate } from "@/utils/thresholdTemplates";
import type { IThresholds } from "@/utils/thresholds";
import { formatDateTime } from "@/utils/time";
import AlertMatrix from "./AlertMatrix";
import { ConfigSummary, NotificationPreview, ValidationBox } from "./ConfigSidebar";
import ScalePreview from "./ScalePreview";

type Tab = "ambang" | "aturan";
const CUSTOM = "CUSTOM";

const LEVELS: { key: "waspada" | "siaga" | "bahaya"; label: string; color: string }[] = [
  { key: "waspada", label: "Waspada", color: "#eab308" },
  { key: "siaga", label: "Siaga", color: "#f97316" },
  { key: "bahaya", label: "Bahaya", color: "#ef4444" },
];

const RULES: {
  key: "rainfall" | "offlineMinutes" | "batteryPercent";
  title: string;
  hint: string;
  unit: string;
}[] = [
  { key: "rainfall", title: "Curah Hujan", hint: "Peringatan dimulai jika intensitas mencapai lebih dari", unit: "mm/jam" },
  { key: "offlineMinutes", title: "Sensor Offline", hint: "Dianggap offline setelah", unit: "menit" },
  { key: "batteryPercent", title: "Baterai Lemah", hint: "Peringatan jika baterai di bawah", unit: "%" },
];

interface IAmbangEditorProps {
  sensors: ISensor[];
  sensor: ISensor;
  config: IAlertConfig;
  isAdmin: boolean;
  saving: boolean;
  savedNotice: boolean;
  onDismissNotice: () => void;
  onSelectSensor: (id: number) => void;
  onSave: (payload: IAlertConfigPayload) => Promise<void>;
  onApplyMany: (thresholds: IThresholds) => void;
}

const AmbangEditor = ({
  sensors,
  sensor,
  config,
  isAdmin,
  saving,
  savedNotice,
  onDismissNotice,
  onSelectSensor,
  onSave,
  onApplyMany,
}: IAmbangEditorProps) => {
  const [tab, setTab] = useState<Tab>("ambang");
  const {
    control,
    handleSubmit,
    setValue,
    reset,
    formState: { isDirty },
  } = useForm<AlertFormValues>({
    resolver: zodResolver(alertFormSchema),
    defaultValues: toFormValues(config),
    mode: "onChange",
  });
  const values = useWatch({ control });

  // Validasi lintas-kolom dihitung langsung agar panel "Validasi Data" selalu mutakhir
  const issues = useMemo(() => {
    const r = alertFormSchema.safeParse(values);
    return r.success ? [] : r.error.issues;
  }, [values]);
  const issueOf = (path: string) => issues.find((i) => i.path.join(".") === path)?.message;
  const messages = [...new Set(issues.map((i) => i.message))];
  const thresholdIssues = issues.filter((i) => ["waspada", "siaga", "bahaya"].includes(String(i.path[0]))).length;
  const ruleIssues = issues.filter((i) => ["rainfall", "offlineMinutes", "batteryPercent"].includes(String(i.path[0]))).length;

  const num = (v: number | null | undefined) => (typeof v === "number" && !Number.isNaN(v) ? v : null);
  const w = num(values.waspada);
  const s = num(values.siaga);
  const b = num(values.bahaya);
  const tpl = w !== null && s !== null && b !== null ? matchTemplate({ waspada: w, siaga: s, bahaya: b }) : undefined;
  const templateName = tpl?.name ?? "Kustom";

  const disabled = !isAdmin;
  const canSave = isAdmin && issues.length === 0 && isDirty;

  const changeSensor = (id: number) => {
    if (id === sensor.id) return;
    if (!isDirty) {
      onSelectSensor(id);
      return;
    }
    Modal.confirm({
      title: "Pindah sensor?",
      content: "Perubahan yang belum disimpan akan hilang.",
      okText: "Pindah",
      cancelText: "Batal",
      onOk: () => onSelectSensor(id),
    });
  };

  const applyTemplate = (name: string) => {
    const t = THRESHOLD_TEMPLATES.find((x) => x.name === name);
    if (!t) return;
    (["waspada", "siaga", "bahaya"] as const).forEach((k) => setValue(k, t.thresholds[k], { shouldDirty: true, shouldValidate: true }));
  };

  const err = (m?: string) => (m ? <p className="m-0 mt-0.5 text-[11px] text-red-500">{m}</p> : null);

  const tabBtn = (key: Tab, label: string, icon: ReactNode, badge: number) => (
    <button
      key={key}
      type="button"
      role="tab"
      aria-selected={tab === key}
      onClick={() => setTab(key)}
      className={`flex cursor-pointer items-center gap-2 border-x-0 border-t-0 bg-transparent px-4 py-3 text-sm font-medium ${
        tab === key ? "border-b-2 border-blue-600 text-blue-600" : "border-b-2 border-transparent text-slate-600"
      }`}
    >
      <span className="text-lg">{icon}</span>
      {label}
      {badge > 0 && <span className="rounded-full bg-red-500 px-1.5 text-[10px] font-semibold text-white">{badge}</span>}
    </button>
  );

  return (
    <div className="grid grid-cols-1 gap-3 xl:grid-cols-[minmax(0,1fr)_340px]">
      <div className="flex min-w-0 flex-col gap-3">
        {!isAdmin && (
          <Alert type="info" showIcon message="Anda masuk sebagai Operator: pengaturan ini hanya dapat dilihat. Perubahan dilakukan oleh Admin." />
        )}

        <div className="flex gap-1 overflow-x-auto rounded-lg border border-slate-200 bg-white px-2 shadow-sm" role="tablist">
          {tabBtn("ambang", "Ambang Batas", <LineChartOutlined />, thresholdIssues + ruleIssues)}
          {tabBtn("aturan", "Aturan Alert", <BellOutlined />, 0)}
        </div>

        <Panel title="Sensor & Template">
          <div className="grid grid-cols-1 gap-3 md:grid-cols-[1fr_1fr_auto] md:items-end">
            <label className="flex min-w-0 flex-col gap-1 text-xs font-medium text-slate-600">
              Pilih Sensor / Lokasi
              <Select
                showSearch
                optionFilterProp="label"
                value={sensor.id}
                onChange={changeSensor}
                options={sensors.map((x) => ({ value: x.id, label: `${x.location} (${x.code})` }))}
              />
            </label>
            <label className="flex min-w-0 flex-col gap-1 text-xs font-medium text-slate-600">
              Template Ambang
              <Select
                value={tpl?.name ?? CUSTOM}
                disabled={disabled}
                onChange={applyTemplate}
                options={[...THRESHOLD_TEMPLATES.map((t) => ({ value: t.name, label: t.name })), { value: CUSTOM, label: "Kustom", disabled: true }]}
              />
            </label>
            <Button
              disabled={disabled || issues.length > 0 || w === null || s === null || b === null}
              onClick={() => w !== null && s !== null && b !== null && onApplyMany({ waspada: w, siaga: s, bahaya: b })}
            >
              Terapkan Template ke Banyak Sensor
            </Button>
          </div>
        </Panel>

        {tab === "ambang" && (
          <>
            <Panel title="Ambang Batas Tinggi Air (cm)">
              <div className="grid grid-cols-1 gap-4 md:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
                <div className="flex flex-col gap-3">
                  {LEVELS.map((l) => (
                    <div key={l.key}>
                      <div className="flex items-center gap-2">
                        <span className="h-3 w-3 shrink-0 rounded-full" style={{ background: l.color }} />
                        <span className="w-16 text-xs font-semibold">{l.label}</span>
                        <Controller
                          name={l.key}
                          control={control}
                          render={({ field }) => (
                            <InputNumber
                              className="flex-1"
                              min={0}
                              value={field.value}
                              disabled={disabled}
                              status={issueOf(l.key) ? "error" : undefined}
                              onChange={field.onChange}
                              addonAfter="cm"
                              aria-label={`Ambang ${l.label}`}
                            />
                          )}
                        />
                      </div>
                      <div className="pl-[88px]">{err(issueOf(l.key))}</div>
                    </div>
                  ))}
                </div>
                <div>
                  <p className="m-0 mb-1 text-xs font-semibold text-slate-700">Pratinjau Skala</p>
                  <ScalePreview waspada={w ?? 0} siaga={s ?? 0} bahaya={b ?? 0} />
                </div>
              </div>
            </Panel>

            <Panel title="Aturan Tambahan">
              <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
                {RULES.map((r) => (
                  <div key={r.key} className="rounded-md border border-slate-200 bg-slate-50 p-3">
                    <p className="m-0 text-xs font-semibold">{r.title}</p>
                    <p className="m-0 mb-2 text-[11px] text-slate-500">{r.hint}</p>
                    <Controller
                      name={r.key}
                      control={control}
                      render={({ field }) => (
                        <InputNumber
                          className="w-full"
                          min={0}
                          value={field.value}
                          disabled={disabled}
                          status={issueOf(r.key) ? "error" : undefined}
                          onChange={field.onChange}
                          addonAfter={r.unit}
                          aria-label={r.title}
                        />
                      )}
                    />
                    {err(issueOf(r.key))}
                  </div>
                ))}
              </div>
            </Panel>
          </>
        )}

        {tab === "aturan" && (
          <Panel title="Penerima & Saluran Notifikasi per Level Alert">
            <AlertMatrix control={control} disabled={disabled} />
          </Panel>
        )}

        <section className="flex flex-wrap items-center gap-3 rounded-lg border border-slate-200 bg-white p-3 shadow-sm">
          <Button type="primary" loading={saving} disabled={!canSave} onClick={() => void handleSubmit((v) => onSave(toPayload(v)))()}>
            Simpan Pengaturan
          </Button>
          <Button disabled={!isDirty} onClick={() => reset(toFormValues(config))}>
            Reset
          </Button>
          <span className="text-[11px] text-slate-500">
            Terakhir disimpan: {formatDateTime(config.updatedAt)} oleh {config.updatedBy}
          </span>
        </section>
      </div>

      <div className="flex min-w-0 flex-col gap-3">
        {messages.length > 0 && <ValidationBox messages={messages} />}
        <ConfigSummary
          sensorLabel={`${sensor.location} (${sensor.code})`}
          templateName={templateName}
          waspada={w}
          siaga={s}
          bahaya={b}
          rainfall={num(values.rainfall)}
          offlineMinutes={num(values.offlineMinutes)}
          battery={num(values.batteryPercent)}
        />
        {values.matrix?.BAHAYA && (
          <NotificationPreview
            location={sensor.location}
            value={(b ?? config.thresholds.bahaya) + 5}
            target={{ ...config.matrix.BAHAYA, ...values.matrix.BAHAYA } as typeof config.matrix.BAHAYA}
          />
        )}
        {savedNotice && (
          <div className="flex items-start gap-2 rounded-lg border border-green-200 bg-green-50 p-3 text-xs" role="status">
            <CheckCircleFilled className="mt-0.5 text-lg text-green-600" />
            <div className="flex-1">
              <p className="m-0 font-semibold text-green-700">Pengaturan berhasil disimpan</p>
              <p className="m-0 text-slate-600">Ambang batas dan aturan alert telah diperbarui.</p>
            </div>
            <button type="button" aria-label="Tutup" onClick={onDismissNotice} className="cursor-pointer border-none bg-transparent p-0 text-slate-400">
              ×
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default AmbangEditor;
