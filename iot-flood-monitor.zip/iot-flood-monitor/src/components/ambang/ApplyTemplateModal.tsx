import { useState } from "react";
import { Button, Modal, Select } from "antd";
import type { ISensor } from "@/types/sensor";
import type { IThresholds } from "@/utils/thresholds";

interface IBodyProps {
  thresholds: IThresholds;
  sensors: ISensor[];
  currentId: number;
  loading: boolean;
  onApply: (ids: number[]) => void;
  onClose: () => void;
}

const Body = ({ thresholds, sensors, currentId, loading, onApply, onClose }: IBodyProps) => {
  const [ids, setIds] = useState<number[]>([]);
  const targets = sensors.filter((s) => s.id !== currentId);

  return (
    <div className="flex flex-col gap-3 text-xs">
      <p className="m-0 rounded bg-slate-50 p-2 text-slate-600">
        Ambang yang akan diterapkan: Waspada <b>{thresholds.waspada}</b> · Siaga <b>{thresholds.siaga}</b> · Bahaya{" "}
        <b>{thresholds.bahaya}</b> cm. Aturan tambahan dan penerima tiap sensor tidak berubah.
      </p>
      <Select
        mode="multiple"
        className="w-full"
        placeholder="Pilih sensor tujuan"
        optionFilterProp="label"
        maxTagCount="responsive"
        value={ids}
        onChange={setIds}
        options={targets.map((s) => ({ value: s.id, label: `${s.code} - ${s.location}` }))}
      />
      <div className="flex items-center justify-between">
        <Button size="small" type="link" onClick={() => setIds(ids.length === targets.length ? [] : targets.map((s) => s.id))}>
          {ids.length === targets.length ? "Kosongkan pilihan" : "Pilih semua sensor"}
        </Button>
        <span className="text-slate-500">{ids.length} sensor dipilih</span>
      </div>
      <div className="flex justify-end gap-2">
        <Button onClick={onClose}>Batal</Button>
        <Button type="primary" disabled={ids.length === 0} loading={loading} onClick={() => onApply(ids)}>
          Terapkan
        </Button>
      </div>
    </div>
  );
};

interface IApplyTemplateModalProps {
  thresholds: IThresholds | null;
  sensors: ISensor[];
  currentId: number;
  loading: boolean;
  onApply: (ids: number[]) => void;
  onClose: () => void;
}

const ApplyTemplateModal = ({ thresholds, sensors, currentId, loading, onApply, onClose }: IApplyTemplateModalProps) => (
  <Modal open={thresholds !== null} title="Terapkan Template ke Banyak Sensor" footer={null} onCancel={onClose} width={520}>
    {thresholds && (
      <Body thresholds={thresholds} sensors={sensors} currentId={currentId} loading={loading} onApply={onApply} onClose={onClose} />
    )}
  </Modal>
);

export default ApplyTemplateModal;
