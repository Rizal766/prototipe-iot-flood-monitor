import { Controller, type Control } from "react-hook-form";
import { Switch } from "antd";
import {
  ALERT_TIERS,
  CHANNEL_TEXT,
  NOTIFY_CHANNELS,
  NOTIFY_ROLES,
  ROLE_TEXT,
  type AlertTier,
  type NotifyChannel,
  type NotifyRole,
} from "@/types/alertConfig";
import type { AlertFormValues } from "@/schemas/alertConfigSchema";

const TIER_META: Record<AlertTier, { label: string; color: string }> = {
  WASPADA: { label: "Waspada", color: "#eab308" },
  SIAGA: { label: "Siaga", color: "#f97316" },
  BAHAYA: { label: "Bahaya", color: "#ef4444" },
};

interface IAlertMatrixProps {
  control: Control<AlertFormValues>;
  disabled: boolean;
}

const th = "px-2 py-2 text-center text-xs font-semibold text-slate-700";

const AlertMatrix = ({ control, disabled }: IAlertMatrixProps) => (
  <div className="overflow-x-auto">
    <table className="w-full min-w-[640px] border-collapse text-xs">
      <thead>
        <tr className="border-b border-slate-200">
          <th rowSpan={2} className={`${th} text-left`}>
            Level Alert
          </th>
          <th colSpan={NOTIFY_ROLES.length} className={`${th} border-l border-slate-200`}>
            Role / Grup
          </th>
          <th colSpan={NOTIFY_CHANNELS.length} className={`${th} border-l border-slate-200`}>
            Saluran Notifikasi
          </th>
        </tr>
        <tr className="border-b border-slate-200 text-slate-600">
          {NOTIFY_ROLES.map((r, i) => (
            <th key={r} className={`${th} font-medium ${i === 0 ? "border-l border-slate-200" : ""}`}>
              {ROLE_TEXT[r]}
            </th>
          ))}
          {NOTIFY_CHANNELS.map((c, i) => (
            <th key={c} className={`${th} font-medium ${i === 0 ? "border-l border-slate-200" : ""}`}>
              {CHANNEL_TEXT[c]}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {ALERT_TIERS.map((tier) => (
          <tr key={tier} className="border-b border-slate-100">
            <td className="px-2 py-3 font-medium">
              <span className="mr-2 inline-block h-2.5 w-2.5 rounded-full" style={{ background: TIER_META[tier].color }} />
              {TIER_META[tier].label}
            </td>
            {([...NOTIFY_ROLES, ...NOTIFY_CHANNELS] as (NotifyRole | NotifyChannel)[]).map((key, i) => (
              <td key={key} className={`px-2 py-3 text-center ${i === 0 || i === NOTIFY_ROLES.length ? "border-l border-slate-100" : ""}`}>
                <Controller
                  name={`matrix.${tier}.${key}` as const}
                  control={control}
                  render={({ field }) => (
                    <Switch
                      size="small"
                      checked={field.value}
                      disabled={disabled}
                      onChange={field.onChange}
                      aria-label={`${TIER_META[tier].label} - ${key in ROLE_TEXT ? ROLE_TEXT[key as NotifyRole] : CHANNEL_TEXT[key as NotifyChannel]}`}
                    />
                  )}
                />
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);

export default AlertMatrix;
