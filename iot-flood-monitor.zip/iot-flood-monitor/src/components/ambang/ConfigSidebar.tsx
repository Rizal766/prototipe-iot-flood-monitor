import { CloudOutlined, DashboardOutlined, EnvironmentOutlined, DisconnectOutlined, ThunderboltOutlined, WarningFilled } from "@ant-design/icons";
import Panel from "@/components/dashboard/Panel";
import {
  CHANNEL_TEXT,
  NOTIFY_CHANNELS,
  NOTIFY_ROLES,
  ROLE_TEXT,
  type IAlertTarget,
} from "@/types/alertConfig";
import { formatDateTime } from "@/utils/time";

interface IValidationBoxProps {
  messages: string[];
}

export const ValidationBox = ({ messages }: IValidationBoxProps) => (
  <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-xs" role="alert">
    <p className="m-0 mb-1 flex items-center gap-1.5 text-sm font-bold text-red-600">
      <WarningFilled /> Validasi Data
    </p>
    <ul className="m-0 list-none p-0 text-red-700">
      {messages.map((m) => (
        <li key={m}>{m}</li>
      ))}
    </ul>
  </div>
);

interface ISummaryProps {
  sensorLabel: string;
  templateName: string;
  waspada: number | null;
  siaga: number | null;
  bahaya: number | null;
  rainfall: number | null;
  offlineMinutes: number | null;
  battery: number | null;
}

const fmt = (v: number | null, unit = "") => (v === null || Number.isNaN(v) ? "-" : `${v}${unit}`);

export const ConfigSummary = (p: ISummaryProps) => {
  const rows = [
    { icon: <EnvironmentOutlined />, title: "Sensor / Lokasi", value: p.sensorLabel },
    { icon: <DashboardOutlined />, title: "Template Ambang", value: p.templateName },
    {
      icon: <ThunderboltOutlined />,
      title: "Tinggi Air (cm)",
      value: `Waspada: ${fmt(p.waspada)} · Siaga: ${fmt(p.siaga)} · Bahaya: ${fmt(p.bahaya)}`,
    },
    { icon: <CloudOutlined />, title: "Curah Hujan", value: fmt(p.rainfall, " mm/jam") },
    { icon: <DisconnectOutlined />, title: "Sensor Offline", value: fmt(p.offlineMinutes, " menit") },
    { icon: <ThunderboltOutlined />, title: "Baterai Lemah", value: fmt(p.battery, " %") },
  ];
  return (
    <Panel title="Ringkasan Konfigurasi">
      <ul className="m-0 flex list-none flex-col gap-2.5 p-0">
        {rows.map((r) => (
          <li key={r.title} className="flex items-start gap-2.5 text-xs">
            <span className="mt-0.5 text-lg text-slate-500">{r.icon}</span>
            <span className="min-w-0">
              <span className="block font-semibold text-slate-800">{r.title}</span>
              <span className="block break-words text-slate-500">{r.value}</span>
            </span>
          </li>
        ))}
      </ul>
    </Panel>
  );
};

interface INotifPreviewProps {
  location: string;
  value: number;
  target: IAlertTarget;
}

export const NotificationPreview = ({ location, value, target }: INotifPreviewProps) => {
  const roles = NOTIFY_ROLES.filter((r) => target[r]);
  const channels = NOTIFY_CHANNELS.filter((c) => target[c]);
  const chip = "rounded border border-slate-200 bg-slate-50 px-2 py-0.5 text-[11px] text-slate-700";
  return (
    <Panel title="Preview Notifikasi">
      <div className="rounded-md border border-red-200 bg-red-50 p-3 text-xs">
        <p className="m-0 font-bold text-red-600">Alert Bahaya – Tinggi Air</p>
        <p className="m-0 text-slate-700">Tinggi air mencapai {value} cm di {location}.</p>
        <p className="m-0 text-slate-500">{formatDateTime(new Date().toISOString())}</p>
      </div>
      <p className="m-0 mb-1 mt-3 text-xs font-semibold">Penerima</p>
      <div className="flex flex-wrap gap-1.5">
        {roles.length === 0 ? <span className="text-[11px] text-slate-400">Belum ada penerima</span> : roles.map((r) => <span key={r} className={chip}>{ROLE_TEXT[r]}</span>)}
      </div>
      <p className="m-0 mb-1 mt-3 text-xs font-semibold">Saluran</p>
      <div className="flex flex-wrap gap-1.5">
        {channels.length === 0 ? <span className="text-[11px] text-slate-400">Belum ada saluran</span> : channels.map((c) => <span key={c} className={chip}>{CHANNEL_TEXT[c]}</span>)}
      </div>
    </Panel>
  );
};
