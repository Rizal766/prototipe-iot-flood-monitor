interface IScalePreviewProps {
  waspada: number;
  siaga: number;
  bahaya: number;
}

const W = 300;
const H = 200;
const TOP = 10;
const BAR_X = 52;
const BAR_W = 76;

// Skala vertikal: air (biru) naik melewati batas waspada, siaga, dan bahaya
const ScalePreview = ({ waspada: w, siaga: s, bahaya: b }: IScalePreviewProps) => {
  const valid = w > 0 && s > w && b > s;
  const base = valid ? b : Math.max(w, s, b, 50);
  const max = Math.max(20, Math.ceil((base * 1.4) / 20) * 20);
  const y = (v: number) => TOP + H - (Math.min(Math.max(v, 0), max) / max) * H;

  const bands = valid
    ? [
        { from: 0, to: w, color: "#3b82f6" },
        { from: w, to: s, color: "#eab308" },
        { from: s, to: b, color: "#f97316" },
        { from: b, to: max, color: "#ef4444" },
      ]
    : [{ from: 0, to: max, color: "#cbd5e1" }];

  const labels = valid
    ? [
        { mid: (b + max) / 2, text: `Bahaya (≥${b})`, color: "#dc2626" },
        { mid: (s + b) / 2, text: `Siaga (${s}-${b - 1})`, color: "#ea580c" },
        { mid: (w + s) / 2, text: `Waspada (${w}-${s - 1})`, color: "#ca8a04" },
      ]
    : [];

  const ticks = [0, 1, 2, 3, 4].map((i) => Math.round((max / 4) * i));

  return (
    <svg viewBox={`0 0 ${W} ${H + TOP + 8}`} className="w-full max-w-[320px]" role="img" aria-label="Pratinjau skala ambang batas">
      {bands.map((band) => (
        <rect key={band.color + band.from} x={BAR_X} y={y(band.to)} width={BAR_W} height={Math.max(0, y(band.from) - y(band.to))} fill={band.color} />
      ))}
      {ticks.map((t) => (
        <g key={t}>
          <line x1={BAR_X - 4} x2={BAR_X} y1={y(t)} y2={y(t)} stroke="#94a3b8" />
          <text x={BAR_X - 7} y={y(t) + 3} textAnchor="end" fontSize="9" fill="#64748b">
            {t}
          </text>
        </g>
      ))}
      {labels.map((l) => (
        <g key={l.text}>
          <line x1={BAR_X + BAR_W + 4} x2={BAR_X + BAR_W + 22} y1={y(l.mid)} y2={y(l.mid)} stroke={l.color} />
          <text x={BAR_X + BAR_W + 26} y={y(l.mid) + 3} fontSize="10" fontWeight="600" fill={l.color}>
            {l.text}
          </text>
        </g>
      ))}
      {!valid && (
        <text x={BAR_X + BAR_W + 8} y={TOP + H / 2} fontSize="10" fill="#94a3b8">
          Nilai belum valid
        </text>
      )}
    </svg>
  );
};

export default ScalePreview;
