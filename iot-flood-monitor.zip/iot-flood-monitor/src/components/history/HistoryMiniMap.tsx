import { Button } from "antd";
import { EnvironmentFilled } from "@ant-design/icons";
import { useNavigate } from "react-router-dom";
import Panel from "@/components/dashboard/Panel";
import SensorMap from "@/components/map/SensorMap";
import { useSensorStore } from "@/stores/useSensorStore";
import type { ISensor } from "@/types/sensor";

const HistoryMiniMap = ({ sensors }: { sensors: ISensor[] }) => {
  const navigate = useNavigate();
  const selectSensor = useSensorStore((s) => s.selectSensor);

  return (
    <Panel title="Peta Lokasi Sensor" className="h-full">
      <div className="relative isolate h-[230px] overflow-hidden rounded-md border border-slate-200 bg-slate-200">
        <div className="absolute inset-0">
          <SensorMap sensors={sensors} selectedId={sensors[0]?.id ?? null} onSelect={selectSensor} fitToSensors />
        </div>
      </div>
      <Button type="primary" block icon={<EnvironmentFilled />} className="mt-2" onClick={() => navigate("/peta")}>
        Lihat di Peta
      </Button>
    </Panel>
  );
};

export default HistoryMiniMap;
