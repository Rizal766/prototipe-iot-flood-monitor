import { Button, Progress } from "antd";
import { CheckCircleFilled, CloseOutlined, FileTextOutlined } from "@ant-design/icons";
import Panel from "@/components/dashboard/Panel";
import type { IExportState } from "@/hooks/useCsvExport";
import { formatBytes } from "@/utils/time";

interface IExportCardProps {
  state: IExportState;
  onReopen: () => void;
  onDismiss: () => void;
}

const ExportCard = ({ state, onReopen, onDismiss }: IExportCardProps) => (
  <div className="flex h-full min-w-0 flex-col gap-3">
    <Panel title="Ekspor File">
      <div className="flex items-center gap-3">
        <FileTextOutlined className="text-3xl text-slate-700" />
        <div className="min-w-0 flex-1">
          <Progress percent={state.progress} size="small" status={state.status === "running" ? "active" : "normal"} />
          <p className="m-0 text-[11px] text-slate-500">
            {state.status === "idle" && "Belum ada ekspor. Klik Export Data."}
            {state.status === "running" && "Menyiapkan file…"}
            {state.status === "done" && state.fileName}
          </p>
        </div>
      </div>
    </Panel>

    {state.status === "done" && (
      <div className="relative rounded-lg border border-green-200 bg-green-50 p-3 text-xs" role="status">
        <button type="button" aria-label="Tutup" onClick={onDismiss} className="absolute right-2 top-2 cursor-pointer border-none bg-transparent p-0 text-slate-400">
          <CloseOutlined />
        </button>
        <p className="m-0 flex items-center gap-1.5 font-semibold text-green-700">
          <CheckCircleFilled /> Ekspor Selesai
        </p>
        <p className="m-0 mb-2 text-slate-600">File berhasil diunduh ({formatBytes(state.size)})</p>
        <Button size="small" type="primary" block onClick={onReopen}>
          Buka File
        </Button>
      </div>
    )}
  </div>
);

export default ExportCard;
