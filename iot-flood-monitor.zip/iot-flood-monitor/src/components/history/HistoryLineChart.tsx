import { useState, type MouseEvent } from "react";
import { formatDateTime } from "@/utils/time";

export interface ILineSeries {
  code: string;
  color: string;
  values: number[];
  siaga?: number; // ambang siaga sensor (cm)
}

export interface IThresholdLine {
  label: string;
  value: number;
  color: string;
}

interface IHistoryLineChartProps {
  times: string[];
  series: ILineSeries[];
  unit: string;
  height?: number;
  thresholds?: IThresholdLine[]; // garis ambang (cm)
  area?: boolean; // isi area di bawah seri pertama
}

const W = 640;
const PAD = { left: 38, right: 12, top: 10, bottom: 24 };

const HistoryLineChart = ({ times, series, unit, height = 210, thresholds, area }: IHistoryLineChartProps) => {
  const [hover, setHover] = useState<number | null>(null);
  const n = times.length;
  if (n < 2 || series.length === 0) {
    return <p className="m-0 py-10 text-center text-xs text-slate-400">Belum ada data pada rentang ini</p>;
  }

  const plotW = W - PAD.left - PAD.right;
  const plotH = height - PAD.top - PAD.bottom;
  const dataMax = Math.max(...series.flatMap((s) => s.values));
  const thresholdMax = thresholds ? Math.max(0, ...thresholds.map((t) => t.value)) : 0;
  const max = Math.max(50, Math.ceil(Math.max(dataMax, thresholdMax * 1.05) / 50) * 50);
  const ticks = [0, 1, 2, 3, 4].map((i) => (max / 4) * i);
  const x = (i: number) => PAD.left + (i / (n - 1)) * plotW;
  const y = (v: number) => PAD.top + plotH - (v / max) * plotH;

  const spanDays = (new Date(times[n - 1]).getTime() - new Date(times[0]).getTime()) / 86400000;
  const label = (iso: string) => {
    const d = new Date(iso);
    return spanDays <= 2
      ? d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", hour12: false }).replace(".", ":")
      : d.toLocaleDateString("id-ID", { day: "numeric", month: "short" });
  };
  const xTicks = [...new Set(Array.from({ length: 8 }, (_, k) => Math.round((k * (n - 1)) / 7)))];

  const onMove = (e: MouseEvent<SVGSVGElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const px = ((e.clientX - rect.left) / rect.width) * W;
    const idx = Math.round(((px - PAD.left) / plotW) * (n - 1));
    setHover(Math.min(n - 1, Math.max(0, idx)));
  };

  return (
    <div className="relative">
      <ul className="m-0 mb-1 flex list-none flex-wrap justify-end gap-x-3 p-0 text-[11px] text-slate-600">
        {series.map((s) => (
          <li key={s.code} className="flex items-center gap-1">
            <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ background: s.color }} />
            {s.code}
          </li>
        ))}
      </ul>

      <svg
        viewBox={`0 0 ${W} ${height}`}
        className="w-full"
        role="img"
        aria-label="Grafik perbandingan tinggi air"
        onMouseMove={onMove}
        onMouseLeave={() => setHover(null)}
      >
        {ticks.map((t) => (
          <g key={t}>
            <line x1={PAD.left} x2={W - PAD.right} y1={y(t)} y2={y(t)} stroke="#e2e8f0" />
            <text x={PAD.left - 6} y={y(t) + 3} textAnchor="end" fontSize="9" fill="#64748b">
              {Math.round(t)}
            </text>
          </g>
        ))}
        {xTicks.map((i) => (
          <text key={i} x={x(i)} y={height - 8} textAnchor="middle" fontSize="9" fill="#64748b">
            {label(times[i])}
          </text>
        ))}
        {area && series[0] && (
          <polygon
            points={`${x(0)},${y(0)} ${series[0].values.map((v, i) => `${x(i)},${y(v)}`).join(" ")} ${x(n - 1)},${y(0)}`}
            fill={series[0].color}
            opacity="0.15"
          />
        )}
        {(thresholds ?? []).map((t) => (
          <g key={t.label}>
            <line x1={PAD.left} x2={W - PAD.right} y1={y(t.value)} y2={y(t.value)} stroke={t.color} strokeDasharray="4 3" />
            <text x={W - PAD.right - 2} y={y(t.value) - 2} textAnchor="end" fontSize="8" fill={t.color}>
              {t.label}
            </text>
          </g>
        ))}
        {series.map((s) => (
          <polyline
            key={s.code}
            fill="none"
            stroke={s.color}
            strokeWidth="1.6"
            strokeLinejoin="round"
            points={s.values.map((v, i) => `${x(i)},${y(v)}`).join(" ")}
          />
        ))}
        {hover !== null && (
          <g>
            <line x1={x(hover)} x2={x(hover)} y1={PAD.top} y2={PAD.top + plotH} stroke="#94a3b8" strokeDasharray="3 3" />
            {series.map((s) => (
              <circle key={s.code} cx={x(hover)} cy={y(s.values[hover])} r="3.5" fill={s.color} stroke="#fff" strokeWidth="1.5" />
            ))}
          </g>
        )}
      </svg>

      {hover !== null && (
        <div
          className="pointer-events-none absolute top-6 z-10 rounded-md border border-slate-200 bg-white/95 p-2 text-[11px] shadow-md"
          style={{
            left: `${(x(hover) / W) * 100}%`,
            transform: hover > n / 2 ? "translateX(calc(-100% - 10px))" : "translateX(10px)",
          }}
        >
          <p className="m-0 mb-1 font-semibold">{formatDateTime(times[hover])}</p>
          {series.map((s) => (
            <p key={s.code} className="m-0 flex items-center gap-1.5">
              <span className="inline-block h-2 w-2 rounded-full" style={{ background: s.color }} />
              {s.code} <b>{s.values[hover]} {unit}</b>
            </p>
          ))}
        </div>
      )}
    </div>
  );
};

export default HistoryLineChart;
