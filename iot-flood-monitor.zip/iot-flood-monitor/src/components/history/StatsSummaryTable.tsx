import type { ILineSeries } from "./HistoryLineChart";
import { WATER_THRESHOLDS } from "@/utils/thresholds";

const hoursColor = (h: number): string =>
  h >= 10 ? "#ef4444" : h >= 4 ? "#f97316" : h > 0 ? "#eab308" : "#16a34a";

interface IStatsSummaryTableProps {
  series: ILineSeries[];
  intervalHours: number;
}

const StatsSummaryTable = ({ series, intervalHours }: IStatsSummaryTableProps) => (
  <div className="overflow-x-auto">
    <table className="w-full text-[11px]">
      <thead>
        <tr className="text-left text-slate-500">
          <th className="py-1 pr-2 font-medium">ID Sensor</th>
          <th className="py-1 pr-2 text-right font-medium">Tertinggi</th>
          <th className="py-1 pr-2 text-right font-medium">Terendah</th>
          <th className="py-1 pr-2 text-right font-medium">Rata-rata</th>
          <th className="py-1 text-right font-medium">Siaga</th>
        </tr>
      </thead>
      <tbody>
        {series.map((s) => {
          const max = Math.max(...s.values);
          const min = Math.min(...s.values);
          const avg = Math.round(s.values.reduce((a, v) => a + v, 0) / s.values.length);
          const hours = s.values.filter((v) => v >= (s.siaga ?? WATER_THRESHOLDS.siaga)).length * intervalHours;
          return (
            <tr key={s.code} className="border-t border-slate-100">
              <td className="py-1.5 pr-2">
                <span className="mr-1.5 inline-block h-2.5 w-2.5 rounded-full align-middle" style={{ background: s.color }} />
                {s.code}
              </td>
              <td className="py-1.5 pr-2 text-right">{max} cm</td>
              <td className="py-1.5 pr-2 text-right">{min} cm</td>
              <td className="py-1.5 pr-2 text-right">{avg} cm</td>
              <td className="py-1.5 text-right font-semibold" style={{ color: hoursColor(hours) }}>
                {hours} jam
              </td>
            </tr>
          );
        })}
        {series.length === 0 && (
          <tr>
            <td colSpan={5} className="py-4 text-center text-slate-400">Belum ada data</td>
          </tr>
        )}
      </tbody>
    </table>
    <p className="m-0 mt-1 text-[10px] text-slate-400">Siaga = durasi tinggi air di atas ambang siaga masing-masing sensor</p>
  </div>
);

export default StatsSummaryTable;
