import { useMemo, useState } from "react";
import { DataGrid, type GridColDef, type GridPaginationModel, type GridRowSelectionModel } from "@mui/x-data-grid";
import { Button, Checkbox, Pagination, Select } from "antd";
import Panel from "@/components/dashboard/Panel";
import StatusBadge from "@/components/StatusBadge";
import type { IHistoryRow } from "@/types/history";
import { STATUS_META } from "@/utils/status";
import { formatDateTime } from "@/utils/time";
import type { IDataTypes } from "./HistoryFilters";

const PAGE_SIZES = [10, 25, 50];

interface IHistoryTableProps {
  rows: IHistoryRow[];
  loading: boolean;
  types: IDataTypes;
  onExport: (rows: IHistoryRow[]) => void;
}

const HistoryTable = ({ rows, loading, types, onExport }: IHistoryTableProps) => {
  const [selection, setSelection] = useState<GridRowSelectionModel>([]);
  const [paging, setPaging] = useState<GridPaginationModel>({ page: 0, pageSize: 10 });

  const columns = useMemo<GridColDef<IHistoryRow>[]>(() => {
    const cols: GridColDef<IHistoryRow>[] = [
      { field: "t", headerName: "Waktu", width: 150, valueFormatter: (v: string) => formatDateTime(v) },
      {
        field: "code",
        headerName: "ID Sensor",
        width: 100,
        renderCell: (p) => (
          <span>
            <span className="mr-1.5 inline-block h-2.5 w-2.5 rounded-full" style={{ background: STATUS_META[p.row.status].color }} />
            {p.row.code}
          </span>
        ),
      },
      {
        field: "location",
        headerName: "Nama Lokasi",
        flex: 1,
        minWidth: 170,
        renderCell: (p) => (
          <div className="leading-tight">
            <div>{p.row.location}</div>
            <div className="text-[11px] text-slate-500">Kec. {p.row.district}</div>
          </div>
        ),
      },
      { field: "river", headerName: "Sungai", width: 140 },
    ];
    if (types.water) cols.push({ field: "waterLevel", headerName: "Tinggi Air (cm)", type: "number", width: 130, align: "left", headerAlign: "left" });
    if (types.rain) cols.push({ field: "rainfall", headerName: "Curah Hujan (mm)", type: "number", width: 140, align: "left", headerAlign: "left" });
    cols.push({ field: "status", headerName: "Status", width: 120, renderCell: (p) => <StatusBadge status={p.row.status} /> });
    return cols;
  }, [types]);

  const selected = rows.filter((r) => selection.includes(r.id));
  const allSelected = rows.length > 0 && selected.length === rows.length;
  const start = rows.length === 0 ? 0 : paging.page * paging.pageSize + 1;
  const end = Math.min((paging.page + 1) * paging.pageSize, rows.length);

  return (
    <Panel
      title="Data Historis"
      className="h-full"
      actions={
        <span className="flex flex-wrap items-center gap-3 text-xs">
          <Checkbox
            checked={allSelected}
            indeterminate={selected.length > 0 && !allSelected}
            onChange={() => setSelection(allSelected ? [] : rows.map((r) => r.id))}
          >
            Pilih Semua ({selected.length})
          </Checkbox>
          <Button size="small" type="primary" onClick={() => onExport(selected.length > 0 ? selected : rows)}>
            Ekspor CSV
          </Button>
        </span>
      }
    >
      <DataGrid
        rows={rows}
        columns={columns}
        loading={loading}
        autoHeight
        rowHeight={48}
        columnHeaderHeight={42}
        hideFooter
        checkboxSelection
        disableRowSelectionOnClick
        disableColumnMenu
        rowSelectionModel={selection}
        onRowSelectionModelChange={setSelection}
        paginationModel={paging}
        onPaginationModelChange={setPaging}
        pageSizeOptions={PAGE_SIZES}
        sx={{ border: 0, fontSize: 12, "& .MuiDataGrid-columnHeaders": { backgroundColor: "#f8fafc" } }}
      />
      <div className="mt-2 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-2 text-xs text-slate-600">
        <span className="flex items-center gap-2">
          Tampilkan
          <Select
            size="small"
            value={paging.pageSize}
            onChange={(v) => setPaging({ page: 0, pageSize: v })}
            options={PAGE_SIZES.map((n) => ({ value: n, label: n }))}
          />
          data per halaman
        </span>
        <Pagination
          size="small"
          current={paging.page + 1}
          pageSize={paging.pageSize}
          total={rows.length}
          showSizeChanger={false}
          onChange={(p) => setPaging((s) => ({ ...s, page: p - 1 }))}
        />
        <span>
          Menampilkan {start} - {end} dari {rows.length} data
        </span>
      </div>
    </Panel>
  );
};

export default HistoryTable;
