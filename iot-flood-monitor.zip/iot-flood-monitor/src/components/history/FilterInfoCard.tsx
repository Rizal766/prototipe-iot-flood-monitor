import { BarChartOutlined, CalendarOutlined, ClockCircleOutlined, WifiOutlined } from "@ant-design/icons";
import Panel from "@/components/dashboard/Panel";
import { INTERVAL_LABEL, type HistoryInterval } from "@/types/history";
import type { IRange } from "@/utils/historyRange";
import type { IDataTypes } from "./HistoryFilters";

const fmt = (iso: string) =>
  new Date(iso).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" });

interface IFilterInfoCardProps {
  range: IRange;
  sensorCount: number;
  types: IDataTypes;
  interval: HistoryInterval;
}

const FilterInfoCard = ({ range, sensorCount, types, interval }: IFilterInfoCardProps) => {
  const typeText = [types.water && "Tinggi Air", types.rain && "Curah Hujan"].filter(Boolean).join(", ");
  const items = [
    { icon: <CalendarOutlined />, text: `${fmt(range.from)} – ${fmt(range.to)}` },
    { icon: <WifiOutlined />, text: `${sensorCount} sensor dipilih` },
    { icon: <BarChartOutlined />, text: typeText },
    { icon: <ClockCircleOutlined />, text: INTERVAL_LABEL[interval] },
  ];
  return (
    <Panel title="Informasi Filter Aktif" className="h-full">
      <ul className="m-0 flex list-none flex-col gap-2.5 p-0">
        {items.map((i) => (
          <li key={i.text} className="flex items-center gap-2.5 text-xs text-slate-700">
            <span className="text-lg text-slate-500">{i.icon}</span>
            {i.text}
          </li>
        ))}
      </ul>
    </Panel>
  );
};

export default FilterInfoCard;
