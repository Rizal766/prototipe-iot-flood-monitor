import { formatDateTime } from "@/utils/time";

interface IRainBarChartProps {
  times: string[];
  values: number[];
  height?: number;
}

const W = 520;
const PAD = { left: 34, right: 8, top: 8, bottom: 22 };

const RainBarChart = ({ times, values, height = 170 }: IRainBarChartProps) => {
  const n = values.length;
  if (n === 0) return <p className="m-0 py-10 text-center text-xs text-slate-400">Belum ada data pada rentang ini</p>;

  const plotW = W - PAD.left - PAD.right;
  const plotH = height - PAD.top - PAD.bottom;
  const max = Math.max(10, Math.ceil(Math.max(...values) / 10) * 10);
  const ticks = [0, 1, 2, 3, 4].map((i) => (max / 4) * i);
  const slot = plotW / n;
  const barW = Math.max(1, slot * 0.7);
  const y = (v: number) => PAD.top + plotH - (v / max) * plotH;
  const xTicks = [...new Set(Array.from({ length: 7 }, (_, k) => Math.round((k * (n - 1)) / 6)))];

  return (
    <svg viewBox={`0 0 ${W} ${height}`} className="w-full" role="img" aria-label="Grafik curah hujan">
      {ticks.map((t) => (
        <g key={t}>
          <line x1={PAD.left} x2={W - PAD.right} y1={y(t)} y2={y(t)} stroke="#e2e8f0" />
          <text x={PAD.left - 5} y={y(t) + 3} textAnchor="end" fontSize="9" fill="#64748b">
            {Math.round(t)}
          </text>
        </g>
      ))}
      {values.map((v, i) => (
        <rect key={times[i]} x={PAD.left + i * slot + (slot - barW) / 2} y={y(v)} width={barW} height={Math.max(0, PAD.top + plotH - y(v))} fill="#3b82f6" rx="0.5">
          <title>{`${formatDateTime(times[i])}: ${v} mm`}</title>
        </rect>
      ))}
      {xTicks.map((i) => (
        <text key={i} x={PAD.left + i * slot + slot / 2} y={height - 6} textAnchor="middle" fontSize="9" fill="#64748b">
          {new Date(times[i]).toLocaleDateString("id-ID", { day: "numeric", month: "short" })}
        </text>
      ))}
    </svg>
  );
};

export default RainBarChart;
