import { Button, Checkbox, DatePicker, Radio, Select } from "antd";
import { DownloadOutlined } from "@ant-design/icons";
import dayjs, { type Dayjs } from "dayjs";
import { HistoryInterval, INTERVAL_LABEL } from "@/types/history";
import type { ISensor } from "@/types/sensor";
import type { RangeKey } from "@/utils/historyRange";

export const MAX_SENSORS = 5;

export interface IDataTypes {
  water: boolean;
  rain: boolean;
}

const PRESETS: { key: RangeKey; label: string }[] = [
  { key: "today", label: "Hari ini" },
  { key: "7d", label: "7 Hari" },
  { key: "30d", label: "30 Hari" },
  { key: "custom", label: "Kustom" },
];

// Kolom filter: pemisah vertikal hanya pada layar lebar
const CELL = "min-w-0 xl:border-l xl:border-slate-200 xl:px-4 xl:first:border-l-0 xl:first:pl-0";
const LABEL = "m-0 mb-2 text-xs font-semibold text-slate-700";

interface IHistoryFiltersProps {
  rangeKey: RangeKey;
  sensors: ISensor[];
  ids: number[];
  types: IDataTypes;
  interval: HistoryInterval;
  exporting: boolean;
  onPreset: (key: RangeKey) => void;
  onCustom: (from: Dayjs, to: Dayjs) => void;
  onIds: (ids: number[]) => void;
  onTypes: (t: IDataTypes) => void;
  onInterval: (i: HistoryInterval) => void;
  onExport: () => void;
}

const HistoryFilters = ({
  rangeKey,
  sensors,
  ids,
  types,
  interval,
  exporting,
  onPreset,
  onCustom,
  onIds,
  onTypes,
  onInterval,
  onExport,
}: IHistoryFiltersProps) => {
  const codes = sensors.filter((s) => ids.includes(s.id)).map((s) => s.code);

  return (
    <section className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-[minmax(0,1.25fr)_minmax(0,1.25fr)_minmax(0,0.8fr)_minmax(0,0.8fr)_auto] xl:gap-0">
        <div className={CELL}>
          <h3 className={LABEL}>Rentang tanggal</h3>
          <div className="flex flex-wrap gap-1.5">
            {PRESETS.map((p) => (
              <Button key={p.key} type={rangeKey === p.key ? "primary" : "default"} onClick={() => onPreset(p.key)}>
                {p.label}
              </Button>
            ))}
          </div>
          {rangeKey === "custom" && (
            <DatePicker.RangePicker
              className="mt-2 w-full"
              disabledDate={(d) => d.isAfter(dayjs(), "day")}
              onChange={(v) => {
                if (v && v[0] && v[1]) onCustom(v[0], v[1]);
              }}
            />
          )}
        </div>

        <div className={CELL}>
          <h3 className={LABEL}>Sensor</h3>
          <Select
            mode="multiple"
            className="w-full"
            value={ids}
            maxTagCount={0}
            maxTagPlaceholder={(omitted) => `${omitted.length} sensor dipilih`}
            placeholder="Pilih sensor"
            optionFilterProp="label"
            onChange={(v: number[]) => onIds(v.slice(0, MAX_SENSORS))}
            options={sensors.map((s) => ({
              value: s.id,
              label: `${s.code} - ${s.location}`,
              disabled: ids.length >= MAX_SENSORS && !ids.includes(s.id),
            }))}
          />
          <p className="m-0 mt-1.5 break-words text-[11px] leading-snug text-slate-500">
            {codes.length > 0 ? codes.join(", ") : "Pilih minimal 1 sensor"} (maks. {MAX_SENSORS})
          </p>
        </div>

        <div className={CELL}>
          <h3 className={LABEL}>Jenis Data</h3>
          <div className="flex flex-col gap-1.5">
            <Checkbox checked={types.water} disabled={types.water && !types.rain} onChange={(e) => onTypes({ ...types, water: e.target.checked })}>
              Tinggi Air
            </Checkbox>
            <Checkbox checked={types.rain} disabled={types.rain && !types.water} onChange={(e) => onTypes({ ...types, rain: e.target.checked })}>
              Curah Hujan
            </Checkbox>
          </div>
        </div>

        <div className={CELL}>
          <h3 className={LABEL}>Interval</h3>
          <Radio.Group value={interval} onChange={(e) => onInterval(e.target.value as HistoryInterval)} className="flex flex-col gap-1.5">
            {Object.values(HistoryInterval).map((i) => (
              <Radio key={i} value={i}>
                {INTERVAL_LABEL[i]}
              </Radio>
            ))}
          </Radio.Group>
        </div>

        <div className={`${CELL} flex items-start md:col-span-2 xl:col-span-1`}>
          <Button type="primary" size="large" block icon={<DownloadOutlined />} loading={exporting} onClick={onExport}>
            Export Data
          </Button>
        </div>
      </div>
    </section>
  );
};

export default HistoryFilters;
