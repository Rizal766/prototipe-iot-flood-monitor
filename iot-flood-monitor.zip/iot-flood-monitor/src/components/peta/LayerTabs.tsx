import { useMapStore } from "@/stores/useMapStore";
import { MapLayer, type BaseMap } from "@/types/map";

const BASE_TABS: { key: BaseMap; label: string }[] = [
  { key: "peta", label: "Peta" },
  { key: "satelit", label: "Satelit" },
];

export const LAYER_OPTIONS: { key: MapLayer; label: string }[] = [
  { key: MapLayer.RIVER, label: "Garis Sungai" },
  { key: MapLayer.DISTRICT, label: "Batas Kecamatan" },
  { key: MapLayer.EVACUATION, label: "Titik Evakuasi" },
  { key: MapLayer.RADAR, label: "Radar Hujan (P2)" },
];

const tabClass = (active: boolean) =>
  `shrink-0 cursor-pointer rounded-md border px-3 py-1.5 text-xs font-medium ${
    active ? "border-blue-600 bg-blue-600 text-white" : "border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
  }`;

const LayerTabs = () => {
  const baseMap = useMapStore((s) => s.baseMap);
  const setBaseMap = useMapStore((s) => s.setBaseMap);
  const layers = useMapStore((s) => s.layers);
  const toggleLayer = useMapStore((s) => s.toggleLayer);

  return (
    <div className="flex gap-2 overflow-x-auto rounded-lg border border-slate-200 bg-white p-2 shadow-sm">
      {BASE_TABS.map((t) => (
        <button key={t.key} type="button" aria-pressed={baseMap === t.key} onClick={() => setBaseMap(t.key)} className={tabClass(baseMap === t.key)}>
          {t.label}
        </button>
      ))}
      <span className="mx-1 w-px shrink-0 bg-slate-200" />
      {LAYER_OPTIONS.map((l) => (
        <button key={l.key} type="button" aria-pressed={layers[l.key]} onClick={() => toggleLayer(l.key)} className={tabClass(layers[l.key])}>
          {l.label}
        </button>
      ))}
    </div>
  );
};

export default LayerTabs;
