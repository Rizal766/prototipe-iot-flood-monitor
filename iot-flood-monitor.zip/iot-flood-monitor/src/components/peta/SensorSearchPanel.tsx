import { memo, useState } from "react";
import { Button, Input, Select } from "antd";
import { ApartmentOutlined, SearchOutlined, SwapOutlined } from "@ant-design/icons";
import Panel from "@/components/dashboard/Panel";
import { usePetaSensors } from "@/hooks/usePetaSensors";
import { ALL, useMapStore } from "@/stores/useMapStore";
import { useSensorStore } from "@/stores/useSensorStore";
import { FloodStatus, type ISensor } from "@/types/sensor";
import { STATUS_FILTERS, STATUS_META } from "@/utils/status";

const COLLAPSED_COUNT = 8;

interface ISensorListItemProps {
  sensor: ISensor;
  active: boolean;
  onSelect: (s: ISensor) => void;
}

const SensorListItem = memo(function SensorListItem({ sensor, active, onSelect }: ISensorListItemProps) {
  const meta = STATUS_META[sensor.status];
  return (
    <li>
      <button
        type="button"
        onClick={() => onSelect(sensor)}
        className={`flex w-full cursor-pointer items-center gap-2 rounded-md border bg-white px-2 py-1.5 text-left ${
          active ? "border-blue-500 bg-blue-50" : "border-slate-100 hover:bg-slate-50"
        }`}
      >
        <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: meta.color }} />
        <span className="min-w-0 flex-1 text-[11px] leading-tight">
          <span className="block font-semibold text-slate-800">#{sensor.code}</span>
          <span className="block truncate text-slate-500">{sensor.location}</span>
        </span>
        <span className="shrink-0 text-right text-[10px] leading-tight">
          <span className="block font-semibold" style={{ color: meta.color }}>
            {meta.label}
          </span>
          <span className="block text-slate-500">
            {sensor.status === FloodStatus.OFFLINE ? "-" : `${sensor.waterLevel} cm`}
          </span>
        </span>
      </button>
    </li>
  );
});

const SensorSearchPanel = () => {
  const { filtered, counts, rivers, districts, selected } = usePetaSensors();
  const search = useMapStore((s) => s.search);
  const setSearch = useMapStore((s) => s.setSearch);
  const status = useMapStore((s) => s.status);
  const setStatus = useMapStore((s) => s.setStatus);
  const river = useMapStore((s) => s.river);
  const setRiver = useMapStore((s) => s.setRiver);
  const district = useMapStore((s) => s.district);
  const setDistrict = useMapStore((s) => s.setDistrict);
  const resetFilters = useMapStore((s) => s.resetFilters);
  const flyTo = useMapStore((s) => s.flyTo);
  const selectSensor = useSensorStore((s) => s.selectSensor);
  const [expanded, setExpanded] = useState(false);

  const hasFilter = Boolean(search) || status !== "ALL" || river !== ALL || district !== ALL;
  const visible = expanded ? filtered : filtered.slice(0, COLLAPSED_COUNT);

  const handleSelect = (s: ISensor) => {
    selectSensor(s.id);
    flyTo({ lat: s.lat, lng: s.lng });
  };

  return (
    <Panel title="Peta Monitoring" className="h-full">
      <Input
        allowClear
        prefix={<SearchOutlined />}
        placeholder="Cari sensor / nama lokasi"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      <h3 className="mb-1.5 mt-3 text-xs font-semibold text-slate-700">Status Sensor</h3>
      <div className="grid grid-cols-2 gap-1.5">
        {STATUS_FILTERS.map((f) => (
          <button
            key={f.key}
            type="button"
            onClick={() => setStatus(f.key)}
            aria-pressed={status === f.key}
            className={`cursor-pointer rounded-md border-2 px-2 py-1 text-left text-white ${
              status === f.key ? "border-slate-800" : "border-transparent"
            }`}
            style={{ background: f.color }}
          >
            <span className="block text-[10px] leading-tight">{f.key === "ALL" ? "Sensor" : f.label}</span>
            <span className="block text-base font-bold leading-tight">{counts[f.key]}</span>
          </button>
        ))}
      </div>

      <div className="mb-1.5 mt-3 flex items-center justify-between">
        <h3 className="m-0 text-xs font-semibold text-slate-700">Filter tambahan</h3>
        {hasFilter && (
          <button type="button" onClick={resetFilters} className="cursor-pointer border-none bg-transparent p-0 text-[11px] text-blue-600 underline">
            Reset filter
          </button>
        )}
      </div>
      <div className="flex flex-col gap-1.5">
        <Select
          value={river}
          onChange={setRiver}
          suffixIcon={<SwapOutlined />}
          options={[{ value: ALL, label: "Semua Sungai" }, ...rivers.map((r) => ({ value: r, label: r }))]}
        />
        <Select
          value={district}
          onChange={setDistrict}
          suffixIcon={<ApartmentOutlined />}
          options={[{ value: ALL, label: "Semua Kecamatan" }, ...districts.map((d) => ({ value: d, label: d }))]}
        />
      </div>

      <ul className="m-0 mt-3 flex max-h-[420px] list-none flex-col gap-1.5 overflow-y-auto p-0">
        {visible.map((s) => (
          <SensorListItem key={s.id} sensor={s} active={s.id === selected?.id} onSelect={handleSelect} />
        ))}
        {filtered.length === 0 && (
          <li className="py-4 text-center text-xs text-slate-400">Tidak ada sensor yang cocok</li>
        )}
      </ul>

      {filtered.length > COLLAPSED_COUNT && (
        <Button size="small" type="link" className="mt-2 self-center" onClick={() => setExpanded((e) => !e)}>
          {expanded ? "Tampilkan lebih sedikit" : `Tampilkan semua sensor (${filtered.length})`}
        </Button>
      )}
    </Panel>
  );
};

export default SensorSearchPanel;
