import { useEffect, useMemo, useState } from "react";
import { Button } from "antd";
import {
  AimOutlined,
  FullscreenExitOutlined,
  FullscreenOutlined,
  MinusOutlined,
  PlusOutlined,
} from "@ant-design/icons";
import SensorMap from "@/components/map/SensorMap";
import { useEvacuationPoints } from "@/hooks/useMapData";
import { useDistricts, useRadarTiles, useWaterways } from "@/hooks/useMapLayers";
import { useLocate } from "@/hooks/useLocate";
import { usePetaSensors } from "@/hooks/usePetaSensors";
import { useMapStore } from "@/stores/useMapStore";
import { useSensorStore } from "@/stores/useSensorStore";
import { MapLayer } from "@/types/map";
import { FloodStatus } from "@/types/sensor";
import { STATUS_META } from "@/utils/status";
import { sensorsBBox } from "@/utils/map";

const LEGEND_STATUS: FloodStatus[] = [
  FloodStatus.AMAN,
  FloodStatus.WASPADA,
  FloodStatus.SIAGA,
  FloodStatus.BAHAYA,
  FloodStatus.OFFLINE,
];

const MapCanvas = () => {
  const { all, filtered, selected, isLoading, isError, refetch } = usePetaSensors();
  const { data: evac } = useEvacuationPoints();
  const baseMap = useMapStore((s) => s.baseMap);
  const layers = useMapStore((s) => s.layers);
  const myLocation = useMapStore((s) => s.myLocation);
  const zoomIn = useMapStore((s) => s.zoomIn);
  const zoomOut = useMapStore((s) => s.zoomOut);
  const selectSensor = useSensorStore((s) => s.selectSensor);
  const { locate, loading: locating } = useLocate();
  const [isFull, setIsFull] = useState(false);

  const bbox = useMemo(() => sensorsBBox(all), [all]);
  const ready = all.length > 0;
  const waterways = useWaterways(bbox, layers[MapLayer.RIVER] && ready);
  const districts = useDistricts(bbox, layers[MapLayer.DISTRICT] && ready);
  const radar = useRadarTiles(layers[MapLayer.RADAR]);

  useEffect(() => {
    const onChange = () => setIsFull(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", onChange);
    return () => document.removeEventListener("fullscreenchange", onChange);
  }, []);

  const toggleFullscreen = () => {
    if (document.fullscreenElement) void document.exitFullscreen();
    else void document.getElementById("peta-stage")?.requestFullscreen();
  };

  const notices = [
    layers[MapLayer.RIVER] && waterways.isFetching && "Memuat garis sungai…",
    layers[MapLayer.RIVER] && waterways.isError && "Garis sungai gagal dimuat",
    layers[MapLayer.DISTRICT] && districts.isFetching && "Memuat batas kecamatan…",
    layers[MapLayer.DISTRICT] && districts.isError && "Batas kecamatan gagal dimuat",
    layers[MapLayer.RADAR] && radar.isFetching && "Memuat radar hujan…",
    layers[MapLayer.RADAR] && radar.isError && "Radar hujan tidak tersedia",
  ].filter((n): n is string => Boolean(n));

  if (isError) {
    return (
      <div className="flex h-[420px] flex-col items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white sm:h-[520px]">
        <p className="m-0 font-semibold">Peta tidak dapat dimuat</p>
        <p className="m-0 text-xs text-slate-500">Coba lagi dalam beberapa saat.</p>
        <Button type="primary" onClick={() => void refetch()}>
          Coba lagi
        </Button>
      </div>
    );
  }

  return (
    <div
      id="peta-stage"
      className={`relative isolate w-full overflow-hidden rounded-lg border-2 border-blue-500 bg-slate-200 ${
        isFull ? "h-screen" : "h-[420px] sm:h-[520px]"
      }`}
    >
      <div className="absolute inset-0">
        <SensorMap
          sensors={filtered}
          selectedId={selected?.id ?? null}
          onSelect={selectSensor}
          baseMap={baseMap}
          evacuation={layers[MapLayer.EVACUATION] ? evac?.data?.filter((e) => e.active) : undefined}
          rivers={layers[MapLayer.RIVER] ? waterways.data : undefined}
          districts={layers[MapLayer.DISTRICT] ? districts.data : undefined}
          radarUrl={layers[MapLayer.RADAR] ? radar.data : null}
          myLocation={myLocation}
          onDetail={() =>
            document.getElementById("sensor-detail")?.scrollIntoView({ behavior: "smooth", block: "start" })
          }
        />
      </div>

      {isLoading && (
        <div className="absolute inset-0 z-[1000] flex items-center justify-center bg-slate-900/50 text-sm text-white">
          Memuat peta…
        </div>
      )}

      {notices.length > 0 && (
        <div className="absolute left-1/2 top-2 z-[1000] -translate-x-1/2 rounded bg-slate-900/80 px-3 py-1 text-[11px] text-white">
          {notices.join(" · ")}
        </div>
      )}

      <div className="absolute right-2 top-2 z-[1000] flex flex-col gap-1">
        {[
          { label: "Perbesar", icon: <PlusOutlined />, onClick: zoomIn },
          { label: "Perkecil", icon: <MinusOutlined />, onClick: zoomOut },
          { label: "Lokasi saya", icon: <AimOutlined />, onClick: locate, loading: locating },
          { label: "Layar penuh", icon: isFull ? <FullscreenExitOutlined /> : <FullscreenOutlined />, onClick: toggleFullscreen },
        ].map((b) => (
          <Button key={b.label} aria-label={b.label} title={b.label} icon={b.icon} onClick={b.onClick} loading={b.loading} />
        ))}
      </div>

      <div className="absolute bottom-7 right-2 z-[1000] hidden rounded-md bg-slate-900/85 p-2 text-[10px] text-white sm:block">
        <p className="m-0 mb-1 font-semibold">Legenda</p>
        <ul className="m-0 grid list-none grid-cols-2 gap-x-3 gap-y-0.5 p-0">
          {LEGEND_STATUS.map((st) => (
            <li key={st} className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full" style={{ background: STATUS_META[st].color }} />
              {st === FloodStatus.AMAN ? "Normal" : STATUS_META[st].label}
            </li>
          ))}
          <li className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-sm bg-emerald-600" />Titik Evakuasi</li>
          <li className="flex items-center gap-1.5"><span className="h-0.5 w-3 bg-blue-500" />Garis Sungai</li>
          <li className="flex items-center gap-1.5"><span className="w-3 border-t border-dashed border-violet-400" />Batas Kecamatan</li>
        </ul>
      </div>
    </div>
  );
};

export default MapCanvas;
