import { useState } from "react";
import { Button } from "antd";
import { ArrowRightOutlined, EnvironmentFilled, WarningFilled } from "@ant-design/icons";
import { useNavigate } from "react-router-dom";
import Panel from "@/components/dashboard/Panel";
import { usePetaSensors } from "@/hooks/usePetaSensors";
import { FloodStatus } from "@/types/sensor";
import { STATUS_MESSAGE, STATUS_META, formatTrend } from "@/utils/status";
import { hourLabels } from "@/utils/map";
import MiniLineChart from "./MiniLineChart";

type Tab = "ringkasan" | "grafik";

const SensorDetailPanel = () => {
  const { selected } = usePetaSensors();
  const [tab, setTab] = useState<Tab>("ringkasan");
  const navigate = useNavigate();

  if (!selected) {
    return <Panel title="Daftar Sensor"><p className="m-0 text-xs text-slate-400">Pilih sensor pada peta.</p></Panel>;
  }

  const meta = STATUS_META[selected.status];
  const labels = hourLabels(selected.updatedAt, selected.history.length || 6);

  const chart = (
    <>
      <h3 className="mb-1 mt-3 text-xs font-semibold">Grafik Tinggi Muka Air (6 jam)</h3>
      <MiniLineChart values={selected.history} labels={labels} color={meta.color} height={tab === "grafik" ? 190 : 130} />
    </>
  );

  return (
    <Panel title="Daftar Sensor">
      <div id="sensor-detail" className="scroll-mt-20">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="m-0 text-sm font-bold">#{selected.code}</p>
            <p className="m-0 text-xs text-slate-600">{selected.location}</p>
          </div>
          <span className="shrink-0 rounded px-2 py-0.5 text-[10px] font-semibold text-white" style={{ background: meta.color }}>
            {meta.label}
          </span>
        </div>

        <dl className="m-0 mt-2 flex flex-col gap-1 text-xs">
          {[
            ["Tinggi muka air", selected.status === FloodStatus.OFFLINE ? "-" : `${selected.waterLevel} cm`],
            ["Tren", formatTrend(selected.trend)],
            ["Baterai", `${selected.battery}%`],
          ].map(([k, v]) => (
            <div key={k} className="flex items-center justify-between border-b border-slate-100 pb-1">
              <dt className="text-slate-500">{k}</dt>
              <dd className="m-0 font-semibold">{v}</dd>
            </div>
          ))}
        </dl>

        <div className="mt-3 grid grid-cols-2 border-b border-slate-200 text-center text-xs" role="tablist">
          {([["ringkasan", "Ringkasan"], ["grafik", "Grafik 6 Jam"]] as [Tab, string][]).map(([key, label]) => (
            <button
              key={key}
              type="button"
              role="tab"
              aria-selected={tab === key}
              onClick={() => setTab(key)}
              className={`cursor-pointer border-x-0 border-t-0 bg-transparent py-1.5 font-medium ${
                tab === key ? "border-b-2 border-blue-600 text-blue-600" : "border-b-2 border-transparent text-slate-500"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {tab === "ringkasan" ? (
          <>
            <div className="mt-3 flex items-start gap-2 text-xs">
              <EnvironmentFilled className="mt-0.5 text-base text-slate-700" />
              <div>
                <p className="m-0 font-medium">{selected.location}</p>
                <p className="m-0 text-slate-500">Kecamatan</p>
                <p className="m-0 font-semibold">{selected.district}</p>
              </div>
            </div>

            <h3 className="mb-1 mt-3 text-xs font-semibold">Status</h3>
            <div className="flex items-start gap-2 rounded-md p-2 text-[11px] leading-snug" style={{ background: `${meta.color}1f` }}>
              <WarningFilled className="mt-0.5 text-base" style={{ color: meta.color }} />
              <span>{STATUS_MESSAGE[selected.status]}</span>
            </div>
            {chart}
          </>
        ) : (
          <>
            {chart}
            <table className="mt-2 w-full text-[11px]">
              <tbody>
                {selected.history.map((v, i) => (
                  <tr key={labels[i]} className="border-t border-slate-100">
                    <td className="py-0.5 text-slate-500">{labels[i]}</td>
                    <td className="py-0.5 text-right font-medium">{v} cm</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </>
        )}

        <Button type="primary" block className="mt-3" onClick={() => navigate(`/sensors/${selected.id}`)}>
          Lihat detail sensor <ArrowRightOutlined />
        </Button>
      </div>
    </Panel>
  );
};

export default SensorDetailPanel;
