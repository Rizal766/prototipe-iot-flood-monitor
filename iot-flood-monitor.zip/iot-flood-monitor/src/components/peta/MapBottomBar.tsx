import { Button, Switch } from "antd";
import { EnvironmentFilled, FullscreenOutlined, ReloadOutlined } from "@ant-design/icons";
import Panel from "@/components/dashboard/Panel";
import { useLocate } from "@/hooks/useLocate";
import { useMapStore } from "@/stores/useMapStore";
import { DEFAULT_CENTER, formatScale } from "@/utils/map";
import { LAYER_OPTIONS } from "./LayerTabs";

const MapBottomBar = () => {
  const layers = useMapStore((s) => s.layers);
  const toggleLayer = useMapStore((s) => s.toggleLayer);
  const zoom = useMapStore((s) => s.zoom);
  const resetView = useMapStore((s) => s.resetView);
  const myLocation = useMapStore((s) => s.myLocation);
  const { locate, loading } = useLocate();

  const scale = formatScale(zoom, DEFAULT_CENTER.lat);
  const fullscreen = () => void document.getElementById("peta-stage")?.requestFullscreen();

  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
      <Panel title="Kontrol Layer">
        <ul className="m-0 flex list-none flex-col gap-1.5 p-0">
          {LAYER_OPTIONS.map((l) => (
            <li key={l.key} className="flex items-center justify-between text-xs">
              <span>{l.label}</span>
              <Switch size="small" checked={layers[l.key]} onChange={() => toggleLayer(l.key)} aria-label={l.label} />
            </li>
          ))}
        </ul>
      </Panel>

      <Panel title="Lokasi Saya">
        <div className="flex items-start gap-2 text-xs">
          <EnvironmentFilled className="mt-0.5 text-lg text-blue-600" />
          <div>
            <p className="m-0 font-medium">Posisi Anda</p>
            <p className="m-0 text-slate-500">
              {myLocation ? `${myLocation.lat.toFixed(5)}, ${myLocation.lng.toFixed(5)}` : "Belum ditentukan"}
            </p>
          </div>
        </div>
        <Button size="small" className="mt-2" loading={loading} onClick={locate}>
          Posisi anda
        </Button>
      </Panel>

      <Panel title="Skala">
        <p className="m-0 text-xs text-slate-500">Zoom level {zoom}</p>
        <div className="mt-2 h-2 border-x border-b border-slate-700" style={{ width: Math.min(scale.width, 140) }} />
        <p className="m-0 mt-1 text-sm font-semibold">{scale.label}</p>
      </Panel>

      <Panel title="Aksi cepat">
        <div className="flex flex-col gap-1.5">
          <Button size="small" icon={<FullscreenOutlined />} onClick={fullscreen}>Layar Penuh</Button>
          <Button size="small" icon={<ReloadOutlined />} onClick={resetView}>Reset Peta</Button>
          <Button size="small" icon={<EnvironmentFilled />} loading={loading} onClick={locate}>Lokasi Saat Ini</Button>
        </div>
      </Panel>
    </div>
  );
};

export default MapBottomBar;
