import { usePetaSensors } from "@/hooks/usePetaSensors";
import { useMapStore } from "@/stores/useMapStore";
import { STATUS_FILTERS } from "@/utils/status";

const StatusChips = () => {
  const { counts } = usePetaSensors();
  const status = useMapStore((s) => s.status);
  const setStatus = useMapStore((s) => s.setStatus);

  return (
    <div className="flex gap-2 overflow-x-auto rounded-lg border border-slate-200 bg-white p-2 shadow-sm">
      {STATUS_FILTERS.map((f) => {
        const active = status === f.key;
        return (
          <button
            key={f.key}
            type="button"
            onClick={() => setStatus(f.key)}
            aria-pressed={active}
            className={`flex shrink-0 cursor-pointer items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium ${
              active ? "border-blue-500 bg-blue-50 text-blue-700" : "border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
            }`}
          >
            <span className="h-3 w-3 rounded-full" style={{ background: f.color }} />
            {f.label}
            <span className="text-[10px] text-slate-400">{counts[f.key]}</span>
          </button>
        );
      })}
    </div>
  );
};

export default StatusChips;
