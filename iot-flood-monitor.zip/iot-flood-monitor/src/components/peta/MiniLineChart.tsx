interface IMiniLineChartProps {
  values: number[];
  labels: string[];
  color: string;
  height?: number;
}

const W = 260;
const PAD = { left: 28, right: 8, top: 8, bottom: 20 };

const MiniLineChart = ({ values, labels, color, height = 130 }: IMiniLineChartProps) => {
  if (values.length < 2) {
    return <p className="m-0 py-6 text-center text-xs text-slate-400">Belum ada data riwayat</p>;
  }
  const plotW = W - PAD.left - PAD.right;
  const plotH = height - PAD.top - PAD.bottom;
  const max = Math.max(50, Math.ceil(Math.max(...values) / 50) * 50);
  const ticks = [0, max / 4, max / 2, (max * 3) / 4, max];
  const x = (i: number) => PAD.left + (i / (values.length - 1)) * plotW;
  const y = (v: number) => PAD.top + plotH - (v / max) * plotH;
  const line = values.map((v, i) => `${x(i)},${y(v)}`).join(" ");

  return (
    <svg viewBox={`0 0 ${W} ${height}`} className="w-full" role="img" aria-label="Grafik tinggi muka air">
      {ticks.map((t) => (
        <g key={t}>
          <line x1={PAD.left} x2={W - PAD.right} y1={y(t)} y2={y(t)} stroke="#e2e8f0" />
          <text x={PAD.left - 5} y={y(t) + 3} textAnchor="end" fontSize="8" fill="#64748b">
            {Math.round(t)}
          </text>
        </g>
      ))}
      <polygon points={`${x(0)},${y(0)} ${line} ${x(values.length - 1)},${y(0)}`} fill={color} opacity=".12" />
      <polyline points={line} fill="none" stroke={color} strokeWidth="1.8" strokeLinejoin="round" />
      <circle cx={x(values.length - 1)} cy={y(values[values.length - 1])} r="3" fill={color} />
      {labels.map((l, i) =>
        i % 2 === 0 || i === labels.length - 1 ? (
          <text key={l + i} x={x(i)} y={height - 6} textAnchor="middle" fontSize="8" fill="#64748b">
            {l}
          </text>
        ) : null,
      )}
    </svg>
  );
};

export default MiniLineChart;
