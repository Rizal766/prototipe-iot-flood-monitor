import { Button } from "antd";
import { DisconnectOutlined, ExclamationCircleFilled, ThunderboltOutlined } from "@ant-design/icons";
import Panel from "@/components/dashboard/Panel";
import { usePetaSensors } from "@/hooks/usePetaSensors";
import { useMapStore } from "@/stores/useMapStore";
import { useSensorStore } from "@/stores/useSensorStore";
import { FloodStatus, type ISensor } from "@/types/sensor";

const LOW_BATTERY = 20;

const SpecialCases = () => {
  const { all, isError, refetch } = usePetaSensors();
  const flyTo = useMapStore((s) => s.flyTo);
  const selectSensor = useSensorStore((s) => s.selectSensor);

  const offline = all.filter((s) => s.status === FloodStatus.OFFLINE);
  const lowBattery = all.filter((s) => s.status !== FloodStatus.OFFLINE && s.battery < LOW_BATTERY);

  const focus = (s: ISensor) => {
    selectSensor(s.id);
    flyTo({ lat: s.lat, lng: s.lng });
  };

  const rowClass = "flex w-full items-start gap-2 rounded-md border border-slate-100 bg-white p-2 text-left text-[11px]";

  return (
    <Panel title="Kasus Khusus">
      <ul className="m-0 flex list-none flex-col gap-1.5 p-0">
        {isError && (
          <li className={rowClass}>
            <ExclamationCircleFilled className="mt-0.5 text-base text-red-500" />
            <div className="flex-1">
              <p className="m-0 font-semibold">Peta tidak dapat dimuat</p>
              <p className="m-0 text-slate-500">Coba lagi dalam beberapa saat.</p>
            </div>
            <Button size="small" onClick={() => void refetch()}>Coba lagi</Button>
          </li>
        )}
        {offline.map((s) => (
          <li key={s.id}>
            <button type="button" className={`${rowClass} cursor-pointer`} onClick={() => focus(s)}>
              <DisconnectOutlined className="mt-0.5 text-base text-slate-500" />
              <span>
                <span className="block font-semibold">Sensor #{s.code} (Offline)</span>
                <span className="block text-slate-500">Terakhir terhubung {s.updatedAt}</span>
              </span>
            </button>
          </li>
        ))}
        {lowBattery.map((s) => (
          <li key={s.id}>
            <button type="button" className={`${rowClass} cursor-pointer`} onClick={() => focus(s)}>
              <ThunderboltOutlined className="mt-0.5 text-base text-amber-500" />
              <span>
                <span className="block font-semibold">Sensor #{s.code}: baterai rendah</span>
                <span className="block text-slate-500">Sisa {s.battery}%</span>
              </span>
            </button>
          </li>
        ))}
        {!isError && offline.length === 0 && lowBattery.length === 0 && (
          <li className="py-2 text-center text-xs text-slate-400">Tidak ada kasus khusus</li>
        )}
      </ul>
    </Panel>
  );
};

export default SpecialCases;
