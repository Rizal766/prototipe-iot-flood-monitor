const DropLogo = ({ size = 40 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden="true">
    <defs>
      <linearGradient id="drop-grad" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor="#7dd3fc" />
        <stop offset="1" stopColor="#2563eb" />
      </linearGradient>
    </defs>
    <path d="M24 3C24 3 8 20 8 31a16 16 0 0 0 32 0C40 20 24 3 24 3Z" fill="url(#drop-grad)" />
    <path d="M17 30a7 7 0 0 0 5 7" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" fill="none" opacity=".7" />
  </svg>
);

export default DropLogo;
