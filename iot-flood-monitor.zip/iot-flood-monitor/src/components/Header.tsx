import { Avatar, Dropdown } from "antd";
import { useNavigate } from "react-router-dom";
import { DownOutlined, MenuOutlined, UserOutlined } from "@ant-design/icons";
import DropLogo from "./DropLogo";
import GlobalSearch from "./GlobalSearch";
import { useLocationWeather } from "@/hooks/useLocationWeather";
import { useClock } from "@/hooks/useClock";
import { useAuthStore } from "@/stores/useAuthStore";
import { ROLE_LABEL } from "@/types/auth";

const Header = ({ onMenuClick }: { onMenuClick: () => void }) => {
  const { weather: w, place } = useLocationWeather();
  const { time, date, tz } = useClock();
  const user = useAuthStore((s) => s.user);
  const logout = useAuthStore((s) => s.logout);
  const navigate = useNavigate();

  return (
    <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-slate-200 bg-white px-3 py-2 sm:px-4">
      <button
        type="button"
        aria-label="Buka menu"
        onClick={onMenuClick}
        className="cursor-pointer border-none bg-transparent p-1 text-xl lg:hidden"
      >
        <MenuOutlined />
      </button>

      <div className="flex items-center gap-2">
        <DropLogo size={30} />
        <div className="hidden leading-tight sm:block">
          <p className="m-0 text-base font-bold text-slate-800">IoT Flood Monitor</p>
          <p className="m-0 text-[11px] text-slate-500">Early Warning System</p>
        </div>
      </div>

      <div className="mx-auto min-w-0 flex-1 md:max-w-md lg:ml-6">
        <GlobalSearch />
      </div>

      {w && (
        <div className="hidden items-center gap-2 xl:flex">
          <span className="text-3xl leading-none" aria-hidden="true">{w.icon}</span>
          <div className="leading-tight">
            <p className="m-0 text-base font-bold">{w.temperature}°C</p>
            <p className="m-0 text-[11px] text-slate-500">{w.condition}</p>
          </div>
          <p className="m-0 ml-2 max-w-40 truncate text-xs text-slate-600">{place}</p>
        </div>
      )}

      <div className="hidden text-right text-[11px] leading-tight text-slate-600 md:block">
        <p className="m-0 font-semibold tabular-nums">{time} {tz}</p>
        <p className="m-0">{date}</p>
      </div>

      <Dropdown
        trigger={["click"]}
        menu={{
          items: [
            { key: "profile", label: "Profil & Keamanan", onClick: () => navigate("/pengaturan/profil") },
            { key: "logout", label: "Logout", danger: true, onClick: logout },
          ],
        }}
      >
        <button type="button" className="flex cursor-pointer items-center gap-2 border-none bg-transparent p-0">
          <Avatar src={user?.avatar ?? undefined} icon={<UserOutlined />} />
          <span className="hidden text-left text-xs leading-tight md:block">
            <span className="block font-semibold text-slate-800">{user?.name ?? "Pengguna"}</span>
            <span className="block text-slate-500">{user?.role ? ROLE_LABEL[user.role] : "Pengguna"}</span>
          </span>
          <DownOutlined className="text-[10px]" />
        </button>
      </Dropdown>
    </header>
  );
};

export default Header;
