import { memo, type ReactNode } from "react";
import { CloudServerOutlined, DisconnectOutlined, ToolOutlined, WifiOutlined } from "@ant-design/icons";
import { DeviceConnection, type IDevice } from "@/types/device";

type Filter = DeviceConnection | "ALL";

interface ICardProps {
  label: string;
  value: number;
  footer: string;
  footerClass: string;
  icon: ReactNode;
  color: string;
  active: boolean;
  onClick: () => void;
}

const Card = memo(function Card({ label, value, footer, footerClass, icon, color, active, onClick }: ICardProps) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={`flex w-full cursor-pointer items-center gap-3 rounded-lg border bg-white p-3 text-left shadow-sm ${
        active ? "border-blue-500 ring-1 ring-blue-500" : "border-slate-200"
      }`}
    >
      <span className="text-3xl" style={{ color }}>
        {icon}
      </span>
      <span>
        <span className="block text-xs text-slate-600">{label}</span>
        <span className="block text-2xl font-bold leading-tight">{value}</span>
        <span className={`block text-[11px] ${footerClass}`}>{footer}</span>
      </span>
    </button>
  );
});

interface IDeviceStatsProps {
  devices: IDevice[];
  active: Filter;
  onSelect: (f: Filter) => void;
}

const DeviceStats = ({ devices, active, onSelect }: IDeviceStatsProps) => {
  const total = devices.length;
  const count = (c: DeviceConnection) => devices.filter((d) => d.connection === c).length;
  const pct = (n: number) => (total ? Math.round((n / total) * 100) : 0);
  const online = count(DeviceConnection.ONLINE);
  const offline = count(DeviceConnection.OFFLINE);
  const maintenance = count(DeviceConnection.MAINTENANCE);
  const fresh = devices.filter((d) => Date.now() - new Date(d.registeredAt).getTime() < 30 * 86400000).length;
  const toggle = (f: Filter) => () => onSelect(active === f ? "ALL" : f);

  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
      <Card label="Total Perangkat" value={total} footer={fresh > 0 ? `↑ ${fresh} perangkat baru` : "Tidak ada perangkat baru"} footerClass="text-sky-600" icon={<CloudServerOutlined />} color="#0ea5e9" active={active === "ALL"} onClick={() => onSelect("ALL")} />
      <Card label="Online" value={online} footer={`${pct(online)}% aktif`} footerClass="text-green-600" icon={<WifiOutlined />} color="#22c55e" active={active === DeviceConnection.ONLINE} onClick={toggle(DeviceConnection.ONLINE)} />
      <Card label="Offline" value={offline} footer={`${pct(offline)}% tidak aktif`} footerClass="text-red-500" icon={<DisconnectOutlined />} color="#ef4444" active={active === DeviceConnection.OFFLINE} onClick={toggle(DeviceConnection.OFFLINE)} />
      <Card label="Maintenance" value={maintenance} footer="dalam perbaikan" footerClass="text-amber-600" icon={<ToolOutlined />} color="#0f172a" active={active === DeviceConnection.MAINTENANCE} onClick={toggle(DeviceConnection.MAINTENANCE)} />
    </div>
  );
};

export default DeviceStats;
