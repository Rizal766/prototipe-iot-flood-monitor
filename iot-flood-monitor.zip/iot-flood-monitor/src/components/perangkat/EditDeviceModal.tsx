import { Button, Input, Modal, Select, message } from "antd";
import { Controller, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useDeviceMutations } from "@/hooks/useDevices";
import { deviceEditSchema, type DeviceEditValues } from "@/schemas/deviceSchema";
import { DEVICE_KIND_LABEL, type IDevice } from "@/types/device";
import { OFFICERS } from "@/utils/officers";

const FIELDS: { name: keyof Omit<DeviceEditValues, "officer">; label: string }[] = [
  { name: "name", label: "Nama Lokasi" },
  { name: "river", label: "Sungai" },
  { name: "district", label: "Kecamatan" },
  { name: "guid", label: "GUID / Kit ID" },
  { name: "firmware", label: "Firmware" },
  { name: "lat", label: "Latitude" },
  { name: "lng", label: "Longitude" },
];

const Form = ({ device, onClose }: { device: IDevice; onClose: () => void }) => {
  const { update } = useDeviceMutations();
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<DeviceEditValues>({
    resolver: zodResolver(deviceEditSchema),
    defaultValues: {
      name: device.name,
      river: device.river,
      district: device.district,
      guid: device.guid,
      firmware: device.firmware,
      lat: String(device.lat),
      lng: String(device.lng),
      officer: device.officer ?? "",
    },
  });

  const onSubmit = async (v: DeviceEditValues) => {
    const res = await update.mutateAsync({
      id: device.id,
      payload: {
        name: v.name.trim(),
        river: v.river.trim(),
        district: v.district.trim(),
        guid: v.guid,
        firmware: v.firmware,
        lat: Number(v.lat),
        lng: Number(v.lng),
        officer: v.officer || null,
      },
    });
    if (res.status) {
      message.success("Perangkat berhasil diperbarui");
      onClose();
    } else {
      message.error(res.message || "Gagal memperbarui perangkat");
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="grid grid-cols-1 gap-3 sm:grid-cols-2">
      <p className="m-0 text-xs text-slate-500 sm:col-span-2">
        {device.deviceId} · {DEVICE_KIND_LABEL[device.kind]} (ID dan jenis perangkat tidak dapat diubah)
      </p>
      {FIELDS.map((f) => (
        <div key={f.name} className={f.name === "name" ? "sm:col-span-2" : ""}>
          <label htmlFor={`edit-${f.name}`} className="mb-1 block text-xs font-medium text-slate-600">
            {f.label}
          </label>
          <Controller
            name={f.name}
            control={control}
            render={({ field }) => <Input {...field} id={`edit-${f.name}`} status={errors[f.name] ? "error" : undefined} />}
          />
          {errors[f.name] && <p className="m-0 mt-0.5 text-xs text-red-500">{errors[f.name]?.message}</p>}
        </div>
      ))}
      <div className="sm:col-span-2">
        <label className="mb-1 block text-xs font-medium text-slate-600">Penanggung Jawab</label>
        <Controller
          name="officer"
          control={control}
          render={({ field }) => (
            <Select
              {...field}
              className="w-full"
              allowClear
              placeholder="Belum ditentukan"
              options={OFFICERS.map((o) => ({ value: o, label: o }))}
              onChange={(v) => field.onChange(v ?? "")}
            />
          )}
        />
      </div>
      <div className="flex justify-end gap-2 sm:col-span-2">
        <Button onClick={onClose}>Batal</Button>
        <Button type="primary" htmlType="submit" loading={update.isPending}>
          Simpan Perubahan
        </Button>
      </div>
    </form>
  );
};

interface IEditDeviceModalProps {
  device: IDevice | null;
  onClose: () => void;
}

const EditDeviceModal = ({ device, onClose }: IEditDeviceModalProps) => (
  <Modal open={device !== null} title={device ? `Edit Perangkat ${device.deviceId}` : "Edit Perangkat"} footer={null} onCancel={onClose} width={560}>
    {device && <Form key={device.id} device={device} onClose={onClose} />}
  </Modal>
);

export default EditDeviceModal;
