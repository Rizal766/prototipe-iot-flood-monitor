import { DatePicker, Input, Select } from "antd";
import { SearchOutlined } from "@ant-design/icons";
import type { Dayjs } from "dayjs";
import { CONNECTION_META, DEVICE_KIND_LABEL, DeviceConnection, DeviceKind } from "@/types/device";

export const ALL = "ALL";

export interface IDeviceFilters {
  search: string;
  connection: DeviceConnection | "ALL";
  kind: DeviceKind | "ALL";
  district: string;
  range: [Dayjs, Dayjs] | null;
}

export const DEFAULT_DEVICE_FILTERS: IDeviceFilters = {
  search: "",
  connection: "ALL",
  kind: "ALL",
  district: ALL,
  range: null,
};

interface IDeviceToolbarProps {
  filters: IDeviceFilters;
  districts: string[];
  onChange: (patch: Partial<IDeviceFilters>) => void;
}

const DeviceToolbar = ({ filters, districts, onChange }: IDeviceToolbarProps) => (
  <div className="flex flex-wrap items-center gap-2 rounded-lg border border-slate-200 bg-white p-2 shadow-sm">
    <Input
      allowClear
      className="min-w-[220px] flex-1 md:max-w-sm"
      prefix={<SearchOutlined />}
      placeholder="Cari ID sensor, nama lokasi atau sungai"
      value={filters.search}
      onChange={(e) => onChange({ search: e.target.value })}
    />
    <Select
      className="w-36"
      value={filters.connection}
      onChange={(v: DeviceConnection | "ALL") => onChange({ connection: v })}
      options={[
        { value: "ALL", label: "Semua status" },
        ...Object.values(DeviceConnection).map((c) => ({ value: c, label: CONNECTION_META[c].label })),
      ]}
    />
    <Select
      className="w-40"
      value={filters.kind}
      onChange={(v: DeviceKind | "ALL") => onChange({ kind: v })}
      options={[
        { value: "ALL", label: "Semua jenis" },
        ...Object.values(DeviceKind).map((k) => ({ value: k, label: DEVICE_KIND_LABEL[k] })),
      ]}
    />
    <Select
      className="w-44"
      value={filters.district}
      onChange={(v) => onChange({ district: v })}
      options={[{ value: ALL, label: "Semua lokasi" }, ...districts.map((d) => ({ value: d, label: d }))]}
    />
    <DatePicker.RangePicker
      value={filters.range}
      placeholder={["Terakhir terhubung", "Terakhir terhubung"]}
      onChange={(v) => onChange({ range: v && v[0] && v[1] ? [v[0], v[1]] : null })}
    />
  </div>
);

export default DeviceToolbar;
