import { useEffect, useRef } from "react";
import { Button, Modal, Spin, message } from "antd";
import { useMutation } from "@tanstack/react-query";
import { QRCodeCanvas } from "qrcode.react";
import { createPairing } from "@/api/deviceApi";
import type { IDevice } from "@/types/device";
import { saveBlob } from "@/utils/download";
import { formatDateTime } from "@/utils/time";

const Body = ({ device }: { device: IDevice }) => {
  const gen = useMutation({ mutationFn: () => createPairing(device.id) });
  const { mutate } = gen;
  const box = useRef<HTMLDivElement>(null);

  useEffect(() => {
    mutate();
  }, [mutate]);

  const pairing = gen.data?.data;

  if (gen.isPending || !pairing) {
    return gen.isError || (gen.data && !gen.data.status) ? (
      <div className="flex flex-col items-center gap-3 py-6">
        <p className="m-0 text-sm text-red-500">Gagal membuat QR pairing.</p>
        <Button onClick={() => mutate()}>Coba lagi</Button>
      </div>
    ) : (
      <Spin className="block py-10" />
    );
  }

  const days = Math.max(0, Math.ceil((new Date(pairing.expiresAt).getTime() - Date.now()) / 86400000));

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(pairing.payload);
      message.success("Data pairing disalin");
    } catch {
      message.error("Tidak dapat menyalin ke clipboard");
    }
  };

  const downloadPdf = async () => {
    const dataUrl = box.current?.querySelector("canvas")?.toDataURL("image/png");
    if (!dataUrl) return;
    const { jsPDF } = await import("jspdf");
    const doc = new jsPDF({ unit: "mm", format: "a5" });
    doc.setFontSize(16);
    doc.text("QR Pairing Perangkat", 14, 20);
    doc.setFontSize(11);
    doc.text(`${device.deviceId} - ${device.name}`, 14, 28);
    doc.text(`GUID / Kit ID: ${device.guid}`, 14, 34);
    doc.addImage(dataUrl, "PNG", 14, 42, 70, 70);
    doc.setFontSize(9);
    doc.text(`Berlaku sampai ${formatDateTime(pairing.expiresAt)}`, 14, 120);
    doc.text("Scan dengan aplikasi pairing untuk menghubungkan perangkat.", 14, 126);
    saveBlob(doc.output("blob"), `qr-pairing-${device.deviceId.toLowerCase()}.pdf`);
  };

  return (
    <div className="flex flex-col items-center gap-3 text-center">
      <p className="m-0 text-sm font-semibold">Perangkat {device.deviceId}</p>
      <p className="m-0 text-xs text-slate-500">{device.name}</p>
      <div ref={box} className="rounded-md border border-slate-200 bg-white p-2">
        <QRCodeCanvas value={pairing.payload} size={176} level="M" marginSize={1} />
      </div>
      <p className="m-0 text-xs text-slate-500">
        Scan QR ini dengan aplikasi pairing untuk menghubungkan perangkat.
      </p>
      <div className="flex flex-wrap justify-center gap-2">
        <Button onClick={() => void downloadPdf()}>Unduh PDF</Button>
        <Button onClick={() => void copy()}>Salin</Button>
        <Button type="primary" onClick={() => mutate()}>
          Buat Ulang
        </Button>
      </div>
      <p className="m-0 rounded bg-amber-50 px-3 py-1 text-[11px] text-amber-700">
        QR akan kedaluwarsa dalam {days} hari
      </p>
    </div>
  );
};

interface IPairingQrModalProps {
  device: IDevice | null;
  onClose: () => void;
}

const PairingQrModal = ({ device, onClose }: IPairingQrModalProps) => (
  <Modal open={device !== null} title="Panel QR Pairing" footer={null} onCancel={onClose} width={420}>
    {device && <Body key={device.id} device={device} />}
  </Modal>
);

export default PairingQrModal;
