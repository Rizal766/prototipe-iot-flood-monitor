import { useEffect } from "react";
import { Button, Modal, Spin } from "antd";
import { CheckCircleFilled, CloseCircleFilled } from "@ant-design/icons";
import { useMutation } from "@tanstack/react-query";
import { testConnection } from "@/api/deviceApi";
import type { IDevice } from "@/types/device";
import { formatDateTime } from "@/utils/time";

const Body = ({ device, onClose }: { device: IDevice; onClose: () => void }) => {
  const test = useMutation({ mutationFn: () => testConnection(device.id) });
  const { mutate } = test;

  useEffect(() => {
    mutate();
  }, [mutate]);

  const result = test.data?.data;
  const failedRequest = test.isError || (test.data && !test.data.status);

  if (test.isPending || (!result && !failedRequest)) {
    return (
      <div className="flex flex-col items-center gap-3 py-8">
        <Spin size="large" />
        <p className="m-0 text-sm text-slate-500">Menguji koneksi ke {device.deviceId}…</p>
      </div>
    );
  }

  if (!result) {
    return (
      <div className="flex flex-col items-center gap-3 py-6">
        <p className="m-0 text-sm text-red-500">Pengujian tidak dapat dijalankan.</p>
        <Button onClick={() => mutate()}>Coba lagi</Button>
      </div>
    );
  }

  const rows: [string, string][] = [
    ["Host", result.host],
    ["Stream", result.stream],
    ["Status", result.status],
    ["GUID / Kit ID", result.guid],
    ["Latensi", result.latencyMs !== null ? `${result.latencyMs} ms` : "-"],
    ["Waktu uji", formatDateTime(result.testedAt)],
  ];

  return (
    <div className={`rounded-lg border p-4 ${result.ok ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}`}>
      <p className={`m-0 flex items-center gap-2 text-base font-bold ${result.ok ? "text-green-700" : "text-red-600"}`}>
        {result.ok ? <CheckCircleFilled /> : <CloseCircleFilled />}
        {result.ok ? "Koneksi berhasil!" : "Koneksi gagal!"}
      </p>
      <p className="m-0 mb-3 text-xs text-slate-600">{result.message}</p>
      <dl className="m-0 grid grid-cols-[110px_1fr] gap-x-3 gap-y-1 text-xs">
        {rows.map(([k, v]) => (
          <div key={k} className="contents">
            <dt className="text-slate-500">{k}</dt>
            <dd className="m-0 break-all font-medium">{v}</dd>
          </div>
        ))}
      </dl>
      {!result.ok && (
        <ul className="m-0 mt-3 list-disc pl-4 text-[11px] text-slate-600">
          <li>Pastikan perangkat menyala dan baterai mencukupi.</li>
          <li>Periksa sinyal jaringan di lokasi.</li>
          <li>Cocokkan GUID / Kit ID dengan label perangkat.</li>
        </ul>
      )}
      <div className="mt-4 flex justify-end gap-2">
        <Button onClick={onClose}>Tutup</Button>
        <Button type="primary" onClick={() => mutate()}>
          Uji Koneksi Lagi
        </Button>
      </div>
    </div>
  );
};

interface IConnectionTestModalProps {
  device: IDevice | null;
  onClose: () => void;
}

const ConnectionTestModal = ({ device, onClose }: IConnectionTestModalProps) => (
  <Modal open={device !== null} title={device ? `Uji Koneksi - ${device.deviceId}` : "Uji Koneksi"} footer={null} onCancel={onClose} width={480}>
    {device && <Body key={device.id} device={device} onClose={onClose} />}
  </Modal>
);

export default ConnectionTestModal;
