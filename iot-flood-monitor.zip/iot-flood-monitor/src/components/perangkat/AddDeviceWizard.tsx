import { useMemo, useState } from "react";
import { AutoComplete, Button, Input, Select, Steps, Upload, message } from "antd";
import { CheckCircleFilled, EnvironmentOutlined } from "@ant-design/icons";
import { Controller, useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import Panel from "@/components/dashboard/Panel";
import MapPicker from "@/components/map/MapPicker";
import { useDeviceMutations } from "@/hooks/useDevices";
import { STEP_FIELDS, deviceFormSchema, type DeviceFormValues } from "@/schemas/deviceSchema";
import { DEVICE_KIND_LABEL, DeviceKind, type IDevice } from "@/types/device";
import { OFFICERS } from "@/utils/officers";
import { THRESHOLD_TEMPLATES } from "@/utils/thresholdTemplates";

const STEPS = ["Info Lokasi", "Koneksi", "Ambang Batas", "Penanggung Jawab"];
const MAX_PHOTO = 5 * 1024 * 1024;

const nextDeviceId = (devices: IDevice[]): string => {
  const max = Math.max(0, ...devices.map((d) => Number(d.deviceId.replace(/\D/g, "")) || 0));
  return `DEV-${String(max + 1).padStart(3, "0")}`;
};

const EMPTY: DeviceFormValues = {
  deviceId: "",
  name: "",
  river: "",
  district: "",
  lat: "",
  lng: "",
  kind: DeviceKind.WATER_LEVEL,
  guid: "",
  firmware: "v1.2.3",
  template: THRESHOLD_TEMPLATES[0].name,
  officer: "",
};

interface IAddDeviceWizardProps {
  devices: IDevice[];
  isAdmin: boolean;
}

const AddDeviceWizard = ({ devices, isAdmin }: IAddDeviceWizardProps) => {
  const { create } = useDeviceMutations();
  const [step, setStep] = useState(0);
  const [photo, setPhoto] = useState<string | null>(null);
  const [created, setCreated] = useState<string | null>(null);

  const {
    control,
    handleSubmit,
    setValue,
    reset,
    trigger,
    formState: { errors },
  } = useForm<DeviceFormValues>({ resolver: zodResolver(deviceFormSchema), defaultValues: EMPTY });
  const v = useWatch({ control });

  const rivers = useMemo(() => [...new Set(devices.map((d) => d.river))].sort(), [devices]);
  const districts = useMemo(() => [...new Set(devices.map((d) => d.district))].sort(), [devices]);
  const template = THRESHOLD_TEMPLATES.find((t) => t.name === v.template) ?? THRESHOLD_TEMPLATES[0];

  const lat = Number(v.lat);
  const lng = Number(v.lng);
  const picked = v.lat && v.lng && !Number.isNaN(lat) && !Number.isNaN(lng) ? { lat, lng } : null;

  const restart = () => {
    reset({ ...EMPTY, deviceId: nextDeviceId(devices) });
    setPhoto(null);
    setStep(0);
  };

  const next = async () => {
    const ok = await trigger(STEP_FIELDS[step]);
    if (ok) setStep((s) => s + 1);
  };

  const beforeUpload = (file: File) => {
    if (!["image/jpeg", "image/png"].includes(file.type)) {
      message.error("Format foto harus JPG atau PNG");
      return Upload.LIST_IGNORE;
    }
    if (file.size > MAX_PHOTO) {
      message.error("Ukuran foto maksimal 5 MB");
      return Upload.LIST_IGNORE;
    }
    const reader = new FileReader();
    reader.onload = () => setPhoto(typeof reader.result === "string" ? reader.result : null);
    reader.readAsDataURL(file);
    return false; // tidak diunggah otomatis
  };

  const locateMe = () => {
    if (!navigator.geolocation) {
      message.warning("Perangkat tidak mendukung geolokasi");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (p) => {
        setValue("lat", p.coords.latitude.toFixed(6), { shouldValidate: true });
        setValue("lng", p.coords.longitude.toFixed(6), { shouldValidate: true });
      },
      () => message.error("Izin lokasi ditolak atau tidak tersedia"),
      { timeout: 8000 },
    );
  };

  const onSubmit = async (values: DeviceFormValues) => {
    const tpl = THRESHOLD_TEMPLATES.find((t) => t.name === values.template) ?? THRESHOLD_TEMPLATES[0];
    const res = await create.mutateAsync({
      deviceId: values.deviceId,
      name: values.name.trim(),
      kind: values.kind,
      guid: values.guid,
      firmware: values.firmware,
      river: values.river.trim(),
      district: values.district.trim(),
      lat: Number(values.lat),
      lng: Number(values.lng),
      officer: values.officer || null,
      photo,
      thresholds: tpl.thresholds,
    });
    if (res.status) {
      setCreated(values.deviceId);
      restart();
    } else {
      message.error(res.message || "Gagal menambahkan perangkat");
      if (/ID perangkat/i.test(res.message)) setStep(0);
      else if (/GUID/i.test(res.message)) setStep(1);
    }
  };

  const err = (m?: string) => (m ? <p className="m-0 mt-0.5 text-[11px] text-red-500">{m}</p> : null);
  const label = "mb-1 block text-xs font-medium text-slate-600";

  if (!isAdmin) {
    return (
      <Panel title="Tambah Perangkat Baru">
        <p className="m-0 rounded bg-slate-50 p-3 text-xs text-slate-500">
          Hanya Admin yang dapat menambah, mengubah, dan menghapus perangkat. Anda masuk sebagai Operator.
        </p>
      </Panel>
    );
  }

  return (
    <Panel title="Tambah Perangkat Baru">
      {created && (
        <div className="mb-3 flex items-start gap-2 rounded-md border border-green-200 bg-green-50 p-3 text-xs" role="status">
          <CheckCircleFilled className="mt-0.5 text-lg text-green-600" />
          <div className="flex-1">
            <p className="m-0 font-semibold text-green-700">Perangkat berhasil ditambahkan!</p>
            <p className="m-0 text-slate-600">
              Sensor {created} sudah terdaftar dan berstatus offline sampai data pertama diterima.
            </p>
          </div>
          <button type="button" aria-label="Tutup" onClick={() => setCreated(null)} className="cursor-pointer border-none bg-transparent p-0 text-slate-400">
            ×
          </button>
        </div>
      )}

      <Steps size="small" current={step} items={STEPS.map((title) => ({ title }))} className="mb-4 [&_.ant-steps-item-title]:text-[10px]" />

      <form onSubmit={handleSubmit(onSubmit)} noValidate className="flex flex-col gap-3 text-xs">
        {step === 0 && (
          <>
            <p className="m-0 font-semibold">1. Info Lokasi</p>
            <p className="m-0 -mt-2 text-slate-500">Isi informasi lokasi dan pilih koordinat di peta.</p>
            <div>
              <label htmlFor="dev-id" className={label}>ID Perangkat *</label>
              <Controller name="deviceId" control={control} render={({ field }) => <Input {...field} id="dev-id" placeholder={nextDeviceId(devices)} />} />
              {err(errors.deviceId?.message)}
            </div>
            <div>
              <label htmlFor="dev-name" className={label}>Nama Lokasi *</label>
              <Controller name="name" control={control} render={({ field }) => <Input {...field} id="dev-name" placeholder="Contoh: Kali Banjir Kanal Barat" />} />
              {err(errors.name?.message)}
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className={label}>Sungai *</label>
                <Controller
                  name="river"
                  control={control}
                  render={({ field }) => (
                    <AutoComplete {...field} className="w-full" placeholder="Pilih sungai" options={rivers.map((r) => ({ value: r }))} />
                  )}
                />
                {err(errors.river?.message)}
              </div>
              <div>
                <label className={label}>Kecamatan *</label>
                <Controller
                  name="district"
                  control={control}
                  render={({ field }) => (
                    <AutoComplete {...field} className="w-full" placeholder="Pilih kecamatan" options={districts.map((d) => ({ value: d }))} />
                  )}
                />
                {err(errors.district?.message)}
              </div>
            </div>

            <MapPicker
              value={picked}
              onChange={(p) => {
                setValue("lat", p.lat.toFixed(6), { shouldValidate: true });
                setValue("lng", p.lng.toFixed(6), { shouldValidate: true });
              }}
            />
            <div className="grid grid-cols-[1fr_1fr_auto] items-start gap-2">
              <div>
                <Controller name="lat" control={control} render={({ field }) => <Input {...field} placeholder="Latitude" aria-label="Latitude" />} />
                {err(errors.lat?.message)}
              </div>
              <div>
                <Controller name="lng" control={control} render={({ field }) => <Input {...field} placeholder="Longitude" aria-label="Longitude" />} />
                {err(errors.lng?.message)}
              </div>
              <Button icon={<EnvironmentOutlined />} onClick={locateMe}>
                Lokasi saya
              </Button>
            </div>
            <p className="m-0 -mt-1 text-[11px] text-slate-400">Klik peta atau geser pin untuk memilih koordinat.</p>

            <div>
              <label className={label}>Foto Lokasi (opsional)</label>
              <Upload.Dragger accept=".jpg,.jpeg,.png" showUploadList={false} maxCount={1} beforeUpload={beforeUpload}>
                {photo ? (
                  <img src={photo} alt="Foto lokasi" className="mx-auto max-h-28 rounded" />
                ) : (
                  <p className="m-0 py-2 text-slate-500">
                    Klik untuk unggah foto lokasi
                    <br />
                    <span className="text-[11px]">Format: JPG, PNG (maks. 5MB)</span>
                  </p>
                )}
              </Upload.Dragger>
            </div>
          </>
        )}

        {step === 1 && (
          <>
            <p className="m-0 font-semibold">2. Koneksi</p>
            <p className="m-0 -mt-2 text-slate-500">Data perangkat keras yang terpasang di lokasi.</p>
            <div>
              <label className={label}>Jenis Perangkat *</label>
              <Controller
                name="kind"
                control={control}
                render={({ field }) => (
                  <Select {...field} className="w-full" options={Object.values(DeviceKind).map((k) => ({ value: k, label: DEVICE_KIND_LABEL[k] }))} />
                )}
              />
            </div>
            <div>
              <label htmlFor="dev-guid" className={label}>GUID / Kit ID *</label>
              <Controller name="guid" control={control} render={({ field }) => <Input {...field} id="dev-guid" placeholder="GK-001-7789" />} />
              {err(errors.guid?.message)}
            </div>
            <div>
              <label htmlFor="dev-fw" className={label}>Versi Firmware *</label>
              <Controller name="firmware" control={control} render={({ field }) => <Input {...field} id="dev-fw" placeholder="v1.2.3" />} />
              {err(errors.firmware?.message)}
            </div>
          </>
        )}

        {step === 2 && (
          <>
            <p className="m-0 font-semibold">3. Ambang Batas</p>
            <p className="m-0 -mt-2 text-slate-500">Pilih template awal. Nilai dapat diubah di menu Ambang Batas & Aturan Alert.</p>
            <Controller
              name="template"
              control={control}
              render={({ field }) => (
                <Select {...field} className="w-full" options={THRESHOLD_TEMPLATES.map((t) => ({ value: t.name, label: t.name }))} />
              )}
            />
            {err(errors.template?.message)}
            <ul className="m-0 flex list-none flex-col gap-1 rounded bg-slate-50 p-3">
              <li>Waspada: <b>{template.thresholds.waspada} cm</b></li>
              <li>Siaga: <b>{template.thresholds.siaga} cm</b></li>
              <li>Bahaya: <b>{template.thresholds.bahaya} cm</b></li>
            </ul>
          </>
        )}

        {step === 3 && (
          <>
            <p className="m-0 font-semibold">4. Penanggung Jawab</p>
            <p className="m-0 -mt-2 text-slate-500">Petugas yang bertanggung jawab atas perangkat ini (opsional).</p>
            <Controller
              name="officer"
              control={control}
              render={({ field }) => (
                <Select
                  {...field}
                  className="w-full"
                  allowClear
                  placeholder="Pilih petugas"
                  options={OFFICERS.map((o) => ({ value: o, label: o }))}
                  onChange={(val) => field.onChange(val ?? "")}
                />
              )}
            />
            <dl className="m-0 grid grid-cols-[100px_1fr] gap-x-2 gap-y-1 rounded bg-slate-50 p-3">
              <dt className="text-slate-500">ID</dt><dd className="m-0 font-medium">{v.deviceId}</dd>
              <dt className="text-slate-500">Lokasi</dt><dd className="m-0 font-medium">{v.name}</dd>
              <dt className="text-slate-500">Koordinat</dt><dd className="m-0 font-medium">{v.lat}, {v.lng}</dd>
              <dt className="text-slate-500">Jenis</dt><dd className="m-0 font-medium">{v.kind ? DEVICE_KIND_LABEL[v.kind] : "-"}</dd>
              <dt className="text-slate-500">GUID</dt><dd className="m-0 font-medium">{v.guid}</dd>
              <dt className="text-slate-500">Template</dt><dd className="m-0 font-medium">{v.template}</dd>
            </dl>
          </>
        )}

        <div className="mt-1 flex justify-between gap-2">
          <Button onClick={step === 0 ? restart : () => setStep((s) => s - 1)}>{step === 0 ? "Batal" : "Kembali"}</Button>
          {step < STEPS.length - 1 ? (
            <Button type="primary" onClick={() => void next()}>
              Lanjut →
            </Button>
          ) : (
            <Button type="primary" htmlType="submit" loading={create.isPending}>
              Simpan Perangkat
            </Button>
          )}
        </div>
      </form>
    </Panel>
  );
};

export default AddDeviceWizard;
