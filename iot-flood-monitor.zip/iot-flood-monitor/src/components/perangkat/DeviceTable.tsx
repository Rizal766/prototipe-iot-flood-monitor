import { useMemo } from "react";
import { DataGrid, type GridColDef, type GridPaginationModel, type GridRowSelectionModel } from "@mui/x-data-grid";
import { Button, Dropdown, Pagination, Select } from "antd";
import { EditOutlined, MoreOutlined } from "@ant-design/icons";
import { CONNECTION_META, DEVICE_KIND_ICON, DEVICE_KIND_LABEL, type IDevice } from "@/types/device";
import { formatDateTime } from "@/utils/time";

const PAGE_SIZES = [10, 25, 50];

const NoRows = () => (
  <div className="flex h-full items-center justify-center text-sm text-slate-400">Tidak ada perangkat yang cocok</div>
);

interface IDeviceTableProps {
  rows: IDevice[];
  loading: boolean;
  isAdmin: boolean;
  selection: GridRowSelectionModel;
  paging: GridPaginationModel;
  onSelectionChange: (m: GridRowSelectionModel) => void;
  onPagingChange: (m: GridPaginationModel) => void;
  onEdit: (d: IDevice) => void;
  onTest: (d: IDevice) => void;
  onPairing: (d: IDevice) => void;
  onDelete: (d: IDevice) => void;
}

const DeviceTable = ({
  rows,
  loading,
  isAdmin,
  selection,
  paging,
  onSelectionChange,
  onPagingChange,
  onEdit,
  onTest,
  onPairing,
  onDelete,
}: IDeviceTableProps) => {
  const columns = useMemo<GridColDef<IDevice>[]>(
    () => [
      { field: "deviceId", headerName: "ID", width: 100 },
      {
        field: "name",
        headerName: "Nama Lokasi",
        flex: 1,
        minWidth: 190,
        renderCell: (p) => (
          <div className="leading-tight">
            <div className="font-medium">{p.row.name}</div>
            <div className="text-[11px] text-slate-500">Sungai {p.row.river}</div>
          </div>
        ),
      },
      {
        field: "kind",
        headerName: "Jenis",
        width: 130,
        renderCell: (p) => (
          <span className="flex items-center gap-1.5">
            <span aria-hidden="true">{DEVICE_KIND_ICON[p.row.kind]}</span>
            {DEVICE_KIND_LABEL[p.row.kind]}
          </span>
        ),
      },
      { field: "guid", headerName: "GUID / Kit ID", width: 130 },
      { field: "firmware", headerName: "Firmware", width: 90 },
      {
        field: "connection",
        headerName: "Status Koneksi",
        width: 140,
        renderCell: (p) => {
          const m = CONNECTION_META[p.row.connection];
          return (
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: m.color }} />
              {m.label}
            </span>
          );
        },
      },
      {
        field: "lastSeen",
        headerName: "Terakhir Terhubung",
        width: 170,
        valueFormatter: (v: string | null) => (v ? formatDateTime(v) : "-"),
      },
      {
        field: "actions",
        headerName: "Aksi",
        width: 100,
        sortable: false,
        disableColumnMenu: true,
        renderCell: (p) => {
          const d = p.row;
          const items = [
            { key: "test", label: "Uji Koneksi", onClick: () => onTest(d) },
            { key: "qr", label: "QR Pairing", onClick: () => onPairing(d) },
            ...(isAdmin ? [{ key: "delete", label: "Hapus Perangkat", danger: true, onClick: () => onDelete(d) }] : []),
          ];
          return (
            <span className="flex items-center gap-1">
              <Button size="small" type="text" aria-label="Edit perangkat" icon={<EditOutlined />} disabled={!isAdmin} onClick={() => onEdit(d)} />
              <Dropdown trigger={["click"]} menu={{ items }}>
                <Button size="small" type="text" aria-label="Menu lainnya" icon={<MoreOutlined />} />
              </Dropdown>
            </span>
          );
        },
      },
    ],
    [isAdmin, onEdit, onTest, onPairing, onDelete],
  );

  const start = rows.length === 0 ? 0 : paging.page * paging.pageSize + 1;
  const end = Math.min((paging.page + 1) * paging.pageSize, rows.length);

  return (
    <>
      <DataGrid
        rows={rows}
        columns={columns}
        loading={loading}
        autoHeight
        rowHeight={56}
        columnHeaderHeight={44}
        hideFooter
        checkboxSelection
        disableRowSelectionOnClick
        disableColumnMenu
        rowSelectionModel={selection}
        onRowSelectionModelChange={onSelectionChange}
        paginationModel={paging}
        onPaginationModelChange={onPagingChange}
        pageSizeOptions={PAGE_SIZES}
        slots={{ noRowsOverlay: NoRows }}
        sx={{
          border: 0,
          fontSize: 12,
          "& .MuiDataGrid-columnHeaders": { backgroundColor: "#f8fafc" },
          "& .MuiDataGrid-overlayWrapper": { minHeight: 120 },
        }}
      />
      <div className="mt-2 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-2 text-xs text-slate-600">
        <span>
          Menampilkan {start} - {end} dari {rows.length} Perangkat
        </span>
        <span className="flex items-center gap-2">
          Tampilkan
          <Select
            size="small"
            value={paging.pageSize}
            onChange={(v) => onPagingChange({ page: 0, pageSize: v })}
            options={PAGE_SIZES.map((n) => ({ value: n, label: n }))}
          />
        </span>
        <Pagination
          size="small"
          current={paging.page + 1}
          pageSize={paging.pageSize}
          total={rows.length}
          showSizeChanger={false}
          onChange={(p) => onPagingChange({ ...paging, page: p - 1 })}
        />
      </div>
    </>
  );
};

export default DeviceTable;
