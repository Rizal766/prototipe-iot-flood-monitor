import Panel from "./Panel";
import { useWaterChart } from "@/hooks/useDashboard";

const W = 420;
const H = 220;
const PAD = { left: 34, right: 10, top: 10, bottom: 26 };
const Y_MAX = 350;
const TICKS = [0, 50, 100, 150, 200, 250, 300, 350];

// Grafik garis SVG ringan (tanpa library chart tambahan)
const WaterLevelChart = () => {
  const { data } = useWaterChart();
  const chart = data?.data;
  const plotW = W - PAD.left - PAD.right;
  const plotH = H - PAD.top - PAD.bottom;
  const y = (v: number) => PAD.top + plotH - (v / Y_MAX) * plotH;

  return (
    <Panel title="Grafik Tinggi Muka Air (TMA)" className="h-full">
      {chart && (
        <>
          <ul className="m-0 mb-1 flex list-none flex-wrap justify-end gap-x-3 p-0 text-[10px] text-slate-600">
            {chart.series.map((s) => (
              <li key={s.code} className="flex items-center gap-1">
                <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ background: s.color }} />
                {s.code} ({s.label})
              </li>
            ))}
          </ul>
          <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="Grafik tinggi muka air">
            {TICKS.map((t) => (
              <g key={t}>
                <line x1={PAD.left} x2={W - PAD.right} y1={y(t)} y2={y(t)} stroke="#e2e8f0" strokeWidth="1" />
                <text x={PAD.left - 6} y={y(t) + 3} textAnchor="end" fontSize="9" fill="#64748b">
                  {t}
                </text>
              </g>
            ))}
            {chart.hours.map((h, i) =>
              i % 2 === 0 ? (
                <text
                  key={h}
                  x={PAD.left + (i / (chart.hours.length - 1)) * plotW}
                  y={H - 8}
                  textAnchor="middle"
                  fontSize="9"
                  fill="#64748b"
                >
                  {h}
                </text>
              ) : null,
            )}
            {chart.series.map((s) => (
              <polyline
                key={s.code}
                fill="none"
                stroke={s.color}
                strokeWidth="1.6"
                strokeLinejoin="round"
                points={s.data
                  .map((v, i) => `${PAD.left + (i / (s.data.length - 1)) * plotW},${y(v)}`)
                  .join(" ")}
              />
            ))}
          </svg>
        </>
      )}
    </Panel>
  );
};

export default WaterLevelChart;
