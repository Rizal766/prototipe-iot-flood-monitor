import Panel from "./Panel";
import { useLocationWeather } from "@/hooks/useLocationWeather";

const WeatherForecast = () => {
  const { weather: w, place, isLoading, isError } = useLocationWeather();
  return (
    <Panel
      title={
        <>
          Cuaca & Prediksi <span className="font-normal text-slate-500">· {place}</span>
        </>
      }
    >
      {isLoading && <p className="m-0 text-xs text-slate-400">Memuat cuaca…</p>}
      {isError && <p className="m-0 text-xs text-red-500">Cuaca tidak tersedia saat ini</p>}
      {w && (
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-4xl leading-none" aria-hidden="true">{w.icon}</span>
            <div>
              <p className="m-0 text-2xl font-bold leading-none">{w.temperature}°C</p>
              <p className="m-0 text-xs text-slate-500">{w.condition}</p>
            </div>
          </div>
          <div className="min-w-0 flex-1 border-l border-slate-300 pl-3">
            <p className="m-0 mb-1 text-xs font-semibold">Prediksi 3 hari</p>
            <ul className="m-0 flex list-none flex-col gap-0.5 p-0 text-[11px] text-slate-600">
              {w.forecast.map((d) => (
                <li key={d.label} className="flex items-center justify-between gap-2">
                  <span>
                    {d.icon} {d.label}
                  </span>
                  <span className="font-semibold">{d.chance}%</span>
                  <span>{d.temp}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </Panel>
  );
};

export default WeatherForecast;
