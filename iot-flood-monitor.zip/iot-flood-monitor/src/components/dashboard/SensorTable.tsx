import { useState } from "react";
import { DataGrid, type GridColDef } from "@mui/x-data-grid";
import { Pagination } from "antd";
import Panel from "./Panel";
import { useSensors } from "@/hooks/useSensors";
import { useSensorStore } from "@/stores/useSensorStore";
import { FloodStatus, type ISensor } from "@/types/sensor";
import { STATUS_META } from "@/utils/status";

const Dot = ({ color }: { color: string }) => (
  <span className="mr-1.5 inline-block h-2.5 w-2.5 rounded-full" style={{ background: color }} />
);

const columns: GridColDef<ISensor>[] = [
  {
    field: "code",
    headerName: "ID Sensor",
    width: 105,
    renderCell: (p) => (
      <span>
        <Dot color={STATUS_META[p.row.status].color} />
        {p.row.code}
      </span>
    ),
  },
  { field: "location", headerName: "Lokasi", flex: 1, minWidth: 140 },
  { field: "waterLevel", headerName: "Tinggi air", width: 90, valueFormatter: (v: number) => `${v}cm` },
  {
    field: "status",
    headerName: "Status",
    width: 100,
    renderCell: (p) => (
      <span>
        <Dot color={STATUS_META[p.row.status].color} />
        {p.row.status === FloodStatus.AMAN ? "Normal" : STATUS_META[p.row.status].label}
      </span>
    ),
  },
  { field: "battery", headerName: "Baterai", width: 80, valueFormatter: (v: number) => `${v}%` },
  { field: "updatedAt", headerName: "Terakhir Update", width: 120 },
];

const PAGE_SIZE = 6;

const SensorTable = () => {
  const [page, setPage] = useState(1);
  const { data, isLoading } = useSensors({ page, limit: PAGE_SIZE });
  const selectSensor = useSensorStore((s) => s.selectSensor);
  const total = data?.meta?.totalData ?? 0;
  const shown = data?.meta?.totalDataPerPage ?? 0;

  return (
    <Panel title="Daftar sensor" className="h-full">
      <div className="h-[330px] w-full">
        <DataGrid
          rows={data?.data ?? []}
          columns={columns}
          loading={isLoading}
          rowHeight={44}
          columnHeaderHeight={40}
          hideFooter
          disableColumnMenu
          disableRowSelectionOnClick
          onRowClick={(p) => selectSensor(p.row.id)}
          sx={{ border: 0, fontSize: 12 }}
        />
      </div>
      <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500">
        <span>
          Menampilkan {shown} dari {total} sensor
        </span>
        <Pagination size="small" current={page} pageSize={PAGE_SIZE} total={total} showSizeChanger={false} onChange={setPage} />
      </div>
    </Panel>
  );
};

export default SensorTable;
