import { memo, type ReactNode } from "react";

interface IStatCardProps {
  icon: ReactNode;
  iconClassName: string;
  label: string;
  value: ReactNode;
  footer: ReactNode;
}

// Section 4: Memoize
const StatCard = memo(function StatCard({ icon, iconClassName, label, value, footer }: IStatCardProps) {
  return (
    <div className="flex items-center gap-3 rounded-lg border border-slate-200 bg-white p-3 shadow-sm">
      <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-lg text-2xl ${iconClassName}`}>
        {icon}
      </div>
      <div className="min-w-0">
        <p className="text-xs text-slate-500">{label}</p>
        <p className="text-2xl font-bold leading-tight text-slate-800">{value}</p>
        <p className="truncate text-[11px] text-slate-500">{footer}</p>
      </div>
    </div>
  );
});

export default StatCard;
