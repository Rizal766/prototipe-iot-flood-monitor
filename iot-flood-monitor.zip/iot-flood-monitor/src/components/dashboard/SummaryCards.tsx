import { AlertFilled, CloudFilled, DatabaseFilled, ThunderboltFilled } from "@ant-design/icons";
import StatCard from "./StatCard";
import { useSummary } from "@/hooks/useDashboard";

const SummaryCards = () => {
  const { data } = useSummary();
  const s = data?.data;
  if (!s) return <div className="h-20 animate-pulse rounded-lg bg-slate-200" />;

  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
      <StatCard
        icon={<DatabaseFilled />}
        iconClassName="bg-sky-100 text-sky-500"
        label="Total sensor"
        value={s.totalSensor}
        footer={
          <>
            <span className="text-green-600">Aktif {s.activeSensor}</span> /{" "}
            <span className="text-slate-400">Offline {s.offlineSensor}</span>
          </>
        }
      />
      <StatCard
        icon={<AlertFilled />}
        iconClassName="bg-red-100 text-red-500"
        label="Lokasi berisiko"
        value={s.riskLocations}
        footer={
          <>
            <span className="text-red-500">Siaga {s.siaga}</span> ·{" "}
            <span className="text-amber-500">Waspada {s.waspada}</span> ·{" "}
            <span className="text-green-600">Aman {s.aman}</span>
          </>
        }
      />
      <StatCard
        icon={<CloudFilled />}
        iconClassName="bg-green-100 text-green-600"
        label="Curah hujan (24 Jam)"
        value={`${s.rainfall}mm`}
        footer={<span className="text-green-600">↑{s.rainfallChange}% Dari Kemarin</span>}
      />
      <StatCard
        icon={<ThunderboltFilled />}
        iconClassName="bg-sky-100 text-sky-600"
        label="Tinggi muka air"
        value={`${s.waterLevel}cm`}
        footer={<span className="text-green-600">↑{s.waterLevelChange}% Dari Kemarin</span>}
      />
    </div>
  );
};

export default SummaryCards;
