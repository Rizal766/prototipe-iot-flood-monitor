import type { ReactNode } from "react";
import {
  ApiOutlined,
  BellFilled,
  MailFilled,
  MessageFilled,
  SoundFilled,
  WhatsAppOutlined,
} from "@ant-design/icons";
import Panel from "./Panel";
import { useIntegrations } from "@/hooks/useDashboard";
import { IntegrationType } from "@/types/dashboard";

const ICONS: Record<IntegrationType, ReactNode> = {
  [IntegrationType.SMS]: <MessageFilled className="text-sky-500" />,
  [IntegrationType.WHATSAPP]: <WhatsAppOutlined className="text-green-500" />,
  [IntegrationType.EMAIL]: <MailFilled className="text-blue-500" />,
  [IntegrationType.PUSH]: <BellFilled className="text-orange-500" />,
  [IntegrationType.SIREN]: <SoundFilled className="text-amber-500" />,
  [IntegrationType.API]: <ApiOutlined className="text-sky-600" />,
};

const IntegrationList = () => {
  const { data } = useIntegrations();
  return (
    <Panel title="Notifikasi & Integrasi" className="h-full">
      <ul className="m-0 flex list-none flex-col gap-1.5 p-0">
        {(data?.data ?? []).map((i) => (
          <li key={i.type} className="flex items-center gap-2 rounded-md border border-slate-100 px-2 py-1.5 text-xs">
            <span className="text-lg">{ICONS[i.type]}</span>
            <span className="flex-1 font-medium text-slate-700">{i.name}</span>
            <span className={`font-semibold ${i.active ? "text-green-600" : "text-slate-400"}`}>
              {i.active ? "aktif" : "nonaktif"}
            </span>
          </li>
        ))}
      </ul>
    </Panel>
  );
};

export default IntegrationList;
