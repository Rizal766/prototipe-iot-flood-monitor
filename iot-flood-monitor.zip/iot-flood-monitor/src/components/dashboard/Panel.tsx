import type { ReactNode } from "react";

interface IPanelProps {
  title: ReactNode;
  children: ReactNode;
  className?: string;
  actions?: ReactNode; // kontrol di sisi kanan judul
}

const Panel = ({ title, children, className = "", actions }: IPanelProps) => (
  <section className={`flex min-w-0 flex-col rounded-lg border border-slate-200 bg-white p-3 shadow-sm ${className}`}>
    <div className="mb-2 flex min-h-6 items-center justify-between gap-2">
      <h2 className="m-0 text-sm font-semibold text-slate-800">{title}</h2>
      {actions}
    </div>
    {children}
  </section>
);

export default Panel;
