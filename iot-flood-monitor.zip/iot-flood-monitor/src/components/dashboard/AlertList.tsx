import { memo } from "react";
import { WarningFilled } from "@ant-design/icons";
import Panel from "./Panel";
import { useAlerts } from "@/hooks/useDashboard";
import { FloodStatus } from "@/types/sensor";
import type { IAlert } from "@/types/dashboard";
import { STATUS_META } from "@/utils/status";

const AlertItem = memo(function AlertItem({ alert }: { alert: IAlert }) {
  const color = STATUS_META[alert.level].color;
  const label = alert.level === FloodStatus.AMAN ? "Normal" : STATUS_META[alert.level].label;
  return (
    <li className="flex items-center gap-2 rounded-md border border-slate-100 border-l-4 bg-white p-2 shadow-sm" style={{ borderLeftColor: color }}>
      <WarningFilled className="text-xl" style={{ color }} />
      <div className="min-w-0 flex-1 text-[11px] leading-tight">
        <p className="m-0 font-medium text-slate-800">
          Sensor #{alert.sensorCode} - {alert.location}
        </p>
        <p className="m-0 text-slate-500">{alert.message}</p>
      </div>
      <div className="flex shrink-0 flex-col items-end gap-1">
        <span className="text-[10px] text-slate-500">{alert.time}</span>
        <span className="rounded px-1.5 py-0.5 text-[10px] font-semibold text-white" style={{ background: color }}>
          {label}
        </span>
      </div>
    </li>
  );
});

const AlertList = () => {
  const { data } = useAlerts();
  return (
    <Panel title={<span className="text-red-500"><WarningFilled /> Alert Terbaru</span>} className="h-full">
      <ul className="m-0 flex list-none flex-col gap-2 p-0">
        {(data?.data ?? []).map((a) => (
          <AlertItem key={a.id} alert={a} />
        ))}
      </ul>
    </Panel>
  );
};

export default AlertList;
