import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import Panel from "./Panel";
import SensorMap from "@/components/map/SensorMap";
import { useEvacuationPoints } from "@/hooks/useMapData";
import { useSensors } from "@/hooks/useSensors";
import { useSensorStore } from "@/stores/useSensorStore";
import { FloodStatus } from "@/types/sensor";
import { STATUS_META, STATUS_SEVERITY } from "@/utils/status";

const LEGEND: FloodStatus[] = [
  FloodStatus.AMAN,
  FloodStatus.WASPADA,
  FloodStatus.SIAGA,
  FloodStatus.BAHAYA,
  FloodStatus.OFFLINE,
];

const MonitoringMap = () => {
  const navigate = useNavigate();
  const { data } = useSensors({ page: 1, limit: 100 });
  const { data: evac } = useEvacuationPoints();
  const selectedId = useSensorStore((s) => s.selectedSensorId);
  const selectSensor = useSensorStore((s) => s.selectSensor);
  const sensors = useMemo(() => data?.data ?? [], [data]);

  const selected = useMemo(
    () =>
      sensors.find((s) => s.id === selectedId) ??
      [...sensors].sort((a, b) => STATUS_SEVERITY[b.status] - STATUS_SEVERITY[a.status])[0],
    [sensors, selectedId],
  );

  return (
    <Panel title="Peta Monitoring Lokasi" className="h-full">
      <div className="relative isolate min-h-[320px] flex-1 overflow-hidden rounded-md border-2 border-sky-500 bg-slate-200">
        <div className="absolute inset-0">
          <SensorMap
            sensors={sensors}
            selectedId={selected?.id ?? null}
            onSelect={selectSensor}
            evacuation={evac?.data?.filter((e) => e.active)}
            onDetail={() => navigate("/peta")}
          />
        </div>
        <ul className="absolute left-2 top-2 z-[1000] m-0 list-none rounded bg-slate-900/80 p-2 text-[11px] text-white">
          {LEGEND.map((st) => (
            <li key={st} className="flex items-center gap-1.5 leading-5">
              <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ background: STATUS_META[st].color }} />
              {st === FloodStatus.AMAN ? "Normal" : STATUS_META[st].label}
            </li>
          ))}
        </ul>
      </div>
    </Panel>
  );
};

export default MonitoringMap;
