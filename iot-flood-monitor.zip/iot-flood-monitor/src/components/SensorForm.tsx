import { Button, Input } from "antd";
import { Controller, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { sensorSchema, type SensorFormValues } from "@/schemas/sensorSchema";

interface ISensorFormProps {
  defaultValues?: Partial<SensorFormValues>;
  submitLabel?: string;
  loading?: boolean;
  lockCode?: boolean;
  onSubmit: (values: SensorFormValues) => void;
}

const FIELDS: { name: keyof SensorFormValues; label: string; placeholder: string }[] = [
  { name: "code", label: "Kode Sensor", placeholder: "BNA-003" },
  { name: "location", label: "Nama Lokasi", placeholder: "Kali Banjir Kanal Barat" },
  { name: "river", label: "Sungai", placeholder: "Banjir Kanal Barat" },
  { name: "district", label: "Kecamatan", placeholder: "Semarang Barat" },
  { name: "lat", label: "Latitude", placeholder: "-6.9855" },
  { name: "lng", label: "Longitude", placeholder: "110.3905" },
];

const SensorForm = ({ defaultValues, submitLabel = "Simpan", loading, lockCode, onSubmit }: ISensorFormProps) => {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<SensorFormValues>({
    resolver: zodResolver(sensorSchema),
    defaultValues: { code: "", location: "", river: "", district: "", lat: "", lng: "", ...defaultValues },
  });

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="grid grid-cols-1 gap-3 sm:grid-cols-2">
      {FIELDS.map((f) => (
        <div key={f.name} className={f.name === "location" ? "sm:col-span-2" : ""}>
          <label htmlFor={`sensor-${f.name}`} className="mb-1 block text-xs font-medium text-slate-600">
            {f.label}
          </label>
          <Controller
            name={f.name}
            control={control}
            render={({ field }) => (
              <Input
                {...field}
                id={`sensor-${f.name}`}
                placeholder={f.placeholder}
                disabled={f.name === "code" && lockCode}
                status={errors[f.name] ? "error" : undefined}
              />
            )}
          />
          {errors[f.name] && <p className="m-0 mt-0.5 text-xs text-red-500">{errors[f.name]?.message}</p>}
        </div>
      ))}
      <div className="sm:col-span-2">
        <Button type="primary" htmlType="submit" loading={loading} block>
          {submitLabel}
        </Button>
      </div>
    </form>
  );
};

export default SensorForm;
