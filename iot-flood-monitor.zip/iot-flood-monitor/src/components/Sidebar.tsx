import { useState, type ReactNode } from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { Badge } from "antd";
import {
  BellOutlined,
  ControlOutlined,
  DashboardOutlined,
  DownOutlined,
  EnvironmentOutlined,
  FileTextOutlined,
  HistoryOutlined,
  PhoneOutlined,
  SafetyOutlined,
  SettingOutlined,
  TeamOutlined,
  ToolOutlined,
  UpOutlined,
  WifiOutlined,
} from "@ant-design/icons";
import { useNotifications } from "@/hooks/useNotifications";
import { usePermissions } from "@/hooks/usePermissions";
import { Feature } from "@/types/permission";
import { AlertStatus } from "@/types/notification";

interface IMenuItem {
  to: string;
  label: string;
  icon: ReactNode;
  badge?: boolean;
  feature?: Feature;
}

const MENU: IMenuItem[] = [
  { to: "/", label: "Dashboard", icon: <DashboardOutlined />, feature: Feature.DASHBOARD_PETA },
  { to: "/peta", label: "Peta Monitoring", icon: <EnvironmentOutlined />, feature: Feature.DASHBOARD_PETA },
  { to: "/sensors", label: "Data sensor", icon: <WifiOutlined />, feature: Feature.SENSOR },
  { to: "/riwayat", label: "Riwayat Data", icon: <HistoryOutlined />, feature: Feature.RIWAYAT },
  { to: "/notifikasi", label: "Notifikasi & Alert", icon: <BellOutlined />, badge: true, feature: Feature.NOTIFIKASI },
  { to: "/laporan", label: "Laporan", icon: <FileTextOutlined />, feature: Feature.LAPORAN },
];

const SETTINGS: IMenuItem[] = [
  { to: "/pengaturan/perangkat", label: "Kelola Perangkat", icon: <ToolOutlined /> },
  { to: "/pengaturan/ambang", label: "Ambang batas & Aturan Alert", icon: <ControlOutlined /> },
  { to: "/pengaturan/pengguna", label: "Pengguna & Role", icon: <TeamOutlined /> },
  { to: "/pengaturan/saluran", label: "Saluran Notifikasi & Kontak darurat", icon: <PhoneOutlined /> },
  { to: "/pengaturan/profil", label: "Profil & Keamanan", icon: <SafetyOutlined /> },
];

const Sidebar = ({ onNavigate }: { onNavigate?: () => void }) => {
  const { can } = usePermissions();
  const { data } = useNotifications();
  // jumlah alert yang belum ditangani; berkurang saat alert diproses/selesai
  const unhandled = (data?.data ?? []).filter((n) => n.status === AlertStatus.BELUM).length;

  const { pathname } = useLocation();
  const navigate = useNavigate();
  const inSettings = pathname.startsWith("/pengaturan");
  const [manual, setManual] = useState<boolean | null>(null);
  const expanded = manual ?? inSettings;

  const toggleSettings = () => {
    const next = !expanded;
    setManual(next);
    if (next && !inSettings) {
      navigate("/pengaturan/perangkat");
      onNavigate?.();
    }
  };

  return (
    <div className="flex h-full flex-col gap-1 overflow-y-auto p-3">
      <nav className="flex flex-col gap-1">
        {MENU.filter((m) => !m.feature || can(m.feature)).map((m) => (
          <NavLink
            key={m.to}
            to={m.to}
            end={m.to === "/"}
            onClick={onNavigate}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium no-underline transition-colors ${
                isActive ? "bg-blue-600 text-white" : "text-slate-700 hover:bg-slate-100"
              }`
            }
          >
            <span className="text-lg">{m.icon}</span>
            <span className="flex-1">{m.label}</span>
            {m.badge && unhandled > 0 && <Badge count={unhandled} size="small" overflowCount={99} />}
          </NavLink>
        ))}

        {can(Feature.PENGATURAN) && (
        <button
          type="button"
          aria-expanded={expanded}
          onClick={toggleSettings}
          className={`flex w-full cursor-pointer items-center gap-3 rounded-md border-none px-3 py-2.5 text-left text-sm font-medium transition-colors ${
            inSettings ? "bg-blue-600 text-white" : "bg-transparent text-slate-700 hover:bg-slate-100"
          }`}
        >
          <span className="text-lg">
            <SettingOutlined />
          </span>
          <span className="flex-1">Pengaturan</span>
          <span className="text-[10px]">{expanded ? <UpOutlined /> : <DownOutlined />}</span>
        </button>
        )}

        {can(Feature.PENGATURAN) && expanded && (
          <div className="ml-3 flex flex-col gap-0.5 border-l border-slate-200 pl-2">
            {SETTINGS.map((m) => (
              <NavLink
                key={m.to}
                to={m.to}
                onClick={onNavigate}
                className={({ isActive }) =>
                  `flex items-center gap-2.5 rounded-md px-2.5 py-2 text-xs font-medium no-underline transition-colors ${
                    isActive ? "bg-blue-50 text-blue-700" : "text-slate-600 hover:bg-slate-100"
                  }`
                }
              >
                <span className="text-base">{m.icon}</span>
                <span className="leading-tight">{m.label}</span>
              </NavLink>
            ))}
          </div>
        )}
      </nav>

      <div className="mt-auto hidden min-h-40 overflow-hidden rounded-md bg-gradient-to-b from-slate-600 to-slate-900 p-3 text-white lg:flex lg:flex-col lg:justify-end">
        <p className="m-0 text-xs font-semibold leading-snug">Bersama Teknologi, Kita Lebih Siap Menghadapi Banjir</p>
        <p className="m-0 mt-1 text-[10px] text-slate-300">IoT for a Safer Tomorrow</p>
      </div>
    </div>
  );
};

export default Sidebar;
