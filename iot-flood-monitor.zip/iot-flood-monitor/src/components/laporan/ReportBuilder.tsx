import { useMemo } from "react";
import { Button, Checkbox, DatePicker, Input, Select, Spin, Switch, message } from "antd";
import { Controller, useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import dayjs from "dayjs";
import { z } from "zod";
import Panel from "@/components/dashboard/Panel";
import { useReportData } from "@/hooks/useReportData";
import { useReportDownload } from "@/hooks/useReportDownload";
import { useReportMutations } from "@/hooks/useReports";
import { useAuthStore } from "@/stores/useAuthStore";
import {
  FREQUENCY_LABEL,
  REPORT_TYPE_LABEL,
  ReportType,
  ScheduleFrequency,
  type IReport,
  type IReportParams,
} from "@/types/report";
import type { ISensor } from "@/types/sensor";
import { presetForType, resolveScope } from "@/utils/reportScope";
import { ReportPreview } from "./ReportPreview";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const reportFormSchema = z
  .object({
    type: z.nativeEnum(ReportType),
    from: z.string().min(1, "Periode wajib diisi"),
    to: z.string().min(1, "Periode wajib diisi"),
    scope: z.array(z.string()),
    summary: z.boolean(),
    charts: z.boolean(),
    alerts: z.boolean(),
    problemSensors: z.boolean(),
    scheduleEnabled: z.boolean(),
    frequency: z.nativeEnum(ScheduleFrequency),
    email: z.string(),
  })
  .superRefine((v, ctx) => {
    if (!(v.summary || v.charts || v.alerts || v.problemSensors)) {
      ctx.addIssue({ code: "custom", path: ["summary"], message: "Pilih minimal satu isi laporan" });
    }
    if (new Date(v.to).getTime() < new Date(v.from).getTime()) {
      ctx.addIssue({ code: "custom", path: ["to"], message: "Periode akhir harus setelah periode awal" });
    }
    if (v.scheduleEnabled) {
      if (v.frequency === ScheduleFrequency.NONE) {
        ctx.addIssue({ code: "custom", path: ["frequency"], message: "Pilih frekuensi pengiriman" });
      }
      if (!EMAIL_RE.test(v.email)) {
        ctx.addIssue({ code: "custom", path: ["email"], message: "Email tujuan tidak valid" });
      }
    }
  });

type ReportFormValues = z.infer<typeof reportFormSchema>;

const defaultsFor = (t: IReport | null): ReportFormValues => {
  if (!t) {
    const r = presetForType(ReportType.HARIAN);
    return {
      type: ReportType.HARIAN,
      from: r.from,
      to: r.to,
      scope: [],
      summary: true,
      charts: true,
      alerts: true,
      problemSensors: true,
      scheduleEnabled: false,
      frequency: ScheduleFrequency.NONE,
      email: "",
    };
  }
  return {
    type: t.type,
    from: t.from,
    to: t.to,
    scope: t.sensorIds ? t.sensorIds.map((id) => `s:${id}`) : [],
    ...t.includes,
    scheduleEnabled: Boolean(t.schedule),
    frequency: t.schedule?.frequency ?? ScheduleFrequency.NONE,
    email: t.schedule?.email ?? "",
  };
};

const CONTENT_OPTIONS: { key: "summary" | "charts" | "alerts" | "problemSensors"; label: string }[] = [
  { key: "summary", label: "Ringkasan status" },
  { key: "charts", label: "Grafik" },
  { key: "alerts", label: "Daftar alert & waktu respons" },
  { key: "problemSensors", label: "Sensor bermasalah" },
];

interface IReportBuilderProps {
  sensors: ISensor[];
  template: IReport | null;
  onPreview: (params: IReportParams) => void;
}

const ReportBuilder = ({ sensors, template, onPreview }: IReportBuilderProps) => {
  const user = useAuthStore((s) => s.user);
  const creator = user?.name ?? "Admin";
  const { create } = useReportMutations();
  const { download, busy } = useReportDownload();

  const { control, handleSubmit, setValue, reset, trigger, formState: { errors } } = useForm<ReportFormValues>({
    resolver: zodResolver(reportFormSchema),
    defaultValues: defaultsFor(template),
  });
  const v = useWatch({ control });

  const scopeOptions = useMemo(() => {
    const districts = [...new Set(sensors.map((s) => s.district))].sort();
    return [
      { label: "Kecamatan", options: districts.map((d) => ({ value: `d:${d}`, label: d })) },
      { label: "Sensor", options: sensors.map((s) => ({ value: `s:${s.id}`, label: `${s.code} - ${s.location}` })) },
    ];
  }, [sensors]);

  const anyContent = Boolean(v.summary || v.charts || v.alerts || v.problemSensors);
  const params = useMemo<IReportParams | null>(() => {
    if (!v.from || !v.to || !anyContent) return null;
    const scope = resolveScope((v.scope ?? []).filter((x): x is string => Boolean(x)), sensors);
    return {
      type: v.type ?? ReportType.HARIAN,
      from: v.from,
      to: v.to,
      sensorIds: scope.ids,
      areaLabel: scope.label,
      includes: {
        summary: Boolean(v.summary),
        charts: Boolean(v.charts),
        alerts: Boolean(v.alerts),
        problemSensors: Boolean(v.problemSensors),
      },
    };
  }, [v.type, v.from, v.to, v.scope, v.summary, v.charts, v.alerts, v.problemSensors, anyContent, sensors]);

  const { data: previewData, isLoading: previewLoading, isError: previewError, refetch: refetchPreview } = useReportData(params, creator);

  const setType = (t: ReportType) => {
    setValue("type", t);
    const r = presetForType(t);
    setValue("from", r.from);
    setValue("to", r.to);
  };

  const onValid = async (values: ReportFormValues) => {
    if (!params) return;
    try {
      const res = await create.mutateAsync({
        ...params,
        schedule:
          values.scheduleEnabled && values.frequency !== ScheduleFrequency.NONE
            ? { frequency: values.frequency, email: values.email }
            : null,
      });
      // form hanya dikosongkan bila server benar-benar menerima laporan
      if (res.status) reset(defaultsFor(null));
    } catch {
      // pesan kesalahan sudah ditampilkan oleh hook useReportMutations
    }
  };

  const withValid = async (action: (p: IReportParams) => void) => {
    const ok = await trigger();
    const p = ok ? params : null;
    if (!p) {
      message.error("Lengkapi form laporan terlebih dahulu");
      return;
    }
    action(p);
  };

  const err = (msg?: string) => (msg ? <p className="m-0 mt-0.5 text-[11px] text-red-500">{msg}</p> : null);
  const scheduleOn = Boolean(v.scheduleEnabled);

  return (
    <Panel title={<span className="text-base">Buat Laporan</span>}>
      <form id="report-builder" onSubmit={handleSubmit(onValid)} noValidate className="flex flex-col gap-4 text-xs">
        <section>
          <h3 className="m-0 mb-1.5 text-xs font-semibold">1. Jenis Laporan</h3>
          <div className="grid grid-cols-2 gap-1.5">
            {Object.values(ReportType).map((t) => (
              <button
                key={t}
                type="button"
                aria-pressed={v.type === t}
                onClick={() => setType(t)}
                className={`cursor-pointer rounded-md border px-2 py-1.5 text-xs font-medium ${
                  v.type === t ? "border-blue-600 bg-blue-50 text-blue-700" : "border-slate-200 bg-white text-slate-700"
                }`}
              >
                {t === ReportType.KEJADIAN ? "Laporan Kejadian" : REPORT_TYPE_LABEL[t]}
              </button>
            ))}
          </div>
        </section>

        <section>
          <h3 className="m-0 mb-1.5 text-xs font-semibold">2. Periode</h3>
          <DatePicker.RangePicker
            className="w-full"
            value={v.from && v.to ? [dayjs(v.from), dayjs(v.to)] : null}
            allowClear={false}
            disabledDate={(d) => d.isAfter(dayjs(), "day")}
            onChange={(r) => {
              if (r && r[0] && r[1]) {
                const end = r[1].endOf("day");
                setValue("from", r[0].startOf("day").toISOString(), { shouldValidate: true });
                setValue("to", (end.isAfter(dayjs()) ? dayjs() : end).toISOString(), { shouldValidate: true });
              }
            }}
          />
          {err(errors.to?.message ?? errors.from?.message)}
        </section>

        <section>
          <h3 className="m-0 mb-1.5 text-xs font-semibold">3. Wilayah / Sensor</h3>
          <Controller
            name="scope"
            control={control}
            render={({ field }) => (
              <Select
                {...field}
                mode="multiple"
                className="w-full"
                placeholder="Semarang (Semua)"
                maxTagCount="responsive"
                optionFilterProp="label"
                options={scopeOptions}
              />
            )}
          />
        </section>

        <section>
          <h3 className="m-0 mb-1.5 text-xs font-semibold">4. Isi yang Disertakan</h3>
          <div className="flex flex-col gap-1">
            {CONTENT_OPTIONS.map((o) => (
              <Controller
                key={o.key}
                name={o.key}
                control={control}
                render={({ field }) => (
                  <Checkbox checked={field.value} onChange={(e) => field.onChange(e.target.checked)}>
                    {o.label}
                  </Checkbox>
                )}
              />
            ))}
          </div>
          {err(errors.summary?.message)}
        </section>

        <section>
          <h3 className="m-0 mb-1.5 text-xs font-semibold">5. Jadwalkan (Opsional)</h3>
          <Controller
            name="scheduleEnabled"
            control={control}
            render={({ field }) => (
              <label className="mb-2 flex items-center gap-2">
                <Switch size="small" checked={field.value} onChange={field.onChange} />
                Kirim otomatis via email
              </label>
            )}
          />
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-1">
            <div>
              <p className="m-0 mb-0.5 text-slate-500">Frekuensi</p>
              <Controller
                name="frequency"
                control={control}
                render={({ field }) => (
                  <Select
                    {...field}
                    className="w-full"
                    disabled={!scheduleOn}
                    options={Object.values(ScheduleFrequency).map((f) => ({ value: f, label: FREQUENCY_LABEL[f] }))}
                  />
                )}
              />
              {err(errors.frequency?.message)}
            </div>
            <div>
              <p className="m-0 mb-0.5 text-slate-500">Email tujuan</p>
              <Controller
                name="email"
                control={control}
                render={({ field }) => (
                  <Input {...field} type="email" disabled={!scheduleOn} placeholder="Pisahkan dengan koma" />
                )}
              />
              {err(errors.email?.message)}
            </div>
          </div>
          {scheduleOn && (
            <p className="m-0 mt-1 text-[10px] text-slate-400">
              Pengiriman email dijalankan oleh server; di mode contoh jadwal hanya disimpan.
            </p>
          )}
        </section>

        <div className="grid grid-cols-2 gap-2">
          <Button onClick={() => reset(defaultsFor(null))}>Batal</Button>
          <Button type="primary" htmlType="submit" loading={create.isPending}>
            Buat Laporan
          </Button>
        </div>
      </form>

      <div className="mt-4 rounded-md border border-slate-200 bg-slate-50 p-2">
        {params === null ? (
          <p className="m-0 py-6 text-center text-xs text-slate-400">Pilih isi laporan untuk melihat pratinjau</p>
        ) : previewError && !previewData ? (
          <div className="flex flex-col items-center gap-2 py-6 text-xs">
            <p className="m-0 text-red-500">Pratinjau gagal dimuat.</p>
            <Button size="small" onClick={() => void refetchPreview()}>
              Coba lagi
            </Button>
          </div>
        ) : previewLoading || !previewData ? (
          <Spin className="block py-8" />
        ) : (
          <ReportPreview data={previewData} compact />
        )}
        <div className="mt-2 grid grid-cols-3 gap-1.5">
          <Button size="small" onClick={() => void withValid(onPreview)}>
            Preview
          </Button>
          <Button
            size="small"
            danger
            type="primary"
            loading={busy === "draft-pdf"}
            onClick={() => void withValid((p) => void download("draft", p, "pdf", creator))}
          >
            Unduh PDF
          </Button>
          <Button
            size="small"
            type="primary"
            className="!bg-green-600 hover:!bg-green-700"
            loading={busy === "draft-xlsx"}
            onClick={() => void withValid((p) => void download("draft", p, "xlsx", creator))}
          >
            Unduh Excel
          </Button>
        </div>
      </div>
    </Panel>
  );
};

export default ReportBuilder;
