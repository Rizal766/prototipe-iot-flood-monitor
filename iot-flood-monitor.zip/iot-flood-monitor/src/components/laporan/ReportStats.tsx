import { memo, type ReactNode } from "react";
import { CalendarOutlined, FileTextOutlined, ProfileOutlined, WarningFilled } from "@ant-design/icons";
import { ReportType, type IReport } from "@/types/report";

interface IStatDef {
  label: string;
  icon: ReactNode;
  color: string;
  filter: (r: IReport) => boolean;
}

const DEFS: IStatDef[] = [
  { label: "Total Laporan", icon: <FileTextOutlined />, color: "#2563eb", filter: () => true },
  { label: "Laporan Bulanan", icon: <CalendarOutlined />, color: "#0f172a", filter: (r) => r.type === ReportType.BULANAN },
  { label: "Laporan Kejadian", icon: <WarningFilled />, color: "#f59e0b", filter: (r) => r.type === ReportType.KEJADIAN },
  { label: "Laporan Harian", icon: <ProfileOutlined />, color: "#0f172a", filter: (r) => r.type === ReportType.HARIAN },
];

// Perubahan jumlah laporan dibuat bulan ini dibanding bulan lalu
const delta = (reports: IReport[]): number | null => {
  const now = new Date();
  const month = (r: IReport) => {
    const d = new Date(r.createdAt);
    return (now.getFullYear() - d.getFullYear()) * 12 + (now.getMonth() - d.getMonth());
  };
  const cur = reports.filter((r) => month(r) === 0).length;
  const prev = reports.filter((r) => month(r) === 1).length;
  return prev === 0 ? null : Math.round(((cur - prev) / prev) * 100);
};

const StatCard = memo(function StatCard({ def, reports }: { def: IStatDef; reports: IReport[] }) {
  const subset = reports.filter(def.filter);
  const d = delta(subset);
  return (
    <div className="flex items-center gap-3 rounded-lg border border-slate-200 bg-white p-3 shadow-sm">
      <span className="text-3xl" style={{ color: def.color }}>
        {def.icon}
      </span>
      <div>
        <p className="m-0 text-xs text-slate-600">{def.label}</p>
        <p className="m-0 text-2xl font-bold leading-tight">{subset.length}</p>
        <p className={`m-0 text-[11px] ${d === null ? "text-slate-400" : d >= 0 ? "text-green-600" : "text-red-500"}`}>
          {d === null ? "Belum ada pembanding" : `${d >= 0 ? "↑" : "↓"} ${Math.abs(d)}% dari bulan lalu`}
        </p>
      </div>
    </div>
  );
});

const ReportStats = ({ reports }: { reports: IReport[] }) => (
  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
    {DEFS.map((d) => (
      <StatCard key={d.label} def={d} reports={reports} />
    ))}
  </div>
);

export default ReportStats;
