import { Button, Progress } from "antd";
import { CloseCircleFilled, FileTextOutlined, LoadingOutlined } from "@ant-design/icons";
import Panel from "@/components/dashboard/Panel";
import { ROLE_LABEL } from "@/types/auth";
import { ReportStatus, type IReport } from "@/types/report";
import { formatDateTime } from "@/utils/time";

interface IReportBottomCardsProps {
  reports: IReport[];
  onCreate: () => void;
  onRetry: (id: number) => void;
}

const ReportBottomCards = ({ reports, onCreate, onRetry }: IReportBottomCardsProps) => {
  const processing = reports.filter((r) => r.status === ReportStatus.PROSES);
  const failed = reports.filter((r) => r.status === ReportStatus.GAGAL);
  const latest = reports.find((r) => r.status === ReportStatus.SELESAI);

  return (
    <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
      <Panel title="Laporan terakhir">
        <div className="flex flex-col items-center gap-2 py-2 text-center text-xs">
          <FileTextOutlined className="text-4xl text-slate-600" />
          {latest ? (
            <>
              <p className="m-0 font-semibold">{latest.name}</p>
              <p className="m-0 text-slate-500">Dibuat {formatDateTime(latest.createdAt)}</p>
            </>
          ) : (
            <>
              <p className="m-0 font-semibold">Belum ada laporan</p>
              <p className="m-0 text-slate-500">Mulai dengan membuat laporan pertama Anda</p>
            </>
          )}
          <Button type="primary" onClick={onCreate}>
            + Buat Laporan
          </Button>
        </div>
      </Panel>

      <Panel title="Laporan Sedang Dibuat">
        {processing.length === 0 ? (
          <p className="m-0 py-4 text-center text-xs text-slate-400">Tidak ada laporan yang sedang dibuat</p>
        ) : (
          <ul className="m-0 flex list-none flex-col gap-3 p-0">
            {processing.map((r) => (
              <li key={r.id} className="text-xs">
                <div className="flex items-start gap-2">
                  <LoadingOutlined className="mt-0.5 text-lg text-blue-600" spin />
                  <div className="min-w-0 flex-1">
                    <p className="m-0 font-medium">{r.name}</p>
                    <p className="m-0 text-slate-500">Sedang diproses... {r.progress}%</p>
                  </div>
                </div>
                <Progress percent={r.progress} size="small" showInfo={false} />
                <p className="m-0 text-[11px] text-slate-500">
                  Dibuat oleh {r.createdBy} ({ROLE_LABEL[r.creatorRole]}) · Mulai {formatDateTime(r.createdAt)}
                </p>
              </li>
            ))}
          </ul>
        )}
      </Panel>

      <Panel title={<span className="text-red-500">Laporan Gagal</span>}>
        {failed.length === 0 ? (
          <p className="m-0 py-4 text-center text-xs text-slate-400">Tidak ada laporan gagal</p>
        ) : (
          <ul className="m-0 flex list-none flex-col gap-3 p-0">
            {failed.map((r) => (
              <li key={r.id} className="flex items-start gap-2 text-xs">
                <CloseCircleFilled className="mt-0.5 text-2xl text-red-500" />
                <div className="min-w-0 flex-1">
                  <p className="m-0 font-medium">{r.name}</p>
                  <p className="m-0 text-slate-500">Gagal membuat laporan. Silakan coba lagi.</p>
                  <p className="m-0 mb-1 text-[11px] text-slate-500">
                    Dibuat oleh {r.createdBy} ({ROLE_LABEL[r.creatorRole]}) · {formatDateTime(r.createdAt)}
                  </p>
                  <Button size="small" onClick={() => onRetry(r.id)}>
                    Coba Lagi
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </div>
  );
};

export default ReportBottomCards;
