import { Button, Modal, Spin } from "antd";
import HistoryLineChart from "@/components/history/HistoryLineChart";
import { useReportData } from "@/hooks/useReportData";
import { FloodStatus } from "@/types/sensor";
import type { IReportData, IReportParams } from "@/types/report";
import { LEVEL_LABEL } from "@/utils/alertLabels";
import { STATUS_META } from "@/utils/status";
import { formatDateTime } from "@/utils/time";

const Gauge = ({ percent }: { percent: number }) => {
  const r = 26;
  const c = 2 * Math.PI * r;
  return (
    <svg viewBox="0 0 64 64" className="h-16 w-16" role="img" aria-label={`${percent}% sensor aktif`}>
      <circle cx="32" cy="32" r={r} fill="none" stroke="#e2e8f0" strokeWidth="7" />
      <circle
        cx="32"
        cy="32"
        r={r}
        fill="none"
        stroke="#22c55e"
        strokeWidth="7"
        strokeLinecap="round"
        strokeDasharray={`${(percent / 100) * c} ${c}`}
        transform="rotate(-90 32 32)"
      />
      <text x="32" y="36" textAnchor="middle" fontSize="13" fontWeight="700" fill="#0f172a">
        {percent}%
      </text>
    </svg>
  );
};

interface IReportPreviewProps {
  data: IReportData;
  compact?: boolean;
}

export const ReportPreview = ({ data: d, compact = false }: IReportPreviewProps) => {
  const s = d.summary;
  const tiles: { label: string; value: number; color: string }[] = [
    { label: "Total", value: s.totalSensor, color: "#3b82f6" },
    { label: "Siaga", value: s.byStatus[FloodStatus.SIAGA], color: STATUS_META[FloodStatus.SIAGA].color },
    { label: "Bahaya", value: s.byStatus[FloodStatus.BAHAYA], color: STATUS_META[FloodStatus.BAHAYA].color },
    { label: "Offline", value: s.byStatus[FloodStatus.OFFLINE], color: STATUS_META[FloodStatus.OFFLINE].color },
  ];

  return (
    <div className={`rounded-md border border-slate-200 bg-white ${compact ? "p-2 text-[10px]" : "p-4 text-xs"}`}>
      <p className={`m-0 font-bold ${compact ? "text-xs" : "text-base"}`}>{d.title}</p>
      <p className="m-0 text-slate-500">
        {d.periodLabel} · {d.areaLabel}
      </p>

      {d.includes.summary && (
        <div className="mt-2 flex items-center gap-2">
          <div className="grid flex-1 grid-cols-4 gap-1">
            {tiles.map((t) => (
              <div key={t.label} className="rounded border border-slate-100 p-1 text-center">
                <p className="m-0 text-slate-500">{t.label}</p>
                <p className={`m-0 font-bold ${compact ? "text-sm" : "text-lg"}`} style={{ color: t.color }}>
                  {t.value}
                </p>
              </div>
            ))}
          </div>
          <Gauge percent={s.activePct} />
        </div>
      )}

      {d.includes.charts && (
        <div className="mt-2">
          <p className="m-0 font-semibold">Tren Tinggi Muka Air</p>
          <HistoryLineChart times={d.times} series={d.series} unit="cm" height={compact ? 120 : 200} />
        </div>
      )}

      {d.includes.summary && (
        <p className="m-0 mt-1 text-slate-600">
          Alert: <b>{s.alertTotal}</b> (belum ditangani {s.alertUnhandled}) · Rata-rata respons:{" "}
          <b>{s.avgResponseMin !== null ? `${s.avgResponseMin} mnt` : "-"}</b>
        </p>
      )}

      {!compact && (
        <>
          {d.includes.summary && (
            <section className="mt-3">
              <p className="m-0 mb-1 font-semibold">Statistik per Sensor</p>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left text-slate-500">
                      <th className="pr-2">ID</th><th className="pr-2">Lokasi</th><th className="pr-2">Status</th>
                      <th className="pr-2 text-right">Maks</th><th className="pr-2 text-right">Min</th>
                      <th className="pr-2 text-right">Rata2</th><th className="text-right">Hujan (mm)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {d.sensorStats.map((t) => (
                      <tr key={t.sensorId} className="border-t border-slate-100">
                        <td className="pr-2">{t.code}</td><td className="pr-2">{t.location}</td>
                        <td className="pr-2" style={{ color: STATUS_META[t.status].color }}>{STATUS_META[t.status].label}</td>
                        <td className="pr-2 text-right">{t.max}</td><td className="pr-2 text-right">{t.min}</td>
                        <td className="pr-2 text-right">{t.avg}</td><td className="text-right">{t.rainTotal}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          )}

          {d.includes.alerts && (
            <section className="mt-3">
              <p className="m-0 mb-1 font-semibold">Daftar Alert & Waktu Respons</p>
              {d.alerts.length === 0 ? (
                <p className="m-0 text-slate-400">Tidak ada alert pada periode ini.</p>
              ) : (
                <table className="w-full">
                  <tbody>
                    {d.alerts.map((a) => (
                      <tr key={a.id} className="border-t border-slate-100">
                        <td className="pr-2">{formatDateTime(a.time)}</td>
                        <td className="pr-2">{LEVEL_LABEL[a.level]}</td>
                        <td className="pr-2">{a.title} ({a.sensorCode})</td>
                        <td className="text-right">{a.responseMin !== null ? `${a.responseMin} mnt` : "-"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </section>
          )}

          {d.includes.problemSensors && (
            <section className="mt-3">
              <p className="m-0 mb-1 font-semibold">Sensor Bermasalah</p>
              {d.problems.length === 0 ? (
                <p className="m-0 text-slate-400">Tidak ada sensor bermasalah.</p>
              ) : (
                <ul className="m-0 list-disc pl-4">
                  {d.problems.map((p) => (
                    <li key={p.code}>
                      {p.code} - {p.location}: {p.issue}
                    </li>
                  ))}
                </ul>
              )}
            </section>
          )}
        </>
      )}
    </div>
  );
};

interface IReportPreviewModalProps {
  params: IReportParams | null;
  creator: string;
  onClose: () => void;
}

export const ReportPreviewModal = ({ params, creator, onClose }: IReportPreviewModalProps) => {
  const { data, isLoading, isError, refetch } = useReportData(params, creator);
  return (
    <Modal open={params !== null} title="Pratinjau Laporan" footer={null} onCancel={onClose} width={760}>
      {isError && !data ? (
        <div className="flex flex-col items-center gap-2 py-8 text-sm">
          <p className="m-0 text-red-500">Pratinjau gagal dimuat.</p>
          <Button onClick={() => void refetch()}>Coba lagi</Button>
        </div>
      ) : isLoading || !data ? (
        <Spin className="block py-10" />
      ) : (
        <ReportPreview data={data} />
      )}
    </Modal>
  );
};
