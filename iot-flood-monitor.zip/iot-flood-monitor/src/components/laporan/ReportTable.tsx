import { useMemo } from "react";
import { DataGrid, type GridColDef, type GridPaginationModel } from "@mui/x-data-grid";
import { Button, Dropdown, Pagination, Progress } from "antd";
import { FileExcelOutlined, FilePdfOutlined, FileTextOutlined, MoreOutlined } from "@ant-design/icons";
import type { ReportFormat } from "@/hooks/useReportDownload";
import { ROLE_LABEL } from "@/types/auth";
import { REPORT_TYPE_COLOR, REPORT_TYPE_LABEL, ReportStatus, type IReport } from "@/types/report";
import { formatDateTime, formatPeriod } from "@/utils/time";

const NoRows = () => (
  <div className="flex h-full items-center justify-center text-sm text-slate-400">Tidak ada laporan yang cocok</div>
);

interface IReportTableProps {
  rows: IReport[];
  loading: boolean;
  isAdmin: boolean;
  busy: string | null;
  paging: GridPaginationModel;
  onPagingChange: (m: GridPaginationModel) => void;
  onDownload: (r: IReport, f: ReportFormat) => void;
  onRetry: (id: number) => void;
  onPreview: (r: IReport) => void;
  onTemplate: (r: IReport) => void;
  onDelete: (r: IReport) => void;
}

const ReportTable = ({
  rows,
  loading,
  isAdmin,
  busy,
  paging,
  onPagingChange,
  onDownload,
  onRetry,
  onPreview,
  onTemplate,
  onDelete,
}: IReportTableProps) => {
  const columns = useMemo<GridColDef<IReport>[]>(
    () => [
      {
        field: "name",
        headerName: "Nama Laporan",
        flex: 1,
        minWidth: 230,
        renderCell: (p) => (
          <span className="flex items-center gap-2">
            <FileTextOutlined className="text-lg text-slate-500" />
            <span className="leading-tight">{p.row.name}</span>
          </span>
        ),
      },
      {
        field: "type",
        headerName: "Jenis",
        width: 100,
        renderCell: (p) => (
          <span className="rounded px-2 py-0.5 text-[11px] font-semibold text-white" style={{ background: REPORT_TYPE_COLOR[p.row.type] }}>
            {REPORT_TYPE_LABEL[p.row.type]}
          </span>
        ),
      },
      {
        field: "from",
        headerName: "Periode",
        width: 160,
        sortable: false,
        renderCell: (p) => <span className="leading-tight">{formatPeriod(p.row.from, p.row.to)}</span>,
      },
      { field: "areaLabel", headerName: "Wilayah/Sensor", width: 150 },
      {
        field: "createdBy",
        headerName: "Dibuat Oleh",
        width: 120,
        renderCell: (p) => (
          <div className="leading-tight">
            <div>{p.row.createdBy}</div>
            <div className="text-[11px] text-slate-500">{ROLE_LABEL[p.row.creatorRole]}</div>
          </div>
        ),
      },
      {
        field: "createdAt",
        headerName: "Tanggal Dibuat",
        width: 150,
        valueFormatter: (v: string) => formatDateTime(v),
      },
      {
        field: "actions",
        headerName: "Aksi",
        width: 260,
        sortable: false,
        disableColumnMenu: true,
        renderCell: (p) => {
          const r = p.row;
          const items = [
            ...(r.status === ReportStatus.SELESAI ? [{ key: "preview", label: "Pratinjau", onClick: () => onPreview(r) }] : []),
            { key: "template", label: "Gunakan sebagai template", onClick: () => onTemplate(r) },
            ...(isAdmin ? [{ key: "delete", label: "Hapus", danger: true, onClick: () => onDelete(r) }] : []),
          ];
          return (
            <span className="flex items-center gap-1">
              {r.status === ReportStatus.SELESAI && (
                <>
                  <Button size="small" danger type="primary" icon={<FilePdfOutlined />} loading={busy === `${r.id}-pdf`} onClick={() => onDownload(r, "pdf")}>
                    PDF
                  </Button>
                  <Button
                    size="small"
                    type="primary"
                    className="!bg-green-600 hover:!bg-green-700"
                    icon={<FileExcelOutlined />}
                    loading={busy === `${r.id}-xlsx`}
                    onClick={() => onDownload(r, "xlsx")}
                  >
                    Excel
                  </Button>
                </>
              )}
              {r.status === ReportStatus.PROSES && (
                <span className="w-36">
                  <Progress percent={r.progress} size="small" />
                </span>
              )}
              {r.status === ReportStatus.GAGAL && (
                <Button size="small" danger onClick={() => onRetry(r.id)}>
                  Gagal - Coba Lagi
                </Button>
              )}
              <Dropdown trigger={["click"]} menu={{ items }}>
                <Button size="small" type="text" aria-label="Menu lainnya" icon={<MoreOutlined />} />
              </Dropdown>
            </span>
          );
        },
      },
    ],
    [isAdmin, busy, onDownload, onRetry, onPreview, onTemplate, onDelete],
  );

  return (
    <>
      <DataGrid
        rows={rows}
        columns={columns}
        loading={loading}
        autoHeight
        rowHeight={56}
        columnHeaderHeight={44}
        hideFooter
        disableRowSelectionOnClick
        disableColumnMenu
        paginationModel={paging}
        onPaginationModelChange={onPagingChange}
        pageSizeOptions={[paging.pageSize]}
        slots={{ noRowsOverlay: NoRows }}
        sx={{
          border: 0,
          fontSize: 12,
          "& .MuiDataGrid-columnHeaders": { backgroundColor: "#f8fafc" },
          "& .MuiDataGrid-overlayWrapper": { minHeight: 120 },
        }}
      />
      <div className="mt-2 flex justify-end border-t border-slate-100 pt-2">
        <Pagination
          size="small"
          current={paging.page + 1}
          pageSize={paging.pageSize}
          total={rows.length}
          showSizeChanger={false}
          onChange={(p) => onPagingChange({ ...paging, page: p - 1 })}
        />
      </div>
    </>
  );
};

export default ReportTable;
