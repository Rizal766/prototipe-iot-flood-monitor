import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { IAuthUser } from "@/types/auth";

interface IAuthState {
  token: string | null;
  user: IAuthUser | null;
  setSession: (token: string, user: IAuthUser) => void;
  logout: () => void;
  updateUser: (patch: Partial<IAuthUser>) => void;
}

export const useAuthStore = create<IAuthState>()(
  persist(
    (set) => ({
      token: null,
      user: null,
      setSession: (token, user) => set({ token, user }),
      logout: () => set({ token: null, user: null }),
      updateUser: (patch) => set((s) => ({ user: s.user ? { ...s.user, ...patch } : s.user })),
    }),
    { name: "iot-flood-monitor-auth-v2" },
  ),
);
