import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Theme = "light" | "dark";

interface IThemeState {
  theme: Theme;
  setTheme: (t: Theme) => void;
}

// Tema disimpan per perangkat (browser), bukan per akun
export const useThemeStore = create<IThemeState>()(
  persist(
    (set) => ({
      theme: "light",
      setTheme: (theme) => set({ theme }),
    }),
    { name: "iot-flood-monitor-theme" },
  ),
);
