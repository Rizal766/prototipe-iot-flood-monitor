import { create } from "zustand";
import { useMapStore } from "./useMapStore";

interface ISensorState {
  selectedSensorId: number | null;
  selectSensor: (id: number | null) => void;
}

export const useSensorStore = create<ISensorState>((set) => ({
  selectedSensorId: null,
  selectSensor: (id) => {
    set({ selectedSensorId: id });
    // Cuaca di header mengikuti lokasi sensor yang dipilih
    if (id !== null) useMapStore.getState().setWeatherSource("sensor");
  },
}));
