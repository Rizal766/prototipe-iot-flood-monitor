import { create } from "zustand";
import type { Map as LeafletMap } from "leaflet";
import { MapLayer, type BaseMap, type IGeoPoint, type StatusFilter } from "@/types/map";
import { DEFAULT_CENTER, DEFAULT_ZOOM, FOCUS_ZOOM } from "@/utils/map";

export const ALL = "ALL";

// Sumber lokasi untuk cuaca di header: titik default, sensor terpilih, atau lokasi pengguna
export type WeatherSource = "default" | "sensor" | "me";

interface IFocus extends IGeoPoint {
  zoom: number;
}

interface IMapState {
  search: string;
  status: StatusFilter;
  river: string;
  district: string;
  baseMap: BaseMap;
  layers: Record<MapLayer, boolean>;
  map: LeafletMap | null;
  zoom: number;
  focus: IFocus | null;
  myLocation: IGeoPoint | null;
  weatherSource: WeatherSource;
  setSearch: (v: string) => void;
  setStatus: (v: StatusFilter) => void;
  setRiver: (v: string) => void;
  setDistrict: (v: string) => void;
  resetFilters: () => void;
  setBaseMap: (v: BaseMap) => void;
  toggleLayer: (layer: MapLayer) => void;
  setMap: (m: LeafletMap | null) => void;
  setZoom: (z: number) => void;
  zoomIn: () => void;
  zoomOut: () => void;
  flyTo: (p: IGeoPoint, zoom?: number) => void;
  clearFocus: () => void;
  resetView: () => void;
  setMyLocation: (p: IGeoPoint | null) => void;
  setWeatherSource: (s: WeatherSource) => void;
}

export const useMapStore = create<IMapState>((set, get) => ({
  search: "",
  status: "ALL",
  river: ALL,
  district: ALL,
  baseMap: "peta",
  layers: {
    [MapLayer.RIVER]: true,
    [MapLayer.DISTRICT]: false,
    [MapLayer.EVACUATION]: true,
    [MapLayer.RADAR]: false,
  },
  map: null,
  zoom: DEFAULT_ZOOM,
  focus: null,
  myLocation: null,
  weatherSource: "default",
  setSearch: (search) => set({ search }),
  setStatus: (status) => set({ status }),
  setRiver: (river) => set({ river }),
  setDistrict: (district) => set({ district }),
  resetFilters: () => set({ search: "", status: "ALL", river: ALL, district: ALL }),
  setBaseMap: (baseMap) => set({ baseMap }),
  toggleLayer: (layer) => set((s) => ({ layers: { ...s.layers, [layer]: !s.layers[layer] } })),
  setMap: (map) => set({ map }),
  setZoom: (zoom) => set({ zoom }),
  zoomIn: () => {
    get().map?.zoomIn();
  },
  zoomOut: () => {
    get().map?.zoomOut();
  },
  // Disimpan sebagai permintaan fokus agar tetap jalan walau peta belum tampil (mis. dari halaman lain)
  flyTo: (p, zoom = FOCUS_ZOOM) => set({ focus: { ...p, zoom } }),
  clearFocus: () => set({ focus: null }),
  resetView: () => {
    get().map?.flyTo([DEFAULT_CENTER.lat, DEFAULT_CENTER.lng], DEFAULT_ZOOM);
  },
  setMyLocation: (myLocation) => set(myLocation ? { myLocation, weatherSource: "me" } : { myLocation }),
  setWeatherSource: (weatherSource) => set({ weatherSource }),
}));
