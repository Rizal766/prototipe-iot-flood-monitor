import { useMemo } from "react";
import { useSensors } from "@/hooks/useSensors";
import { ALL, useMapStore } from "@/stores/useMapStore";
import { useSensorStore } from "@/stores/useSensorStore";
import { FloodStatus } from "@/types/sensor";
import type { StatusFilter } from "@/types/map";
import { STATUS_SEVERITY } from "@/utils/status";

export const usePetaSensors = () => {
  const { data, isLoading, isError, refetch } = useSensors({ page: 1, limit: 100 });
  const search = useMapStore((s) => s.search);
  const status = useMapStore((s) => s.status);
  const river = useMapStore((s) => s.river);
  const district = useMapStore((s) => s.district);
  const selectedId = useSensorStore((s) => s.selectedSensorId);

  const all = useMemo(() => data?.data ?? [], [data]);

  const counts = useMemo(() => {
    const c: Record<StatusFilter, number> = {
      ALL: all.length,
      [FloodStatus.AMAN]: 0,
      [FloodStatus.WASPADA]: 0,
      [FloodStatus.SIAGA]: 0,
      [FloodStatus.BAHAYA]: 0,
      [FloodStatus.OFFLINE]: 0,
    };
    all.forEach((s) => {
      c[s.status] += 1;
    });
    return c;
  }, [all]);

  const rivers = useMemo(() => [...new Set(all.map((s) => s.river))].sort(), [all]);
  const districts = useMemo(() => [...new Set(all.map((s) => s.district))].sort(), [all]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return all
      .filter((s) => status === "ALL" || s.status === status)
      .filter((s) => river === ALL || s.river === river)
      .filter((s) => district === ALL || s.district === district)
      .filter(
        (s) =>
          !q ||
          [s.code, s.location, s.river, s.district].some((f) => f.toLowerCase().includes(q)),
      )
      .sort((a, b) => STATUS_SEVERITY[b.status] - STATUS_SEVERITY[a.status] || b.waterLevel - a.waterLevel);
  }, [all, search, status, river, district]);

  // Sensor terpilih; bila belum ada, tampilkan sensor paling parah
  const selected = useMemo(
    () =>
      all.find((s) => s.id === selectedId) ??
      [...all].sort((a, b) => STATUS_SEVERITY[b.status] - STATUS_SEVERITY[a.status])[0],
    [all, selectedId],
  );

  return { all, filtered, counts, rivers, districts, selected, isLoading, isError, refetch };
};
