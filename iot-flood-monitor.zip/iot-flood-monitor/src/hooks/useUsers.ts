import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  cancelInvitation,
  createInvitation,
  createUser,
  deleteUser,
  getAreas,
  getInvitations,
  getUsers,
  resendInvitation,
  savePermissions,
  updateArea,
  updateUser,
} from "@/api/userApi";
import type { IPermissionMatrix } from "@/types/permission";
import type { IArea, IUserPayload } from "@/types/user";

export const useUsers = () => useQuery({ queryKey: ["users"], queryFn: getUsers });
export const useInvitations = () => useQuery({ queryKey: ["invitations"], queryFn: getInvitations });
export const useAreas = () => useQuery({ queryKey: ["areas"], queryFn: getAreas });

export const useUserMutations = () => {
  const qc = useQueryClient();
  const refresh = (key: string) => qc.invalidateQueries({ queryKey: [key] });

  const create = useMutation({
    mutationFn: createUser,
    onSuccess: async (r) => {
      if (r.status) await refresh("users");
    },
  });
  const update = useMutation({
    mutationFn: ({ id, payload }: { id: number; payload: IUserPayload }) => updateUser(id, payload),
    onSuccess: async (r) => {
      if (r.status) await refresh("users");
    },
  });
  const remove = useMutation({
    mutationFn: deleteUser,
    onSuccess: async (r) => {
      if (r.status) await refresh("users");
    },
  });
  const invite = useMutation({
    mutationFn: createInvitation,
    onSuccess: async (r) => {
      if (r.status) await refresh("invitations");
    },
  });
  const resend = useMutation({
    mutationFn: resendInvitation,
    onSuccess: async (r) => {
      if (r.status) await refresh("invitations");
    },
  });
  const cancel = useMutation({
    mutationFn: cancelInvitation,
    onSuccess: async (r) => {
      if (r.status) await refresh("invitations");
    },
  });
  const permissions = useMutation({
    mutationFn: (m: IPermissionMatrix) => savePermissions(m),
    onSuccess: async (r) => {
      if (r.status) await refresh("permissions");
    },
  });
  const area = useMutation({
    mutationFn: ({ district, patch }: { district: string; patch: Partial<Pick<IArea, "residents" | "active">> }) =>
      updateArea(district, patch),
    onSuccess: async (r) => {
      if (r.status) await refresh("areas");
    },
  });
  return { create, update, remove, invite, resend, cancel, permissions, area };
};
