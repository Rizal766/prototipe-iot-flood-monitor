import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { getHistory } from "@/api/historyApi";
import type { IHistoryQuery } from "@/types/history";

export const useHistory = (q: IHistoryQuery) =>
  useQuery({
    queryKey: ["history", [...q.sensorIds].sort(), q.from, q.to, q.interval],
    queryFn: () => getHistory(q),
    enabled: q.sensorIds.length > 0,
    staleTime: 60_000,
    placeholderData: keepPreviousData,
  });
