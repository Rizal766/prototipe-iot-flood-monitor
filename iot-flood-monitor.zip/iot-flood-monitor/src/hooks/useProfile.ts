import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  changePassword,
  getPreferences,
  getProfile,
  getSessions,
  revokeAllSessions,
  revokeSession,
  saveAvatar,
  savePreferences,
  updateProfile,
} from "@/api/profileApi";
import { useAuthStore } from "@/stores/useAuthStore";
import type { IPreferences } from "@/types/profile";
import type { IResponseEntity } from "@/types/response";

export const useProfile = () => useQuery({ queryKey: ["profile"], queryFn: getProfile });
export const useSessions = () => useQuery({ queryKey: ["sessions"], queryFn: getSessions });
export const usePreferences = () => useQuery({ queryKey: ["preferences"], queryFn: getPreferences });

export const useProfileMutations = () => {
  const qc = useQueryClient();
  const updateAuth = useAuthStore((s) => s.updateUser);

  const save = useMutation({
    mutationFn: updateProfile,
    onSuccess: async (res) => {
      if (res.status && res.data) {
        updateAuth({ name: res.data.name }); // nama di header ikut berubah
        await Promise.all([qc.invalidateQueries({ queryKey: ["profile"] }), qc.invalidateQueries({ queryKey: ["users"] })]);
      }
    },
  });

  const avatar = useMutation({
    mutationFn: saveAvatar,
    onSuccess: async (res) => {
      if (res.status) {
        updateAuth({ avatar: res.data?.avatar ?? null });
        await qc.invalidateQueries({ queryKey: ["profile"] });
      }
    },
  });

  const password = useMutation({
    mutationFn: changePassword,
    onSuccess: async (res) => {
      if (res.status) await qc.invalidateQueries({ queryKey: ["sessions"] });
    },
  });

  const revoke = useMutation({
    mutationFn: revokeSession,
    onSuccess: async (res) => {
      if (res.status) await qc.invalidateQueries({ queryKey: ["sessions"] });
    },
  });

  const revokeAll = useMutation({ mutationFn: revokeAllSessions });

  // Preferensi diterapkan langsung di layar, lalu dikembalikan bila penyimpanan gagal
  const prefs = useMutation({
    mutationFn: async (next: IPreferences) => {
      const res = await savePreferences(next);
      if (!res.status) throw new Error(res.message || "Gagal menyimpan preferensi");
      return res;
    },
    onMutate: async (next) => {
      await qc.cancelQueries({ queryKey: ["preferences"] });
      const previous = qc.getQueryData<IResponseEntity<IPreferences>>(["preferences"]);
      if (previous) qc.setQueryData<IResponseEntity<IPreferences>>(["preferences"], { ...previous, data: next });
      return { previous };
    },
    onError: (_err, _next, ctx) => {
      if (ctx?.previous) qc.setQueryData(["preferences"], ctx.previous);
    },
    onSettled: () => qc.invalidateQueries({ queryKey: ["preferences"] }),
  });

  return { save, avatar, password, revoke, revokeAll, prefs };
};
