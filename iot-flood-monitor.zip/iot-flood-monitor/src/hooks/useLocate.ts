import { useCallback, useState } from "react";
import { message } from "antd";
import { useMapStore } from "@/stores/useMapStore";

export const useLocate = () => {
  const setMyLocation = useMapStore((s) => s.setMyLocation);
  const flyTo = useMapStore((s) => s.flyTo);
  const [loading, setLoading] = useState(false);

  const locate = useCallback(() => {
    if (!navigator.geolocation) {
      message.warning("Perangkat tidak mendukung geolokasi");
      return;
    }
    setLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const p = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setMyLocation(p); // cuaca di header ikut berpindah ke lokasi ini
        flyTo(p);
        setLoading(false);
      },
      () => {
        setLoading(false);
        message.error("Izin lokasi ditolak atau tidak tersedia");
      },
      { enableHighAccuracy: true, timeout: 8000 },
    );
  }, [setMyLocation, flyTo]);

  return { locate, loading };
};
