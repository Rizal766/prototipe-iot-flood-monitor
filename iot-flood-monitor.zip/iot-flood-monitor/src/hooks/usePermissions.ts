import { useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { getPermissions } from "@/api/userApi";
import { useAuthStore } from "@/stores/useAuthStore";
import { UserRole } from "@/types/auth";
import type { Feature } from "@/types/permission";

export const usePermissionMatrix = () =>
  useQuery({ queryKey: ["permissions"], queryFn: getPermissions, staleTime: 60_000 });

// Hak akses menu per role (Admin selalu penuh). `ready` false selama matriks belum dimuat.
export const usePermissions = () => {
  const role = useAuthStore((s) => s.user?.role);
  const { data, isSuccess } = usePermissionMatrix();

  const can = useCallback(
    (feature: Feature): boolean => {
      if (role === UserRole.ADMIN) return true;
      if (!role) return false;
      const matrix = data?.data;
      if (!matrix) return true;
      return matrix[feature]?.[role] ?? false;
    },
    [role, data],
  );

  return { can, ready: role === UserRole.ADMIN || isSuccess };
};
