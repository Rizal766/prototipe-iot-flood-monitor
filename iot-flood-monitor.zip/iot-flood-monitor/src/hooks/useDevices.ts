import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { message } from "antd";
import { createDevice, deleteDevice, getDevices, updateDevice } from "@/api/deviceApi";
import type { IDeviceUpdate } from "@/types/device";

export const useDevices = () => useQuery({ queryKey: ["devices"], queryFn: getDevices });

export const useDeviceMutations = () => {
  const qc = useQueryClient();
  // perangkat berkaitan dengan sensor dan konfigurasi alert
  const refresh = async () => {
    await Promise.all([
      qc.invalidateQueries({ queryKey: ["devices"] }),
      qc.invalidateQueries({ queryKey: ["sensors"] }),
      qc.invalidateQueries({ queryKey: ["alert-configs"] }),
    ]);
  };
  const onError = () => message.error("Aksi gagal, coba lagi");

  const create = useMutation({
    mutationFn: createDevice,
    onSuccess: async (res) => {
      if (res.status) await refresh();
    },
    onError,
  });
  const update = useMutation({
    mutationFn: ({ id, payload }: { id: number; payload: IDeviceUpdate }) => updateDevice(id, payload),
    onSuccess: async (res) => {
      if (res.status) await refresh();
    },
    onError,
  });
  const remove = useMutation({
    mutationFn: deleteDevice,
    onSuccess: async (res) => {
      if (res.status) await refresh();
    },
    onError,
  });
  return { create, update, remove };
};
