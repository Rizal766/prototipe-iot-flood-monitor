import { useQuery } from "@tanstack/react-query";
import { getSensors } from "@/api/sensorApi";
import type { ISensorQuery } from "@/types/sensor";

export const useSensors = (query: ISensorQuery) =>
  useQuery({
    queryKey: ["sensors", query],
    queryFn: () => getSensors(query),
  });
