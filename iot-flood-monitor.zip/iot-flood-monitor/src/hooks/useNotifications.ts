import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { message } from "antd";
import { deleteNotification, getNotifications, updateNotifications } from "@/api/notificationApi";
import type { INotificationPatch } from "@/types/notification";

export const useNotifications = () =>
  useQuery({ queryKey: ["notifications"], queryFn: getNotifications, refetchInterval: 30_000 });

export const useNotificationMutations = () => {
  const qc = useQueryClient();
  const refresh = () => qc.invalidateQueries({ queryKey: ["notifications"] });
  const onError = () => message.error("Aksi gagal, coba lagi");

  const update = useMutation({
    mutationFn: ({ ids, patch }: { ids: number[]; patch: INotificationPatch }) => updateNotifications(ids, patch),
    onSuccess: async (_res, vars) => {
      await refresh();
      message.success(`${vars.ids.length} alert diperbarui`);
    },
    onError,
  });

  const remove = useMutation({
    mutationFn: deleteNotification,
    onSuccess: async () => {
      await refresh();
      message.success("Alert dihapus");
    },
    onError,
  });

  return { update, remove };
};
