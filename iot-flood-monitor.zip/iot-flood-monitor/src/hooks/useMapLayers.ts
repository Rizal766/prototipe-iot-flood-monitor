import { useQuery } from "@tanstack/react-query";
import { getDistricts, getWaterways } from "@/api/overpassApi";
import { getRadarTileUrl } from "@/api/rainviewerApi";
import type { IBBox } from "@/types/map";

const DAY = 24 * 60 * 60 * 1000;
const key = (b: IBBox) => [b.south, b.west, b.north, b.east];

export const useWaterways = (bbox: IBBox, enabled: boolean) =>
  useQuery({
    queryKey: ["map", "waterways", ...key(bbox)],
    queryFn: () => getWaterways(bbox),
    enabled,
    staleTime: DAY,
    gcTime: DAY,
    retry: 1,
  });

export const useDistricts = (bbox: IBBox, enabled: boolean) =>
  useQuery({
    queryKey: ["map", "districts", ...key(bbox)],
    queryFn: () => getDistricts(bbox),
    enabled,
    staleTime: DAY,
    gcTime: DAY,
    retry: 1,
  });

export const useRadarTiles = (enabled: boolean) =>
  useQuery({
    queryKey: ["map", "radar"],
    queryFn: getRadarTileUrl,
    enabled,
    staleTime: 5 * 60_000,
    refetchInterval: enabled ? 5 * 60_000 : false,
    retry: 1,
  });
