import { useEffect, useState } from "react";

const tzName = (d: Date): string =>
  new Intl.DateTimeFormat("id-ID", { timeZoneName: "short" })
    .formatToParts(d)
    .find((p) => p.type === "timeZoneName")?.value ?? "";

// Jam real-time, diperbarui setiap detik
export const useClock = () => {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  return {
    time: now
      .toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false })
      .replace(/\./g, ":"),
    date: now.toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" }),
    tz: tzName(now),
  };
};
