import { useCallback, useState } from "react";
import { message } from "antd";
import { useAuthStore } from "@/stores/useAuthStore";
import type { IReportParams } from "@/types/report";
import { fileSlug, saveBlob } from "@/utils/download";
import { loadReportData } from "@/utils/reportBuilder";
import { buildReportExcel } from "@/utils/reportExcel";
import { buildReportPdf } from "@/utils/reportPdf";

export type ReportFormat = "pdf" | "xlsx";

export const useReportDownload = () => {
  const [busy, setBusy] = useState<string | null>(null);
  const user = useAuthStore((s) => s.user);

  const download = useCallback(
    async (key: string, params: IReportParams, format: ReportFormat, creator?: string) => {
      setBusy(`${key}-${format}`);
      try {
        const data = await loadReportData(params, creator ?? user?.name ?? "Admin");
        const blob = format === "pdf" ? await buildReportPdf(data) : await buildReportExcel(data);
        saveBlob(blob, `${fileSlug(data.title)}.${format}`);
        message.success(`File ${format.toUpperCase()} berhasil dibuat`);
      } catch (e) {
        message.error(`Gagal membuat file laporan${e instanceof Error ? `: ${e.message}` : ""}`);
      } finally {
        setBusy(null);
      }
    },
    [user],
  );

  return { download, busy };
};
