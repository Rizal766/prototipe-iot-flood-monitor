import { useMemo } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { message } from "antd";
import { applyThresholds, getAlertConfigs, saveAlertConfig } from "@/api/alertConfigApi";
import type { IAlertConfigPayload } from "@/types/alertConfig";
import type { IThresholds } from "@/utils/thresholds";

export const useAlertConfigs = () => useQuery({ queryKey: ["alert-configs"], queryFn: getAlertConfigs });

// Peta sensorId -> ambang batas, dipakai halaman lain agar status mengikuti pengaturan
export const useThresholdMap = (): Map<number, IThresholds> => {
  const { data } = useAlertConfigs();
  return useMemo(() => new Map((data?.data ?? []).map((c) => [c.sensorId, c.thresholds])), [data]);
};

export const useAlertConfigMutations = () => {
  const qc = useQueryClient();
  // ambang batas memengaruhi status sensor, jadi data sensor ikut disegarkan
  const refresh = async () => {
    await Promise.all([
      qc.invalidateQueries({ queryKey: ["alert-configs"] }),
      qc.invalidateQueries({ queryKey: ["sensors"] }),
      qc.invalidateQueries({ queryKey: ["history"] }),
    ]);
  };

  const save = useMutation({
    mutationFn: ({ sensorId, payload }: { sensorId: number; payload: IAlertConfigPayload }) =>
      saveAlertConfig(sensorId, payload),
    onSuccess: async (res) => {
      if (res.status) await refresh();
      else message.error(res.message || "Gagal menyimpan pengaturan");
    },
    onError: () => message.error("Gagal menyimpan pengaturan"),
  });

  const apply = useMutation({
    mutationFn: ({ sensorIds, thresholds }: { sensorIds: number[]; thresholds: IThresholds }) =>
      applyThresholds(sensorIds, thresholds),
    onSuccess: async (_res, vars) => {
      await refresh();
      message.success(`Ambang batas diterapkan ke ${vars.sensorIds.length} sensor`);
    },
    onError: () => message.error("Gagal menerapkan template"),
  });

  return { save, apply };
};
