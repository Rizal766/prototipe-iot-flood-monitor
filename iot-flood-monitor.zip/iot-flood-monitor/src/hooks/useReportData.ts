import { keepPreviousData, useQuery } from "@tanstack/react-query";
import type { IReportParams } from "@/types/report";
import { loadReportData } from "@/utils/reportBuilder";

export const useReportData = (params: IReportParams | null, creator: string) =>
  useQuery({
    queryKey: [
      "report-data",
      params?.type,
      params?.from,
      params?.to,
      params?.sensorIds,
      params?.areaLabel,
      params?.includes,
      creator,
    ],
    queryFn: () => (params ? loadReportData(params, creator) : Promise.reject(new Error("Parameter laporan kosong"))),
    enabled: params !== null,
    staleTime: 60_000,
    placeholderData: keepPreviousData,
  });
