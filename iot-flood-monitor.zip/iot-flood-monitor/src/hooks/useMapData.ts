import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  createEvacuationPoint,
  deleteEvacuationPoint,
  getEvacuationPoints,
  updateEvacuationPoint,
} from "@/api/mapApi";
import type { IEvacuationPayload } from "@/types/map";

export const useEvacuationPoints = () =>
  useQuery({ queryKey: ["map", "evacuation"], queryFn: getEvacuationPoints });

export const useEvacuationMutations = () => {
  const qc = useQueryClient();
  const refresh = () => qc.invalidateQueries({ queryKey: ["map", "evacuation"] });

  const create = useMutation({
    mutationFn: createEvacuationPoint,
    onSuccess: async (res) => {
      if (res.status) await refresh();
    },
  });
  const update = useMutation({
    mutationFn: ({ id, payload }: { id: number; payload: IEvacuationPayload }) => updateEvacuationPoint(id, payload),
    onSuccess: async (res) => {
      if (res.status) await refresh();
    },
  });
  const remove = useMutation({
    mutationFn: deleteEvacuationPoint,
    onSuccess: async (res) => {
      if (res.status) await refresh();
    },
  });
  return { create, update, remove };
};
