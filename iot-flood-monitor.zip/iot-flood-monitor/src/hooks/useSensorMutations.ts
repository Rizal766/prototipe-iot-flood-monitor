import { useMutation, useQueryClient } from "@tanstack/react-query";
import { message } from "antd";
import { createSensor, updateSensor } from "@/api/sensorApi";
import type { IResponseEntity } from "@/types/response";
import type { ISensor, ISensorPayload } from "@/types/sensor";

export const useSensorMutations = (onDone?: () => void) => {
  const qc = useQueryClient();

  const handleResult = (res: IResponseEntity<ISensor>, successText: string) => {
    if (res.status) {
      message.success(successText);
      void qc.invalidateQueries({ queryKey: ["sensors"] });
      onDone?.();
    } else {
      message.error(res.message || "Terjadi kesalahan");
    }
  };

  const onError = () => message.error("Gagal menyimpan sensor");

  const create = useMutation({
    mutationFn: createSensor,
    onSuccess: (res) => handleResult(res, "Sensor berhasil ditambahkan"),
    onError,
  });

  const update = useMutation({
    mutationFn: ({ id, payload }: { id: number; payload: ISensorPayload }) => updateSensor(id, payload),
    onSuccess: (res) => handleResult(res, "Sensor berhasil diperbarui"),
    onError,
  });

  return { create, update };
};
