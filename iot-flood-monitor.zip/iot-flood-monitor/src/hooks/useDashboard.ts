import { useQuery } from "@tanstack/react-query";
import { getAlerts, getIntegrations, getSummary, getWaterChart } from "@/api/dashboardApi";

export const useSummary = () => useQuery({ queryKey: ["dashboard", "summary"], queryFn: getSummary });
export const useAlerts = () => useQuery({ queryKey: ["dashboard", "alerts"], queryFn: getAlerts });
export const useWaterChart = () =>
  useQuery({ queryKey: ["dashboard", "water-chart"], queryFn: getWaterChart });
export const useIntegrations = () =>
  useQuery({ queryKey: ["dashboard", "integrations"], queryFn: getIntegrations });
