import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  createContact,
  deleteContact,
  getContacts,
  getNotificationSettings,
  saveNotificationSettings,
  testChannel,
  updateChannel,
  updateContact,
} from "@/api/notificationSettingsApi";
import type { IEmergencyContactPayload } from "@/types/contact";
import type { ChannelType } from "@/types/notificationSettings";

export const useNotificationSettings = () =>
  useQuery({ queryKey: ["notification-settings"], queryFn: getNotificationSettings });

export const useContacts = () => useQuery({ queryKey: ["contacts"], queryFn: getContacts });

export const useSettingsMutations = () => {
  const qc = useQueryClient();
  const refreshSettings = () => qc.invalidateQueries({ queryKey: ["notification-settings"] });
  const refreshContacts = () => qc.invalidateQueries({ queryKey: ["contacts"] });

  const save = useMutation({
    mutationFn: saveNotificationSettings,
    onSuccess: async (r) => {
      if (r.status) await refreshSettings();
    },
  });
  const channel = useMutation({
    mutationFn: ({ type, fields }: { type: ChannelType; fields: Record<string, string> }) => updateChannel(type, fields),
    onSuccess: async (r) => {
      if (r.status) await refreshSettings();
    },
  });
  const test = useMutation({
    mutationFn: testChannel,
    onSettled: async () => {
      await refreshSettings();
    },
  });
  const addContact = useMutation({
    mutationFn: createContact,
    onSuccess: async (r) => {
      if (r.status) await refreshContacts();
    },
  });
  const editContact = useMutation({
    mutationFn: ({ id, payload }: { id: number; payload: IEmergencyContactPayload }) => updateContact(id, payload),
    onSuccess: async (r) => {
      if (r.status) await refreshContacts();
    },
  });
  const removeContact = useMutation({
    mutationFn: deleteContact,
    onSuccess: async (r) => {
      if (r.status) await refreshContacts();
    },
  });
  return { save, channel, test, addContact, editContact, removeContact };
};
