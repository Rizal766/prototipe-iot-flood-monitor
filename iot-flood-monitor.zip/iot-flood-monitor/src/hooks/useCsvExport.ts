import { useCallback, useEffect, useRef, useState } from "react";
import { message } from "antd";
import { buildCsvAsync } from "@/utils/exportCsv";

export interface IExportState {
  status: "idle" | "running" | "done";
  progress: number;
  fileName: string;
  size: number;
}

const IDLE: IExportState = { status: "idle", progress: 0, fileName: "", size: 0 };

const trigger = (url: string, fileName: string) => {
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  a.click();
};

export const useCsvExport = () => {
  const [state, setState] = useState<IExportState>(IDLE);
  const urlRef = useRef<string | null>(null);

  const release = () => {
    if (urlRef.current) URL.revokeObjectURL(urlRef.current);
    urlRef.current = null;
  };
  useEffect(() => release, []);

  const start = useCallback(async (header: string[], rows: (string | number)[][], baseName: string) => {
    if (rows.length === 0) {
      message.warning("Tidak ada data untuk diekspor");
      return;
    }
    release();
    setState({ ...IDLE, status: "running" });
    const blob = await buildCsvAsync(header, rows, (progress) => setState((s) => ({ ...s, progress })));
    const fileName = `${baseName}-${new Date().toISOString().slice(0, 10)}.csv`;
    urlRef.current = URL.createObjectURL(blob);
    trigger(urlRef.current, fileName);
    setState({ status: "done", progress: 100, fileName, size: blob.size });
  }, []);

  const reopen = useCallback(() => {
    if (urlRef.current) trigger(urlRef.current, state.fileName);
  }, [state.fileName]);

  const dismiss = useCallback(() => {
    release();
    setState(IDLE);
  }, []);

  return { state, start, reopen, dismiss };
};
