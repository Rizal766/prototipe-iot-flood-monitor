import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { message } from "antd";
import { createReport, deleteReport, getReports, retryReport } from "@/api/reportApi";
import { ReportStatus } from "@/types/report";

// Polling cepat selama masih ada laporan yang diproses
export const useReports = () =>
  useQuery({
    queryKey: ["reports"],
    queryFn: getReports,
    refetchInterval: (q) => (q.state.data?.data?.some((r) => r.status === ReportStatus.PROSES) ? 1500 : false),
  });

export const useReportMutations = () => {
  const qc = useQueryClient();
  const refresh = () => qc.invalidateQueries({ queryKey: ["reports"] });
  const onError = () => message.error("Aksi gagal, coba lagi");

  const create = useMutation({
    mutationFn: createReport,
    onSuccess: async (res) => {
      if (!res.status) {
        message.error(res.message || "Gagal membuat laporan");
        return;
      }
      await refresh();
      message.success("Laporan sedang dibuat");
    },
    onError,
  });
  const retry = useMutation({
    mutationFn: retryReport,
    onSuccess: async (res) => {
      if (!res.status) {
        message.error(res.message || "Gagal mencoba ulang");
        return;
      }
      await refresh();
      message.info("Mencoba membuat ulang laporan");
    },
    onError,
  });
  const remove = useMutation({
    mutationFn: deleteReport,
    onSuccess: async (res) => {
      if (!res.status) {
        message.error(res.message || "Gagal menghapus laporan");
        return;
      }
      await refresh();
      message.success("Laporan dihapus");
    },
    onError,
  });
  return { create, retry, remove };
};
