import { useMemo } from "react";
import { useSensors } from "@/hooks/useSensors";
import { useMapStore } from "@/stores/useMapStore";
import { useSensorStore } from "@/stores/useSensorStore";
import type { IGeoPoint } from "@/types/map";
import { DEFAULT_CENTER } from "@/utils/map";

// Lokasi acuan cuaca: posisi pengguna, sensor terpilih, atau pusat default (Semarang)
export const useWeatherLocation = (): IGeoPoint => {
  const source = useMapStore((s) => s.weatherSource);
  const myLocation = useMapStore((s) => s.myLocation);
  const selectedId = useSensorStore((s) => s.selectedSensorId);
  const { data } = useSensors({ page: 1, limit: 100 });

  return useMemo(() => {
    if (source === "me" && myLocation) return myLocation;
    if (source === "sensor") {
      const s = data?.data?.find((x) => x.id === selectedId);
      if (s) return { lat: s.lat, lng: s.lng };
    }
    return DEFAULT_CENTER;
  }, [source, myLocation, selectedId, data]);
};
