import { useQuery } from "@tanstack/react-query";
import { reverseGeocode } from "@/api/geocodeApi";
import { getWeather } from "@/api/weatherApi";
import { useWeatherLocation } from "./useWeatherLocation";

const round = (n: number) => Number(n.toFixed(2));

export const useLocationWeather = () => {
  const point = useWeatherLocation();
  const lat = round(point.lat);
  const lng = round(point.lng);

  const weather = useQuery({
    queryKey: ["weather", lat, lng],
    queryFn: () => getWeather(lat, lng),
    staleTime: 10 * 60_000,
    refetchInterval: 10 * 60_000,
    retry: 1,
  });

  const place = useQuery({
    queryKey: ["place", lat, lng],
    queryFn: () => reverseGeocode(lat, lng),
    staleTime: Infinity,
    retry: 1,
  });

  return {
    weather: weather.data,
    place: place.data ?? `${lat.toFixed(2)}, ${lng.toFixed(2)}`,
    isLoading: weather.isLoading,
    isError: weather.isError,
  };
};
