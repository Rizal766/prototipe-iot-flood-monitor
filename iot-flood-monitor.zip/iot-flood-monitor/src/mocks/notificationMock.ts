import { MOCK_SENSORS } from "./dashboardMock";
import { OFFICERS } from "@/utils/officers";
import {
  AlertLevel,
  AlertStatus,
  AlertType,
  type INotification,
} from "@/types/notification";

const ago = (minutes: number) => new Date(Date.now() - minutes * 60000).toISOString();
const sensorOf = (code: string) => MOCK_SENSORS.find((s) => s.code === code);
const loc = (code: string) => sensorOf(code)?.location ?? code;

type Seed = Omit<INotification, "location" | "createdAt" | "respondedAt"> & { minutes: number };

const head: Seed[] = [
  { id: 1, level: AlertLevel.TINGGI, type: AlertType.TINGGI_AIR, title: "Tinggi air mencapai 248 cm", sensorCode: "BNA-003", value: 248, threshold: 200, unit: "cm", minutes: 36, status: AlertStatus.BELUM, officer: null },
  { id: 2, level: AlertLevel.SEDANG, type: AlertType.CURAH_HUJAN, title: "Curah hujan intensitas tinggi", sensorCode: "SMG-015", value: 78, threshold: 50, unit: "mm", minutes: 60, status: AlertStatus.DIPROSES, officer: "Andi Pratama" },
  { id: 3, level: AlertLevel.TINGGI, type: AlertType.TINGGI_AIR, title: "Tinggi air mencapai 165 cm", sensorCode: "GRG-007", value: 165, threshold: 120, unit: "cm", minutes: 90, status: AlertStatus.BELUM, officer: null },
  { id: 4, level: AlertLevel.SEDANG, type: AlertType.CURAH_HUJAN, title: "Curah hujan meningkat", sensorCode: "TMR-021", value: 45, threshold: 30, unit: "mm", minutes: 125, status: AlertStatus.DIPROSES, officer: "Siti Rahayu" },
  { id: 5, level: AlertLevel.OFFLINE, type: AlertType.OFFLINE, title: "Sensor offline", sensorCode: "KDL-008", value: null, threshold: null, unit: "", minutes: 180, status: AlertStatus.BELUM, officer: null },
  { id: 6, level: AlertLevel.RENDAH, type: AlertType.BATERAI, title: "Baterai lemah (12%)", sensorCode: "BRG-012", value: 12, threshold: 20, unit: "%", minutes: 240, status: AlertStatus.DIPROSES, officer: "Budi Santoso" },
  { id: 7, level: AlertLevel.SEDANG, type: AlertType.TINGGI_AIR, title: "Tinggi air mencapai 132 cm", sensorCode: "BNA-003", value: 132, threshold: 120, unit: "cm", minutes: 420, status: AlertStatus.SELESAI, officer: "Rizky Maulana" },
  { id: 8, level: AlertLevel.OFFLINE, type: AlertType.OFFLINE, title: "Sensor offline", sensorCode: "GRG-007", value: null, threshold: null, unit: "", minutes: 540, status: AlertStatus.SELESAI, officer: "Andi Pratama" },
  { id: 9, level: AlertLevel.RENDAH, type: AlertType.BATERAI, title: "Baterai lemah (15%)", sensorCode: "SMG-015", value: 15, threshold: 20, unit: "%", minutes: 660, status: AlertStatus.DIPROSES, officer: "Dewi Lestari" },
  { id: 10, level: AlertLevel.TINGGI, type: AlertType.TINGGI_AIR, title: "Tinggi air mencapai 210 cm", sensorCode: "TMR-021", value: 210, threshold: 200, unit: "cm", minutes: 840, status: AlertStatus.SELESAI, officer: "Ahmad Fauzi" },
];

const STATUS_CYCLE: AlertStatus[] = [
  AlertStatus.BELUM, AlertStatus.SELESAI, AlertStatus.DIPROSES, AlertStatus.SELESAI, AlertStatus.BELUM,
  AlertStatus.SELESAI, AlertStatus.BELUM, AlertStatus.DIPROSES, AlertStatus.SELESAI, AlertStatus.BELUM,
  AlertStatus.SELESAI, AlertStatus.DIPROSES, AlertStatus.BELUM, AlertStatus.SELESAI,
];
const CODES = ["BNA-003", "GRG-007", "BRG-012", "SMG-015", "TMR-021", "KDL-008"];

const rest: Seed[] = Array.from({ length: 14 }, (_, i) => {
  const code = CODES[(i + 2) % CODES.length];
  const kind = i % 4;
  const status = STATUS_CYCLE[i];
  const officer = status === AlertStatus.BELUM ? null : OFFICERS[i % OFFICERS.length];
  const minutes = 1000 + i * 130;
  const id = 11 + i;
  if (kind === 0) {
    const v = 125 + ((i * 17) % 90);
    return { id, level: v >= 200 ? AlertLevel.TINGGI : AlertLevel.SEDANG, type: AlertType.TINGGI_AIR, title: `Tinggi air mencapai ${v} cm`, sensorCode: code, value: v, threshold: v >= 200 ? 200 : 120, unit: "cm" as const, minutes, status, officer };
  }
  if (kind === 1) {
    const v = 32 + ((i * 7) % 40);
    return { id, level: AlertLevel.SEDANG, type: AlertType.CURAH_HUJAN, title: "Curah hujan meningkat", sensorCode: code, value: v, threshold: 30, unit: "mm" as const, minutes, status, officer };
  }
  if (kind === 2) {
    return { id, level: AlertLevel.OFFLINE, type: AlertType.OFFLINE, title: "Sensor offline", sensorCode: code, value: null, threshold: null, unit: "" as const, minutes, status, officer };
  }
  const v = 10 + ((i * 3) % 9);
  return { id, level: AlertLevel.RENDAH, type: AlertType.BATERAI, title: `Baterai lemah (${v}%)`, sensorCode: code, value: v, threshold: 20, unit: "%" as const, minutes, status, officer };
});

export const MOCK_NOTIFICATIONS: INotification[] = [...head, ...rest].map(({ minutes, ...n }) => ({
  ...n,
  location: loc(n.sensorCode),
  createdAt: ago(minutes),
  // waktu respons contoh: 8-37 menit setelah alert muncul
  respondedAt: n.status === AlertStatus.BELUM ? null : ago(minutes - Math.min(minutes - 1, 8 + ((n.id * 7) % 30))),
}));
