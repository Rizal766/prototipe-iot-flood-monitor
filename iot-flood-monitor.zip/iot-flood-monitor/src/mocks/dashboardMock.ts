import { FloodStatus, type ISensor } from "@/types/sensor";
import type { IEvacuationPoint } from "@/types/map";
import {
  IntegrationType,
  type IAlert,
  type IDashboardSummary,
  type IIntegration,
  type IWaterChart,
} from "@/types/dashboard";

type ISensorBase = Omit<ISensor, "river" | "district" | "trend" | "history" | "signal" | "network" | "lastSeenMinutes" | "rssi" | "solar" | "temperature">;

const head: ISensorBase[] = [
  { id: 1, code: "BNA-003", name: "BNA-003", location: "Kali Banjir Kanal Barat", waterLevel: 248, status: FloodStatus.BAHAYA, battery: 92, updatedAt: "11:12", lat: -6.9769, lng: 110.3912 },
  { id: 2, code: "GRG-007", name: "GRG-007", location: "Kali Garang", waterLevel: 165, status: FloodStatus.SIAGA, battery: 87, updatedAt: "10:48", lat: -6.999, lng: 110.401 },
  { id: 3, code: "BRG-012", name: "BRG-012", location: "Kali Bringin", waterLevel: 89, status: FloodStatus.WASPADA, battery: 76, updatedAt: "09:32", lat: -6.987, lng: 110.347 },
  { id: 4, code: "SMG-015", name: "SMG-015", location: "Sungai Muktiharjo", waterLevel: 78, status: FloodStatus.AMAN, battery: 95, updatedAt: "08:00", lat: -6.974, lng: 110.462 },
  { id: 5, code: "TMR-021", name: "TMR-021", location: "Kali Timo", waterLevel: 34, status: FloodStatus.AMAN, battery: 88, updatedAt: "07:58", lat: -6.964, lng: 110.485 },
  { id: 6, code: "KDL-008", name: "KDL-008", location: "Kali Kembangarum", waterLevel: 62, status: FloodStatus.AMAN, battery: 81, updatedAt: "07:42", lat: -6.988, lng: 110.383 },
];

const rest: ISensorBase[] = Array.from({ length: 18 }, (_, i) => {
  const n = i + 7;
  const offline = n === 13 || n === 20;
  return {
    id: n,
    code: `SNR-${String(n).padStart(3, "0")}`,
    name: `SNR-${String(n).padStart(3, "0")}`,
    location: `Titik Pantau ${n}`,
    waterLevel: offline ? 0 : 30 + ((n * 17) % 60),
    status: offline ? FloodStatus.OFFLINE : n === 9 ? FloodStatus.WASPADA : FloodStatus.AMAN,
    battery: offline ? (n === 13 ? 11 : 21) : 60 + ((n * 7) % 40),
    updatedAt: offline ? "-" : "07:30",
    lat: -7.06 + (((n * 37) % 100) / 100) * 0.09,
    lng: 110.36 + (((n * 53) % 100) / 100) * 0.13,
  };
});

const META: Record<string, { river: string; district: string; trend: number }> = {
  "BNA-003": { river: "Banjir Kanal Barat", district: "Semarang Barat", trend: 12 },
  "GRG-007": { river: "Garang", district: "Gajahmungkur", trend: 6 },
  "BRG-012": { river: "Bringin", district: "Ngaliyan", trend: 4 },
  "SMG-015": { river: "Muktiharjo", district: "Pedurungan", trend: 1 },
  "TMR-021": { river: "Timo", district: "Genuk", trend: 1 },
  "KDL-008": { river: "Kembangarum", district: "Semarang Barat", trend: 0 },
};
const RIVERS = ["Banjir Kanal Barat", "Garang", "Bringin", "Babon", "Banjir Kanal Timur"];
const DISTRICTS = ["Semarang Barat", "Gajahmungkur", "Ngaliyan", "Genuk", "Pedurungan", "Tembalang"];

const enrich = (s: ISensorBase): ISensor => {
  const meta = META[s.code] ?? {
    river: RIVERS[s.id % RIVERS.length],
    district: DISTRICTS[s.id % DISTRICTS.length],
    trend: s.status === FloodStatus.OFFLINE ? 0 : ((s.id * 3) % 5) - 1,
  };
  const history =
    s.status === FloodStatus.OFFLINE
      ? []
      : Array.from({ length: 6 }, (_, i) => Math.max(0, Math.round(s.waterLevel - meta.trend * (5 - i))));
  const offline = s.status === FloodStatus.OFFLINE;
  const idx = Object.keys(META).indexOf(s.code);
  const SEEN = [2, 5, 9, 13, 17, 22];
  const SIGNAL = [4, 4, 3, 4, 3, 4];
  return {
    ...s,
    ...meta,
    history,
    signal: offline ? 0 : idx >= 0 ? SIGNAL[idx] : 2 + (s.id % 3),
    rssi: offline ? null : -(55 + ((s.id * 7) % 30)),
    solar: offline ? 0 : 60 + ((s.id * 13) % 40),
    temperature: offline ? 0 : 28 + (s.id % 8),
    network: offline ? "-" : s.id % 4 === 0 ? "LoRa" : s.id % 5 === 0 ? "3G" : "4G",
    lastSeenMinutes: idx >= 0 ? SEEN[idx] : offline ? 120 + ((s.id * 20) % 200) : 30 + ((s.id * 11) % 90),
  };
};

export const MOCK_SENSORS: ISensor[] = [...head, ...rest].map(enrich);

export const MOCK_EVACUATION: IEvacuationPoint[] = [
  { id: 1, name: "Balai Kelurahan Tawangmas", address: "Jl. Tawangmas Raya, Semarang Barat", lat: -6.9705, lng: 110.3955, capacity: 200, active: true },
  { id: 2, name: "GOR Jatidiri", address: "Jl. Setia Budi, Gajahmungkur", lat: -7.0255, lng: 110.4285, capacity: 500, active: true },
  { id: 3, name: "SD Negeri Bringin 01", address: "Jl. Bringin Raya, Ngaliyan", lat: -7.0065, lng: 110.3665, capacity: 150, active: true },
  { id: 4, name: "Masjid Raya Pedurungan", address: "Jl. Pedurungan Tengah, Pedurungan", lat: -6.9755, lng: 110.4655, capacity: 300, active: true },
  { id: 5, name: "Aula Kecamatan Genuk", address: "Jl. Raya Genuk, Genuk", lat: -7.0285, lng: 110.4565, capacity: 250, active: true },
];

export const MOCK_SUMMARY: IDashboardSummary = {
  totalSensor: 24,
  activeSensor: 22,
  offlineSensor: 2,
  riskLocations: 3,
  siaga: 1,
  waspada: 2,
  aman: 19,
  rainfall: 86,
  rainfallChange: 12,
  waterLevel: 118,
  waterLevelChange: 8,
};

export const MOCK_ALERTS: IAlert[] = [
  { id: 1, sensorCode: "BNA-003", location: "Kali Banjir Kanal Barat", message: "Tinggi muka air mencapai 248cm (Bahaya)", level: FloodStatus.BAHAYA, time: "11:12" },
  { id: 2, sensorCode: "GRG-007", location: "Kali Garang", message: "Tinggi muka air 165cm (Siaga)", level: FloodStatus.SIAGA, time: "10:48" },
  { id: 3, sensorCode: "BRG-012", location: "Kali Bringin", message: "Curah hujan meningkat 35mm/jam (Waspada)", level: FloodStatus.WASPADA, time: "09:32" },
  { id: 4, sensorCode: "SMG-015", location: "Normal", message: "Kondisi normal, tinggi muka air 78cm", level: FloodStatus.AMAN, time: "08:00" },
];

export const MOCK_WATER_CHART: IWaterChart = {
  hours: ["00.00", "02.00", "04.00", "06.00", "08.00", "10.00", "12.00", "14.00", "16.00", "18.00", "20.00", "22.00"],
  series: [
    { code: "BNA-003", label: "Bahaya", color: "#ef4444", data: [140, 125, 110, 115, 120, 135, 150, 170, 200, 230, 270, 300] },
    { code: "GRG-007", label: "Siaga", color: "#f97316", data: [100, 90, 85, 80, 95, 100, 105, 110, 120, 135, 150, 165] },
    { code: "BRG-012", label: "Waspada", color: "#eab308", data: [70, 65, 60, 62, 68, 72, 75, 80, 82, 85, 88, 89] },
  ],
};

export const MOCK_INTEGRATIONS: IIntegration[] = [
  { type: IntegrationType.SMS, name: "SMS Gateway", active: true },
  { type: IntegrationType.WHATSAPP, name: "WhatsApp", active: true },
  { type: IntegrationType.EMAIL, name: "Email", active: true },
  { type: IntegrationType.PUSH, name: "Push Notification", active: true },
  { type: IntegrationType.SIREN, name: "Sirene Remote", active: true },
  { type: IntegrationType.API, name: "API Integration", active: true },
];
