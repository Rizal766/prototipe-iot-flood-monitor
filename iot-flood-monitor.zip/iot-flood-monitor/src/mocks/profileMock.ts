import { MOCK_USERS } from "./userMock";
import { DEMO_ACCOUNTS } from "@/types/auth";
import type { IPreferences, ISession } from "@/types/profile";
import { describeDevice } from "@/utils/device";

const ago = (minutes: number) => new Date(Date.now() - minutes * 60000).toISOString();

// Kata sandi akun demo yang dapat diganti selama sesi aplikasi berjalan (hilang saat refresh)
export const MOCK_PASSWORDS = new Map<string, string>(DEMO_ACCOUNTS.map((a) => [a.user.email, a.password]));
export const MOCK_AVATARS = new Map<string, string>();
export const MOCK_PREFS = new Map<string, IPreferences>();
export const MOCK_SESSIONS = new Map<string, ISession[]>();

export const defaultPrefs = (): IPreferences => ({
  floodAlert: true,
  systemInfo: true,
  dailyReport: true,
  email: true,
  sms: true,
  whatsapp: true,
});

// Sesi pertama = browser yang sedang dipakai; sisanya contoh perangkat lain
export const sessionsFor = (email: string): ISession[] => {
  const key = email.toLowerCase();
  const existing = MOCK_SESSIONS.get(key);
  if (existing) return existing;
  const created: ISession[] = [
    { id: "current", device: describeDevice(navigator.userAgent), ip: "103.78.45.12", location: "Kota Semarang, Indonesia", lastActive: new Date().toISOString(), current: true },
    { id: "s-android", device: "Android Chrome", ip: "103.78.45.98", location: "Kota Semarang, Indonesia", lastActive: ago(60 * 26), current: false },
    { id: "s-edge", device: "Windows Edge", ip: "45.122.33.76", location: "Jakarta, Indonesia", lastActive: ago(60 * 24 * 3), current: false },
    { id: "s-iphone", device: "iPhone Safari", ip: "36.73.121.44", location: "Bandung, Indonesia", lastActive: ago(60 * 24 * 6), current: false },
  ];
  MOCK_SESSIONS.set(key, created);
  return created;
};

export const findMockUser = (email: string) =>
  MOCK_USERS.find((u) => u.email.toLowerCase() === email.toLowerCase());
