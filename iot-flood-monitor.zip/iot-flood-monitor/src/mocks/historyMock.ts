import { MOCK_SENSORS } from "./dashboardMock";
import type { ISensor } from "@/types/sensor";
import type { IHistoryPoint, IHistorySeries } from "@/types/history";

const HOUR = 3600000;

const hash = (s: string): number => {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
};

const mulberry32 = (seed: number) => () => {
  let a = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  a = a + 0;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

// Data deterministik per sensor & jam, berakhir mendekati nilai sensor saat ini
export const generateHistory = (
  ids: number[],
  fromMs: number,
  toMs: number,
  intervalHours: number,
): IHistorySeries[] => {
  const now = Date.now();
  const start = Math.floor(fromMs / HOUR) * HOUR;
  const end = Math.floor(toMs / HOUR) * HOUR;
  const bucketMs = intervalHours * HOUR;
  const tzOffset = -new Date().getTimezoneOffset() * 60000;

  const sensors = ids
    .map((id) => MOCK_SENSORS.find((s) => s.id === id))
    .filter((s): s is ISensor => Boolean(s));

  return sensors.map((s, idx) => {
    const base = Math.max(25, s.waterLevel * 0.55);
    const buckets = new Map<number, { water: number[]; rain: number }>();

    for (let t = start; t <= end; t += HOUR) {
      const hourIndex = Math.floor(t / HOUR);
      const hoursAgo = Math.max(0, (now - t) / HOUR);
      const noise = (mulberry32(hash(s.code) ^ hourIndex)() - 0.5) * 0.06 * base;
      const swing = 0.12 * base * Math.sin(hoursAgo / (10 + idx * 2) + idx);
      const surge = Math.max(0, s.waterLevel - base) * Math.exp(-hoursAgo / 60);
      const water = Math.max(0, Math.round(base + swing + surge + noise));
      const r = mulberry32(hash(`${s.code}-r`) ^ hourIndex)();
      const rain = r > 0.72 ? (r - 0.72) * 60 * (1 + Math.exp(-hoursAgo / 72)) : 0;

      const key = Math.floor((t - tzOffset) / bucketMs) * bucketMs + tzOffset;
      const b = buckets.get(key) ?? { water: [], rain: 0 };
      b.water.push(water);
      b.rain += rain;
      buckets.set(key, b);
    }

    const points: IHistoryPoint[] = [...buckets.entries()]
      .sort((a, b) => a[0] - b[0])
      .map(([key, b]) => ({
        t: new Date(key).toISOString(),
        waterLevel: Math.round(b.water.reduce((a, v) => a + v, 0) / b.water.length),
        rainfall: Math.round(b.rain * 10) / 10,
      }));

    return { sensorId: s.id, code: s.code, location: s.location, river: s.river, district: s.district, points };
  });
};
