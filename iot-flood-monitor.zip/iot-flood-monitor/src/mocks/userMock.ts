import { MOCK_SENSORS } from "./dashboardMock";
import { UserRole } from "@/types/auth";
import { Feature, PERMISSION_ROLES, type IPermissionMatrix } from "@/types/permission";
import { InviteStatus, UserStatus, type IArea, type IInvitation, type IUser } from "@/types/user";
import { OFFICERS } from "@/utils/officers";

const ago = (minutes: number) => new Date(Date.now() - minutes * 60000).toISOString();
const DISTRICTS = [...new Set(MOCK_SENSORS.map((s) => s.district))];

const slug = (name: string) => name.toLowerCase().replace(/[^a-z]+/g, ".").replace(/^\.|\.$/g, "");

const operators = ["Maya Sari", "Hendra Wijaya", "Lina Kusuma", "Doni Prakoso"];

export const MOCK_USERS: IUser[] = [
  { id: 1, name: "Admin", email: "admin@iotflood.id", phone: "081200000001", role: UserRole.ADMIN, areas: [], status: UserStatus.AKTIF, lastLogin: ago(30) },
  { id: 2, name: "Operator", email: "operator@iotflood.id", phone: "081200000002", role: UserRole.OPERATOR, areas: [], status: UserStatus.AKTIF, lastLogin: ago(95) },
  ...operators.map<IUser>((name, i) => ({
    id: 3 + i,
    name,
    email: `${slug(name)}@iotflood.id`,
    phone: `08120000010${i}`,
    role: UserRole.OPERATOR,
    areas: i % 2 === 0 ? [] : [DISTRICTS[i % DISTRICTS.length]],
    status: UserStatus.AKTIF,
    lastLogin: ago(180 + i * 400),
  })),
  ...OFFICERS.map<IUser>((name, i) => ({
    id: 7 + i,
    name,
    email: `${slug(name)}@iotflood.id`,
    phone: `08120000020${i}`,
    role: UserRole.PETUGAS,
    areas: [DISTRICTS[i % DISTRICTS.length]],
    status: i === 4 ? UserStatus.NONAKTIF : UserStatus.AKTIF,
    lastLogin: i === 5 ? null : ago(60 * 5 + i * 700),
  })),
];

export const MOCK_INVITATIONS: IInvitation[] = [
  { id: 1, name: "Rina Marlina", target: "rina.marlina@iotflood.id", role: UserRole.PETUGAS, areas: [DISTRICTS[3 % DISTRICTS.length]], sentAt: ago(120), status: InviteStatus.MENUNGGU, viaEmail: true },
  { id: 2, name: "Bagus Santoso", target: "bagus@contoh.invalid", role: UserRole.OPERATOR, areas: [], sentAt: ago(60 * 26), status: InviteStatus.GAGAL, viaEmail: true },
  { id: 3, name: "Tia Anggraini", target: "081200000777", role: UserRole.PETUGAS, areas: [DISTRICTS[4 % DISTRICTS.length]], sentAt: ago(60 * 24 * 9), status: InviteStatus.KEDALUWARSA, viaEmail: false },
];

const build = (fn: (role: UserRole, f: Feature) => boolean): IPermissionMatrix =>
  Object.fromEntries(
    Object.values(Feature).map((f) => [f, Object.fromEntries(PERMISSION_ROLES.map((r) => [r, fn(r, f)]))]),
  ) as IPermissionMatrix;

export const MOCK_PERMISSIONS: IPermissionMatrix = build((role, f) => {
  if (role === UserRole.ADMIN || role === UserRole.OPERATOR) return true;
  return f === Feature.DASHBOARD_PETA || f === Feature.NOTIFIKASI; // petugas lapangan
});

export const MOCK_AREAS: IArea[] = DISTRICTS.map((district, i) => ({
  district,
  residents: 800 + ((i * 437) % 2500),
  active: true,
}));
