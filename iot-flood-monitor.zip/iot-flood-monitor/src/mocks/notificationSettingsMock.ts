import {
  ChannelHealth,
  ChannelType,
  type IChannel,
  type ITemplates,
} from "@/types/notificationSettings";
import type { IEmergencyContact } from "@/types/contact";

const ago = (minutes: number) => new Date(Date.now() - minutes * 60000).toISOString();

// Nilai rahasia di sini hanya contoh; server sungguhan tidak pernah mengirim rahasia ke browser
export const MOCK_CHANNELS: IChannel[] = [
  {
    type: ChannelType.SMS,
    name: "SMS Gateway",
    enabled: true,
    health: ChannelHealth.NORMAL,
    fields: [
      { key: "provider", label: "Provider", value: "Zenziva" },
      { key: "sender", label: "Sender ID", value: "IOTFLOOD" },
      { key: "apiKey", label: "API Key", value: "sms-key-demo-k2f", secret: true },
    ],
    lastDeliveryAt: ago(125),
    lastTest: { ok: true, at: ago(2) },
  },
  {
    type: ChannelType.WHATSAPP,
    name: "WhatsApp",
    enabled: true,
    health: ChannelHealth.NORMAL,
    fields: [
      { key: "provider", label: "Provider", value: "Fonnte" },
      { key: "number", label: "Nomor Pengirim", value: "6281200000009" },
      { key: "token", label: "Token", value: "wa-token-demo-x9p", secret: true },
    ],
    lastDeliveryAt: ago(95),
    lastTest: { ok: true, at: ago(60) },
  },
  {
    type: ChannelType.EMAIL,
    name: "Email",
    enabled: true,
    health: ChannelHealth.NORMAL,
    fields: [
      { key: "host", label: "SMTP Host", value: "smtp.gmail.com" },
      { key: "port", label: "Port", value: "587" },
      { key: "from", label: "Pengirim", value: "iotflood@gmail.com" },
      { key: "password", label: "Password", value: "mail-pass-demo-77a", secret: true },
    ],
    lastDeliveryAt: ago(240),
    lastTest: { ok: true, at: ago(180) },
  },
  {
    type: ChannelType.PUSH,
    name: "Push Notification",
    enabled: true,
    health: ChannelHealth.NORMAL,
    fields: [
      { key: "provider", label: "Provider", value: "Firebase Cloud Messaging" },
      { key: "project", label: "Project ID", value: "iotflood-app" },
      { key: "serverKey", label: "Server Key", value: "fcm-key-demo-b31", secret: true },
    ],
    lastDeliveryAt: ago(75),
    lastTest: { ok: true, at: ago(30) },
  },
  {
    type: ChannelType.SIREN,
    name: "Sirene Remote",
    enabled: true,
    health: ChannelHealth.GANGGUAN,
    fields: [
      { key: "provider", label: "Provider", value: "Siren Controller" },
      { key: "sites", label: "Jumlah Lokasi", value: "3 site" },
      { key: "token", label: "Token", value: "siren-token-demo-45a", secret: true },
    ],
    lastDeliveryAt: ago(60 * 26),
    lastTest: { ok: false, at: ago(60 * 5) },
  },
  {
    type: ChannelType.API,
    name: "API Integration",
    enabled: true,
    health: ChannelHealth.NORMAL,
    fields: [
      { key: "endpoint", label: "Endpoint", value: "https://api.iotflood.id/v1/alerts" },
      { key: "secret", label: "Webhook Secret", value: "hook-secret-demo-c08", secret: true },
    ],
    lastDeliveryAt: ago(45),
    lastTest: { ok: true, at: ago(12) },
  },
];

export const MOCK_TEMPLATES: ITemplates = {
  BAHAYA: {
    title: "PERINGATAN BANJIR - BAHAYA",
    body: "PERINGATAN BANJIR! Status BAHAYA. Tinggi air {tinggi} cm di {lokasi} (sensor {sensor}) pada {waktu}. Segera evakuasi ke titik aman terdekat.",
  },
  SIAGA: {
    title: "SIAGA BANJIR",
    body: "SIAGA BANJIR. Tinggi air {tinggi} cm di {lokasi} (sensor {sensor}) pada {waktu}. Siapkan barang penting dan pantau informasi terbaru.",
  },
  WASPADA: {
    title: "WASPADA BANJIR",
    body: "WASPADA. Tinggi air mulai naik, {tinggi} cm di {lokasi} (sensor {sensor}) pada {waktu}. Tetap waspada.",
  },
  NORMAL: {
    title: "KONDISI NORMAL",
    body: "Kondisi NORMAL. Tinggi air kembali {tinggi} cm di {lokasi} (sensor {sensor}) pada {waktu}.",
  },
};

// Nomor layanan darurat nasional Indonesia
export const MOCK_CONTACTS: IEmergencyContact[] = [
  { id: 1, name: "Layanan Darurat Terpadu", phone: "112", category: "Darurat Nasional", showInAlert: true },
  { id: 2, name: "Polisi", phone: "110", category: "Polisi", showInAlert: false },
  { id: 3, name: "Pemadam Kebakaran", phone: "113", category: "Pemadam Kebakaran", showInAlert: true },
  { id: 4, name: "Ambulans", phone: "119", category: "Ambulans", showInAlert: true },
  { id: 5, name: "SAR / Basarnas", phone: "115", category: "SAR / Basarnas", showInAlert: true },
];

export const SETTINGS_META = { updatedAt: ago(60 * 24 * 2), updatedBy: "Admin" };
