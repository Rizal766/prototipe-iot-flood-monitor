import { MOCK_SENSORS } from "./dashboardMock";
import type { IAlertConfig } from "@/types/alertConfig";
import { buildDefaultConfig } from "@/utils/alertConfigDefaults";
import { THRESHOLD_TEMPLATES } from "@/utils/thresholdTemplates";
import { DEFAULT_THRESHOLDS, type IThresholds } from "@/utils/thresholds";

const THREE_DAYS_AGO = new Date(Date.now() - 3 * 86400000).toISOString();

export const MOCK_ALERT_CONFIGS: IAlertConfig[] = MOCK_SENSORS.map((s) =>
  buildDefaultConfig(
    s.id,
    s.code === "SMG-015" ? THRESHOLD_TEMPLATES[1].thresholds : DEFAULT_THRESHOLDS,
    "Admin",
    THREE_DAYS_AGO,
  ),
);

export const thresholdsOf = (sensorId: number): IThresholds =>
  MOCK_ALERT_CONFIGS.find((c) => c.sensorId === sensorId)?.thresholds ?? DEFAULT_THRESHOLDS;
