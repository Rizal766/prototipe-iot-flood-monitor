import { MOCK_SENSORS } from "./dashboardMock";
import { DeviceConnection, DeviceKind, type IDevice } from "@/types/device";
import { FloodStatus } from "@/types/sensor";

const pad = (n: number) => String(n).padStart(3, "0");
const FIRMWARE = ["v1.2.3", "v1.1.8", "v1.2.0", "v1.2.1"];
const MAINTENANCE_IDS = [9, 17];
const DAY = 86400000;

// Satu perangkat untuk setiap sensor; status koneksi mengikuti status sensor
export const MOCK_DEVICES: IDevice[] = MOCK_SENSORS.map((s) => ({
  id: s.id,
  sensorId: s.id,
  sensorCode: s.code,
  deviceId: `DEV-${pad(s.id)}`,
  name: s.location,
  kind: s.id % 4 === 0 ? DeviceKind.RAIN_GAUGE : DeviceKind.WATER_LEVEL,
  guid: `GK-${pad(s.id)}-${1000 + ((s.id * 2731) % 9000)}`,
  firmware: FIRMWARE[s.id % 4],
  connection:
    s.status === FloodStatus.OFFLINE
      ? DeviceConnection.OFFLINE
      : MAINTENANCE_IDS.includes(s.id)
        ? DeviceConnection.MAINTENANCE
        : DeviceConnection.ONLINE,
  lastSeen: s.lastSeenMinutes === null ? null : new Date(Date.now() - s.lastSeenMinutes * 60000).toISOString(),
  river: s.river,
  district: s.district,
  lat: s.lat,
  lng: s.lng,
  host: "broker.iotflood.id",
  officer: null,
  photo: null,
  registeredAt: new Date(Date.now() - (s.id <= 2 ? 10 + s.id * 5 : 120 + s.id * 9) * DAY).toISOString(),
}));
