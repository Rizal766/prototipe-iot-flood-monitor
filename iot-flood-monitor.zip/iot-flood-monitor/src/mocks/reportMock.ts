import dayjs, { type Dayjs } from "dayjs";
import { MOCK_SENSORS } from "./dashboardMock";
import { UserRole } from "@/types/auth";
import {
  ReportStatus,
  ReportType,
  type IReport,
  type IReportContent,
} from "@/types/report";
import { reportTitle } from "@/utils/reportName";

const ALL: IReportContent = { summary: true, charts: true, alerts: true, problemSensors: true };

const districtIds = (district: string) => MOCK_SENSORS.filter((s) => s.district === district).map((s) => s.id);
const AREAS: { label: string; ids: number[] | null }[] = [
  { label: "Semarang (Semua)", ids: null },
  { label: "Semarang Barat", ids: districtIds("Semarang Barat") },
  { label: "Genuk", ids: districtIds("Genuk") },
  { label: "GRG-007", ids: [2] },
];

const clamp = (d: Dayjs): Dayjs => (d.isAfter(dayjs()) ? dayjs() : d);
const day = (ago: number, h = 8, m = 0) =>
  dayjs().subtract(ago, "day").hour(h).minute(m).second(0).millisecond(0);

let nextId = 1;
const make = (
  type: ReportType,
  from: Dayjs,
  to: Dayjs,
  createdAt: Dayjs,
  i: number,
  status: ReportStatus = ReportStatus.SELESAI,
): IReport => {
  const area = AREAS[i % AREAS.length];
  const byAdmin = i % 2 === 0;
  const params = { type, from: from.toISOString(), to: to.toISOString(), areaLabel: area.label };
  return {
    id: nextId++,
    ...params,
    name: reportTitle(params),
    sensorIds: area.ids,
    includes: ALL,
    status,
    progress: status === ReportStatus.SELESAI ? 100 : 45,
    createdBy: byAdmin ? "Admin" : "Operator",
    creatorRole: byAdmin ? UserRole.ADMIN : UserRole.OPERATOR,
    createdAt: clamp(createdAt).toISOString(),
    schedule: null,
  };
};

const seed: IReport[] = [];

// 10 laporan harian
for (let i = 1; i <= 10; i++) {
  seed.push(make(ReportType.HARIAN, day(i).startOf("day"), day(i).endOf("day"), day(i - 1, 7, 10), i));
}
// 4 laporan mingguan
for (let w = 0; w < 4; w++) {
  const to = day(7 * w + 1).endOf("day");
  seed.push(make(ReportType.MINGGUAN, to.subtract(6, "day").startOf("day"), to, to.add(1, "day").hour(8).minute(0), w + 3));
}
// 5 laporan bulanan
for (let m = 1; m <= 5; m++) {
  const start = dayjs().subtract(m, "month").startOf("month");
  const end = start.endOf("month");
  seed.push(make(ReportType.BULANAN, start, end, end.add(1, "day").hour(8).minute(0), m));
}
// 5 laporan kejadian (yang terbaru gagal dibuat)
[2, 15, 33, 61, 90].forEach((ago, i) => {
  const from = day(ago).startOf("day");
  seed.push(
    make(
      ReportType.KEJADIAN,
      from,
      from.add(1, "day").endOf("day"),
      from.add(2, "day").hour(9).minute(0),
      i + 1,
      i === 0 ? ReportStatus.GAGAL : ReportStatus.SELESAI,
    ),
  );
});

export const MOCK_REPORTS: IReport[] = seed.sort((a, b) => b.createdAt.localeCompare(a.createdAt));

// Simulasi pemrosesan di server: progres naik bertahap lalu selesai
export const simulateProcessing = (id: number) => {
  [25, 50, 75, 100].forEach((p, i) => {
    setTimeout(() => {
      const r = MOCK_REPORTS.find((x) => x.id === id);
      if (!r || r.status !== ReportStatus.PROSES) return;
      r.progress = p;
      if (p === 100) r.status = ReportStatus.SELESAI;
    }, (i + 1) * 1800);
  });
};

export const nextReportId = () => Math.max(0, ...MOCK_REPORTS.map((r) => r.id)) + 1;
