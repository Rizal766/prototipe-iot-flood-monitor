import { lazy, Suspense, type ReactNode } from "react";
import { Navigate, createHashRouter } from "react-router-dom";
import { Spin } from "antd";
import MainLayout from "@/components/MainLayout";
import ProtectedRoute from "@/components/ProtectedRoute";
import RequireFeature from "@/components/RequireFeature";
import { Feature } from "@/types/permission";

// Section 3: Lazyloading (Performance)
const DashboardPage = lazy(() => import("@/pages/DashboardPage"));
const DataSensorPage = lazy(() => import("@/pages/DataSensorPage"));
const SensorDetailPage = lazy(() => import("@/pages/SensorDetailPage"));
const PetaPage = lazy(() => import("@/pages/PetaPage"));
const RiwayatPage = lazy(() => import("@/pages/RiwayatPage"));
const NotifikasiPage = lazy(() => import("@/pages/NotifikasiPage"));
const LaporanPage = lazy(() => import("@/pages/LaporanPage"));
const PerangkatPage = lazy(() => import("@/pages/PerangkatPage"));
const AmbangPage = lazy(() => import("@/pages/AmbangPage"));
const PenggunaPage = lazy(() => import("@/pages/PenggunaPage"));
const SaluranPage = lazy(() => import("@/pages/SaluranPage"));
const LoginPage = lazy(() => import("@/pages/LoginPage"));
const ProfilPage = lazy(() => import("@/pages/ProfilPage"));

const withSuspense = (node: ReactNode) => (
  <Suspense fallback={<Spin className="mt-10 block" />}>{node}</Suspense>
);

// Halaman dibatasi menurut hak akses per role (menu Pengguna & Role > Hak Akses)
const page = (feature: Feature, node: ReactNode) => (
  <RequireFeature feature={feature}>{withSuspense(node)}</RequireFeature>
);

export const router: ReturnType<typeof createHashRouter> = createHashRouter([
  { path: "/login", element: withSuspense(<LoginPage />) },
  {
    element: <ProtectedRoute />,
    children: [
      {
        element: <MainLayout />,
        children: [
          { path: "/", element: page(Feature.DASHBOARD_PETA, <DashboardPage />) },
          { path: "/peta", element: page(Feature.DASHBOARD_PETA, <PetaPage />) },
          { path: "/sensors", element: page(Feature.SENSOR, <DataSensorPage />) },
          { path: "/sensors/:id", element: page(Feature.SENSOR, <SensorDetailPage />) },
          { path: "/riwayat", element: page(Feature.RIWAYAT, <RiwayatPage />) },
          { path: "/notifikasi", element: page(Feature.NOTIFIKASI, <NotifikasiPage />) },
          { path: "/laporan", element: page(Feature.LAPORAN, <LaporanPage />) },
          { path: "/pengaturan", element: <Navigate to="/pengaturan/perangkat" replace /> },
          { path: "/pengaturan/perangkat", element: page(Feature.PENGATURAN, <PerangkatPage />) },
          { path: "/pengaturan/ambang", element: page(Feature.PENGATURAN, <AmbangPage />) },
          { path: "/pengaturan/pengguna", element: page(Feature.PENGATURAN, <PenggunaPage />) },
          { path: "/pengaturan/saluran", element: page(Feature.PENGATURAN, <SaluranPage />) },
          // profil sendiri tidak dibatasi hak akses menu
          { path: "/pengaturan/profil", element: withSuspense(<ProfilPage />) },
        ],
      },
    ],
  },
]);
