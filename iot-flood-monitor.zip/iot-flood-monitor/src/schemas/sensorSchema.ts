import { z } from "zod";
import type { ISensorPayload } from "@/types/sensor";

export const coord = (max: number, label: string) =>
  z
    .string()
    .min(1, `${label} wajib diisi`)
    .refine((v) => {
      const n = Number(v);
      return !Number.isNaN(n) && Math.abs(n) <= max;
    }, `${label} tidak valid`);

export const sensorSchema = z.object({
  code: z.string().regex(/^[A-Za-z]{2,5}-\d{3}$/, "Format kode: ABC-001"),
  location: z.string().min(3, "Lokasi minimal 3 karakter"),
  river: z.string().min(3, "Nama sungai minimal 3 karakter"),
  district: z.string().min(3, "Kecamatan minimal 3 karakter"),
  lat: coord(90, "Latitude"),
  lng: coord(180, "Longitude"),
});

export type SensorFormValues = z.infer<typeof sensorSchema>;

export const toPayload = (v: SensorFormValues): ISensorPayload => ({
  code: v.code.toUpperCase(),
  location: v.location.trim(),
  river: v.river.trim(),
  district: v.district.trim(),
  lat: Number(v.lat),
  lng: Number(v.lng),
});
