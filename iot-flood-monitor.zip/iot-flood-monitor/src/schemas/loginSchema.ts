import { z } from "zod";

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const phoneRegex = /^(\+62|62|0)8[0-9]{8,12}$/;

export const loginSchema = z.object({
  identifier: z
    .string()
    .min(1, "Email / No. Telepon wajib diisi")
    .refine((v) => emailRegex.test(v) || phoneRegex.test(v), "Format email atau no. telepon tidak valid"),
  password: z.string().min(6, "Password minimal 6 karakter"),
});

export type LoginFormValues = z.infer<typeof loginSchema>;
