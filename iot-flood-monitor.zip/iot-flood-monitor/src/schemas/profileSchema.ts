import { z } from "zod";
import { PHONE_RE } from "./userSchema";

export const profileSchema = z.object({
  name: z.string().trim().min(3, "Nama minimal 3 karakter"),
  phone: z
    .string()
    .trim()
    .refine((v) => v === "" || PHONE_RE.test(v), "Nomor HP tidak valid (contoh 081234567890)"),
});
export type ProfileFormValues = z.infer<typeof profileSchema>;

export const passwordSchema = z
  .object({
    oldPassword: z.string().min(1, "Password lama wajib diisi"),
    newPassword: z
      .string()
      .min(8, "Minimal 8 karakter")
      .regex(/[A-Za-z]/, "Harus mengandung huruf")
      .regex(/\d/, "Harus mengandung angka"),
    confirm: z.string().min(1, "Konfirmasi password wajib diisi"),
    signOutOthers: z.boolean(),
  })
  .superRefine((v, ctx) => {
    if (v.newPassword && v.confirm && v.newPassword !== v.confirm) {
      ctx.addIssue({ code: "custom", path: ["confirm"], message: "Konfirmasi password tidak sama" });
    }
    if (v.newPassword && v.oldPassword && v.newPassword === v.oldPassword) {
      ctx.addIssue({ code: "custom", path: ["newPassword"], message: "Password baru tidak boleh sama dengan password lama" });
    }
  });
export type PasswordFormValues = z.infer<typeof passwordSchema>;

// 0-4: seberapa kuat sebuah password (hanya indikator, bukan aturan wajib)
export const passwordStrength = (pw: string): number => {
  let score = 0;
  if (pw.length >= 8) score += 1;
  if (pw.length >= 12) score += 1;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) score += 1;
  if (/\d/.test(pw) && /[^A-Za-z0-9]/.test(pw)) score += 1;
  return score;
};
