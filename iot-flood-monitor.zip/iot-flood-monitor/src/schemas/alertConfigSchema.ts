import { z } from "zod";
import type { IAlertConfig, IAlertConfigPayload } from "@/types/alertConfig";

const flag = z.boolean();
const target = z.object({
  admin: flag,
  operator: flag,
  petugas: flag,
  bpbd: flag,
  push: flag,
  sms: flag,
  whatsapp: flag,
  email: flag,
  sirene: flag,
});

const num = (label: string) =>
  z.number({ required_error: `${label} wajib diisi`, invalid_type_error: `${label} wajib diisi` });

export const alertFormSchema = z
  .object({
    waspada: num("Nilai Waspada").positive("Nilai Waspada harus lebih dari 0"),
    siaga: num("Nilai Siaga").positive("Nilai Siaga harus lebih dari 0"),
    bahaya: num("Nilai Bahaya").positive("Nilai Bahaya harus lebih dari 0"),
    rainfall: num("Intensitas hujan").positive("Intensitas hujan harus lebih dari 0"),
    offlineMinutes: num("Batas offline")
      .int("Batas offline harus bilangan bulat")
      .min(1, "Batas offline minimal 1 menit"),
    batteryPercent: num("Batas baterai").min(1, "Batas baterai minimal 1%").max(100, "Batas baterai maksimal 100%"),
    matrix: z.object({ WASPADA: target, SIAGA: target, BAHAYA: target }),
  })
  .superRefine((v, ctx) => {
    if (v.siaga <= v.waspada) {
      ctx.addIssue({ code: "custom", path: ["siaga"], message: "Nilai Siaga harus lebih besar dari Waspada." });
    }
    if (v.bahaya <= v.siaga) {
      ctx.addIssue({ code: "custom", path: ["bahaya"], message: "Nilai Bahaya harus lebih besar dari Siaga." });
    }
  });

export type AlertFormValues = z.infer<typeof alertFormSchema>;

export const toFormValues = (c: IAlertConfig): AlertFormValues => ({
  waspada: c.thresholds.waspada,
  siaga: c.thresholds.siaga,
  bahaya: c.thresholds.bahaya,
  rainfall: c.rules.rainfallMmPerHour,
  offlineMinutes: c.rules.offlineMinutes,
  batteryPercent: c.rules.batteryPercent,
  matrix: structuredClone(c.matrix),
});

export const toPayload = (v: AlertFormValues): IAlertConfigPayload => ({
  thresholds: { waspada: v.waspada, siaga: v.siaga, bahaya: v.bahaya },
  rules: { rainfallMmPerHour: v.rainfall, offlineMinutes: v.offlineMinutes, batteryPercent: v.batteryPercent },
  matrix: v.matrix,
});
