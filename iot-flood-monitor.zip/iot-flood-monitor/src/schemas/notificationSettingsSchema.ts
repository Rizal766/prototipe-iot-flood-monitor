import { z } from "zod";
import { CONTACT_CATEGORIES } from "@/types/contact";
import { coord } from "./sensorSchema";

export const contactSchema = z.object({
  name: z.string().min(3, "Nama minimal 3 karakter"),
  phone: z.string().regex(/^\+?[\d\s-]{3,20}$/, "Nomor telepon tidak valid"),
  category: z.enum(CONTACT_CATEGORIES),
  showInAlert: z.boolean(),
});
export type ContactFormValues = z.infer<typeof contactSchema>;

export const evacuationSchema = z.object({
  name: z.string().min(3, "Nama minimal 3 karakter"),
  address: z.string().min(5, "Alamat minimal 5 karakter"),
  capacity: z
    .string()
    .min(1, "Kapasitas wajib diisi")
    .refine((v) => /^\d+$/.test(v) && Number(v) > 0, "Kapasitas harus bilangan bulat lebih dari 0"),
  lat: coord(90, "Latitude"),
  lng: coord(180, "Longitude"),
  active: z.boolean(),
});
export type EvacuationFormValues = z.infer<typeof evacuationSchema>;
