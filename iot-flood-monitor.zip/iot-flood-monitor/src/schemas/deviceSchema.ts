import { z } from "zod";
import { DeviceKind } from "@/types/device";
import { coord } from "./sensorSchema";

export const deviceFormSchema = z.object({
  deviceId: z.string().regex(/^DEV-\d{3}$/, "Format ID: DEV-001"),
  name: z.string().min(3, "Nama lokasi minimal 3 karakter"),
  river: z.string().min(3, "Nama sungai wajib diisi"),
  district: z.string().min(3, "Kecamatan wajib diisi"),
  lat: coord(90, "Latitude"),
  lng: coord(180, "Longitude"),
  kind: z.nativeEnum(DeviceKind),
  guid: z.string().regex(/^GK-\d{3}-\d{4}$/, "Format GUID / Kit ID: GK-001-7789"),
  firmware: z.string().regex(/^v\d+\.\d+\.\d+$/, "Format firmware: v1.2.3"),
  template: z.string().min(1, "Pilih template ambang batas"),
  officer: z.string(),
});

export type DeviceFormValues = z.infer<typeof deviceFormSchema>;

// Kolom yang divalidasi pada tiap langkah wizard
export const STEP_FIELDS: (keyof DeviceFormValues)[][] = [
  ["deviceId", "name", "river", "district", "lat", "lng"],
  ["kind", "guid", "firmware"],
  ["template"],
  ["officer"],
];

export const deviceEditSchema = deviceFormSchema.pick({
  name: true,
  river: true,
  district: true,
  lat: true,
  lng: true,
  guid: true,
  firmware: true,
  officer: true,
});

export type DeviceEditValues = z.infer<typeof deviceEditSchema>;
