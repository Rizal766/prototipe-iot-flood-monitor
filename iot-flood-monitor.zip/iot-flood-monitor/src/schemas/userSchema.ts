import { z } from "zod";
import { UserRole } from "@/types/auth";
import { UserStatus } from "@/types/user";

export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
export const PHONE_RE = /^(\+62|62|0)8\d{8,12}$/;

const name = z.string().min(3, "Nama minimal 3 karakter");

export const userFormSchema = z
  .object({
    name,
    email: z.string(),
    phone: z.string(),
    role: z.nativeEnum(UserRole),
    areas: z.array(z.string()),
    status: z.nativeEnum(UserStatus),
  })
  .superRefine((v, ctx) => {
    const email = v.email.trim();
    const phone = v.phone.trim();
    if (!email && !phone) {
      ctx.addIssue({ code: "custom", path: ["email"], message: "Isi email atau nomor HP" });
    }
    if (email && !EMAIL_RE.test(email)) {
      ctx.addIssue({ code: "custom", path: ["email"], message: "Format email tidak valid" });
    }
    if (phone && !PHONE_RE.test(phone)) {
      ctx.addIssue({ code: "custom", path: ["phone"], message: "Nomor HP tidak valid (contoh 081234567890)" });
    }
  });

export type UserFormValues = z.infer<typeof userFormSchema>;

export const inviteSchema = z
  .object({
    name,
    target: z.string().min(1, "Email / No. HP wajib diisi"),
    role: z.nativeEnum(UserRole),
    areas: z.array(z.string()),
    viaEmail: z.boolean(),
  })
  .superRefine((v, ctx) => {
    const t = v.target.trim();
    if (!t) return;
    const isEmail = EMAIL_RE.test(t);
    if (!isEmail && !PHONE_RE.test(t)) {
      ctx.addIssue({ code: "custom", path: ["target"], message: "Isi email atau nomor HP yang valid" });
    } else if (v.viaEmail && !isEmail) {
      ctx.addIssue({ code: "custom", path: ["target"], message: "Undangan via email memerlukan alamat email" });
    }
  });

export type InviteFormValues = z.infer<typeof inviteSchema>;
